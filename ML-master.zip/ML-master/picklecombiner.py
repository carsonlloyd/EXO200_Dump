#!/usr/bin/env python
import cPickle as pickle
import numpy as np

newdict = {}
print "X pickle"
with open('ada100x_APDs_only.pkl','r') as f:
	newdict = pickle.load(f)

print "Y pickle"
with open('ada100y_APDs_only.pkl','r') as f:
	y = pickle.load(f)

print "scE pickle"
with open('ada100scE_APDs_only.pkl','r') as f:
	scE = pickle.load(f)

print "z pickle"
with open('ada100z_APDs_only.pkl','r') as f:
	z = pickle.load(f)

print "Updating dict"
newdict.update(y)
newdict.update(scE)
newdict.update(z)

print "dumping to new pickle"
with open('ada100/ada100_APDs_only.pkl','w') as f:
	pickle.dump(newdict,f,-1)
