#!/usr/bin/env python
from __future__ import print_function

import cPickle as pickle
import os
import sys

import numpy as np
import matplotlib.pyplot as plt

def load (filename):
	with open (filename, 'rb') as f:
		return pickle.load (f)

def save (obj, filename):
	with open (filename, 'wb') as f:
		pickle.dump (obj, f, -1)

class Data (object):

	def __init__ (self, candidates=None):
		self._cols = 't x y z nsc scE ccE u v '.split()
		if candidates is not None:
			for (i, col) in enumerate (self._cols):
				setattr (self, col, candidates.T[i])

	def __len__ (self):
		return self.t.size

	def get_copy (self, mask):
		out = Data ()
		for col in self._cols:
			a = getattr (self, col)
			setattr (out, col, a[mask])
		return out

def load_rnpo_data():
	return Data(load('RnPo_all_candidates.pkl')['candidates'])

def load_nocc_data():
	return Data(load('onescnocc.pkl')['candidates'])

def compare_nsc(rnpo, nocc):
	hist, bins = np.histogram(rnpo.nsc, bins=700, range = (0,70000))
	fig = plt.figure(figsize=(6,4))
	xhist, yhist = bins, np.r_[hist,hist[-1]]
	ax = plt.gca()
	ax.plot(xhist,yhist,drawstyle='steps-post')
	plt.xlabel('Scintillation Counts')
	plt.ylabel('Events')
	plt.title('RnPo candidates')
	plt.savefig('RnPo_nscounts.png')
	plt.close(fig)

	hist, bins = np.histogram(nocc.nsc, bins=700, range = (0,70000))
	fig = plt.figure(figsize=(6,4))
	xhist, yhist = bins, np.r_[hist,hist[-1]]
	ax = plt.gca()
	ax.plot(xhist,yhist,drawstyle='steps-post')
	plt.xlabel('Scintillation Counts')
	plt.ylabel('Events')
	plt.title('One Scint Cluster, No Charge Clusters')
	plt.savefig('nocc_nscounts.png')
	plt.close(fig)

if __name__ == '__main__':
	rnpo = load_rnpo_data()
	nocc = load_nocc_data()
	compare_nsc(rnpo,nocc)

