def ks(z, name):
	plotx = np.linspace (20, 172, len(z))
	y = np.linspace (0, 1, len(z))
	uniform_cdf = lambda x: 1 / (170-20.) * (x - 20.)
	criticalD001 = 1.628/np.sqrt(len(z))
	criticalD05 = 1.358/np.sqrt(len(z))
	criticalD01 = 1.224/np.sqrt(len(z))
	uni_cdf = uniform(loc=(20.),scale=(152.))
	
	plt.figure(1)
	plt.clf()
	ax = plt.gca()
	ax.plot(np.sort(z),y,label='Empirical CDF')
	ax.plot(plotx,uni_cdf.cdf(plotx),label='Uniform CDF')
#	ax.scatter(np.sort(z),y-uni_cdf.cdf(plotx),s=10, c='b', marker='o',edgecolors='none')
	plt.xlim(20,172)
	plt.ylim(-0.5, 1.5)
	plt.legend()	

	plt.savefig('%s'%name)

	plt.show()
	return stats.kstest(z,uniform_cdf)
