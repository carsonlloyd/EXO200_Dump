#!/usr/bin/env python

from __future__ import print_function

import cPickle as pickle
import os
import sys

import numpy as np
import matplotlib.pyplot as plt


def load (filename):
	with open (filename, 'rb') as f:
		return pickle.load (f)

def save (obj, filename):
	with open (filename, 'wb') as f:
		pickle.dump (obj, f, -1)

class Data (object):

	def __init__ (self, candidates=None):
		self._cols = 't x y z nsc scE ccE u v ' \
			'x_ml y_ml scE_ml '.split ()
		if candidates is not None:
			for (i, col) in enumerate (self._cols):
				setattr (self, col, candidates.T[i])

	def __len__ (self):
		return self.t.size

	def get_copy (self, mask):
		out = Data ()
		for col in self._cols:
			a = getattr (self, col)
			setattr (out, col, a[mask])
		return out

	@property
	def mask_bulk (self):
		mask_z = (20 <= np.abs (self.z)) & (np.abs (self.z) <= 172)
		mask_nsc = (28e3 <= self.nsc) & (self.nsc <= 50e3)
		mask_ccE = self.ccE <= 210
		return mask_z & mask_nsc & mask_ccE

	@property
	def mask_surface (self):
		return ~self.mask_bulk

	@property
	def mask_teflon(self):
		reco = self.x>-998.
		r_reco_tef = np.sqrt(self.x**2 + self.y**2) > 170
		r_ml_tef = np.sqrt(self.x_ml**2 + self.y_ml**2) > 170
		mask = np.where(reco, r_reco_tef, r_ml_tef)
		return mask

	@property
	def mask_no_anodes(self):
		mask_z = np.abs(self.z) <= 172
		return mask_z
		

dTmax = 180. # s
dumax = 9.   # mm
dxymax = 30. # mm

def load_data ():
	return Data (load ('RnPo_all_candidates_with_ada100_position.pkl')['candidates'])

def load_bulk_data ():
	data = load_data ()
	return data.get_copy (data.mask_bulk)

def load_coincs (which):
	return load (which + '_coincs.pickle')

def load_each_coincs (which):
	coincs = load_coincs (which)
	return coincs['good'], coincs['ambiguous']

def get_coincs (data):

	i2 = 1
	coincs_good = []
	coincs_ambiguous = [()]
	
	for i1 in xrange (len (data)):
		if i1 in coincs_ambiguous[-1]:
			continue

		t1 = data.t[i1]
		u1 = data.u[i1]
		v1 = data.v[i1]
		x1 = data.x[i1]
		y1 = data.y[i1]
		z1 = data.z[i1]

		while data.t[i2] <= t1 + 2 * dTmax:
			if i2 == len (data) - 1:
				break
			i2 += 1

		delta_u = data.u[i1:i2+1] - u1

		mask = np.abs (delta_u) <= dumax

		if x1 > -998:
			dx = data.x[i1:i2+1] - x1
			dy = data.y[i1:i2+1] - y1
			mask |= np.sqrt(dx**2 + dy**2) < dxymax

		if x1 < -998.:
			dx_ml = data.x_ml[i1:i2+1] - data.x_ml[i1]
			dy_ml = data.y_ml[i1:i2+1] - data.y_ml[i1]
			mask |= np.sqrt(dx_ml**2 + dy_ml**2) < dxymax


		#mask[0] = False
		mask &= (data.t[i1:i2+1] - t1) <= 2 * dTmax
		mask &= (data.z[i1:i2+1] / z1) > 0

		#check for dTs within dTmax
		i_coincs = i1 + np.where (mask)[0]
		dTs = np.diff(data.t[i_coincs])
		dTs_inrange = dTs < dTmax
		n = len(dTs)

		# if there is a coinc, check that there is no second coinc
		if n >= 1 and dTs_inrange[0]:
			if n >= 2 and dTs_inrange[1]:
				coincs_ambiguous.append(tuple(i_coincs))
			else: 
				coincs_good.append(tuple(i_coincs[:2]))

		if i1 % 50000 == 0:
			print (i1, '...')

	coincs = dict(good=coincs_good, ambiguous=coincs_ambiguous)
	return coincs


def get_dz_dt (data, coincs, mask=None):
	coincs = np.array (coincs)
	if mask is None:
		mask = np.ones (len (coincs), dtype=bool)
	dz = np.array ([
		-np.sign (data.z[c[0]]) * np.diff (data.z[np.r_[c]])[0]
		for c in coincs[mask]
	])
	dt = np.array ([
		np.diff (data.t[np.r_[c]])[0]
		for c in coincs[mask]
	])
	return dz, dt

def get_mask_ends_in_bulk (data, coincs):
	i2 = np.array (coincs).T[1]
	return data.mask_bulk[i2]

def get_v(data, coincs, mask=None):
	dz, dt = get_dz_dt(data, coincs, mask)
	return dz/dt

def get_mask_teflon(data, coincs):
	i2 = np.array(coincs).T[1]
	return data.mask_teflon[i2]

def get_mask_v(v):
	return v>0.5

def get_mask_no_anodes(data, coincs):
	i2 = np.array(coincs).T[1]
	return data.mask_no_anodes[i2]

def all_masks(data, coincs):
	ends_bulk = get_mask_ends_in_bulk(data, coincs)
	no_anodes = get_mask_no_anodes(data, coincs)
	tef = get_mask_teflon(data, coincs)
	v = get_v(data, coincs)
	v_mask = get_mask_v(v)
	return ends_bulk, no_anodes, tef, v_mask

if __name__ == '__main__':
	if 'redo' in sys.argv:
		print ('Loading...')
		data = load_data ()
		coincs = get_coincs (data)
		save (coincs, 'ml_all_coincs.pickle')
		bulk_data = data.get_copy (data.mask_bulk)
		bulk_coincs = get_coincs (bulk_data)
		save (bulk_coincs, 'ml_bulk_coincs.pickle')


# Plotting stuff:

##scE for Rn, Po, Po
# plt.figure(1); plt.clf(); ax = plt.gca(); mask_z = (data.z>20.)&(data.z<172.); mask_R = np.sqrt(data.x_ml**2 + data.y_ml**2)<172.; H, xedges, yedges = np.histogram2d(data.z[data.nsc>25000],data.scE_ml[data.nsc>25000],bins=(200,200),range=((-200,200),(25000,70000))); H = np.rot90(H); H = np.flipud(H); H2 = np.ma.masked_where(H==0,H); H3 = np.log(H2); plt.pcolormesh(xedges,yedges,H3,vmax = np.amax(H3)); cbar = plt.colorbar(); cbar.ax.set_ylabel('Events'); plt.xlabel('Z pos (mm)'); plt.ylabel('Raw scintillation counts'); plt.savefig('alphaplots/scE_ml_vs_z.png'); plt.show()

# plt.figure(1); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(data.scE[tpc1_sce&mask_z], bins = 150, range = (30000,60000)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post'); plt.xlabel('Corrected scintillation counts'); plt.ylabel('Events'); plt.title('TPC 1'); plt.savefig('alphaplots/TPC1_nsc.png'); plt.show()

 
## for dz dt from the beginning
# plt.figure(1); plt.clf(); ax = plt.gca(); dz, dt = get_dz_dt (bulk_data, bcg) ; ax.scatter(dz, dt, s=10, c='b', marker='o',edgecolors='none') ; plt.ylim (0, dt.max()) ; plt.xlabel(r'$\Delta z$'); plt.ylabel(r'$\Delta t$'); plt.grid (); plt.savefig('alphaplots/dzdt.png'); plt.show()

## for z, from dzdt
#plt.figure(2); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(dz, bins = 400, range = (-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post'); plt.xlabel('dz'); plt.ylabel('Coincs'); plt.savefig('alphaplots/z.png'); plt.show()

## for velocity 
#plt.figure(3); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(v, bins = 160, range = (-1.0,3.0)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post', color='b'); bin_centers = bins[:-1] + 0.5 * np.diff(bins); ax.errorbar(bin_centers, hist, yerr=np.sqrt(hist), linestyle='none', capsize=0, color='b'); plt.xlabel(r'$v$'); plt.ylabel(r'${}^{218}\textrm{Po}$'); plt.savefig('alphaplots/vel.png'); plt.show()

## extra for fit to ion
# from scipy.optimize import curve_fit; from RnPocoincidence2 import gauss_sum
# plt.figure(3); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(v, bins = 160, range = (-1.0,3.0)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post', color='b'); bin_centers = bins[:-1] + 0.5 * np.diff(bins); ax.errorbar(bin_centers, hist, yerr=np.sqrt(hist), linestyle='none', capsize=0, color='b'); plt.xlabel(r'$v \textrm{\small{ (mm/s)}}$'); plt.ylabel(r'${}^{218}\textrm{Po}$'); x_fit = bins[:-1] + 0.5 * np.diff(bins); gauss_plot = np.linspace(xhist.min(),xhist.max(),200); p0 = np.array([500.,100.,60.,0.,0.,1.2,0.06,0.16,0.35]); coeff, var_matrix = curve_fit(gauss_sum, x_fit, hist, p0); hist_fit = gauss_sum(gauss_plot, *coeff); ax.plot(gauss_plot, hist_fit, label='sigma = %4.3f'%coeff[0], color='r'); plt.savefig('alphaplots/vel_fit.png'); plt.show();

## z position histogram
#plt.figure(8); plt.clf(); ax = plt.gca(); ends_bulk, tef, v_mask = all_masks(data, cg); mask = ends_bulk & tef & v_mask; hist, bins = np.histogram(data.z[mask], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post'); plt.xlabel('z position'); plt.ylabel('# Po++'); plt.show()

#scint counts vs z position, figure 7 from alpha paper
#plt.figure(5); plt.clf(); ax = plt.gca(); Rn_nsc = np.array([bulk_data.nsc[c[0]] for c in bcg]); Po_nsc = np.array([bulk_data.nsc[c[1]] for c in bcg]); ax.scatter(Rn_z, Rn_nsc, s=10, c= 'r', marker='o', edgecolors='none'); ax.scatter(Po_z, Po_nsc, s=10, c='k', marker='o', edgecolors='none'); plt.ylim(25000, 55000); l1 = plt.scatter([],[], s=30, c='r',marker='o',edgecolors='none'); l2 = plt.scatter([],[], s=30, c='k', marker='o',edgecolors='none'); plt.legend([l1,l2],labels); plt.savefig('alphaplots/nscvszRnPo.png'); plt.show()


## for surface events
#bmask = nsc_mask&z_mask&ccE_mask; surface_mask = ~bmask
#plt.figure(8); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(data.z[surface_mask], bins = 20, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post'); bin_centers = bins[:-1] + 0.5 * np.diff(bins); ax.errorbar(bin_centers, hist, yerr=np.sqrt(hist), linestyle='none', capsize=0, color='b'); plt.xlabel('z position'); plt.savefig('surfaceplots/alpha_surface_cath_an_z.png'); plt.show()

#from mpl_toolkits.mplot3d import Axes3D; pos_3d = plt.figure(2); ax = pos_3d.add_subplot(111, projection='3d'); ax.scatter(data.x_ml[surface_mask&z_mask],data.y_ml[surface_mask&z_mask],data.z[surface_mask&z_mask], s=2, lw=0); ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_zlabel('z'); ax.set_xlim([-200,200]); ax.set_ylim([-200,200]); ax.set_zlim([-200,200]); plt.savefig('surfaceplots/alpha_3d_surf.png'); plt.show(); plt.close(pos_3d)
'''
z_edges = np.array([-200, -190, -10, -1, 0, 1, 10, 190, 200]); nbins = 20; 
#z_edges = np.arange(-200,200,10)

for (z1, z2) in zip(z_edges[:-1], z_edges[1:]):

	mask = (z1 <= data.z) & (data.z < z2)
	hists, xedges, yedges = np.histogram2d(data.x_ml[mask&surface_mask], data.y_ml[mask&surface_mask], bins=nbins)
	hists = np.rot90(hists)
	hists = np.flipud(hists)
	hists_masked = np.ma.masked_where(hists==0,hists)
	fig = plt.figure()
	plt.clf()
	if z1 == -200 or z1 == 190: colormax = 300
	elif z1 == -190 or z1 == 10: colormax = 130
	elif z1 == -10 or z1 == -1: colormax = 120
	else: colormax = 160
	plt.pcolormesh(xedges, yedges, hists_masked, vmax=colormax)
	plt.xlabel('x')
	plt.ylabel('y')
	cbar = plt.colorbar()
	cbar.ax.set_ylabel('Counts')
	plt.savefig('surfaceplots/alpha_surf_%3.1f_to_%3.1f.png'%(z1,z2))
	plt.close(fig)



'''
#plt.figure(5); plt.clf(); ax = plt.gca(); Rn_nsc = np.array([bulk_data.scE[c[0]] for c in bcg]); Po_nsc = np.array([bulk_data.scE[c[1]] for c in bcg]); ax.plot(Rn_z, Rn_nsc, 'ro', markersize=4,label='Rn222'); ax.plot(Po_z, Po_nsc, 'ko', markersize=4,label='Po218'); ax.plot(Rn_z[~v_test], Rn_nsc[~v_test], 'co', markersize=4,label='Rn222_issues'); ax.plot(Po_z[~v_test], Po_nsc[~v_test], 'bo', markersize=4,label='Po218_issues'); plt.ylim(25000, 55000); plt.legend(); plt.savefig('alphaplots/scEvszRnPo_v.png'); plt.show()

#plt.figure(5); plt.clf(); ax = plt.gca(); Rn_scE_ml = np.array([bulk_data.scE_ml[c[0]] for c in bcg]); Po_scE_ml = np.array([bulk_data.scE_ml[c[1]] for c in bcg]); ax.plot(Rn_z, Rn_scE_ml, 'ro', markersize=4,label='Rn222'); ax.plot(Po_z, Po_scE_ml, 'ko', markersize=4,label='Po218'); ax.plot(Rn_z[misordered], Rn_scE_ml[misordered], 'co', markersize=4,label='misordered Rn222'); ax.plot(Po_z[misordered], Po_scE_ml[misordered], 'bo', markersize=4,label='misordered Po218'); plt.ylim(25000, 55000); plt.legend(); plt.savefig('alphaplots/scE_mlvszRnPo_misordered.png'); plt.show()



#dt vs v
#plt.figure(1); plt.clf(); ax = plt.gca(); tpc1 = np.array([bulk_data.z[c[0]] > 0. for c in bcg]); tpc2 = np.array([bulk_data.z[c[0]] < 0. for c in bcg]); ax.scatter(v[tpc1], dt[tpc1], s=10, c='k', marker='o',edgecolors='none',label='TPC1'); ax.scatter(v[tpc2],dt[tpc2], s=10, c='r', marker='o',edgecolors='none',label='TPC2'); plt.xlim(-1,3); plt.ylim (0, dt.max()); plt.grid (); plt.xlabel(r'$v \textrm{\small{( mm/s)}}$'); plt.ylabel(r'$\Delta t$'); plt.legend(); plt.savefig('alphaplots/dt_vs_v.png'); plt.show()

#cut on dt
#dt_cut = np.array([np.abs(bulk_data.z[c[0]])/2.5 for c in bcg]); dt_mask = dt<dt_cut; plt.figure(3); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(v[dt_mask], bins = 80, range = (-1.0,3.0)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post',color='k'); plt.xlabel(r'$v \textrm{mm/s}$'); plt.ylabel(r'${}^{218}\textrm{Po}$'); index = (0.5 < xhist) & (xhist < 2.5); xi = xhist[index]; xp = np.sort(np.r_[0.5, xi, xi, 2.5]); yp = yhist[np.searchsorted(xhist, np.sort(np.r_[0.5, 0.5, xi, xi]))]; ax.fill_between(xp, 0, yp, color='blue', alpha = 0.5); bin_centers = bins[:-1] + 0.5 * np.diff(bins); ax.errorbar(bin_centers, hist, yerr=np.sqrt(hist), linestyle='none', capsize=0, color='b'); plt.savefig('alphaplots/vel_dt_cut.png'); plt.show()





#maskU = np.array([np.abs(bulk_data.u[c[1]]-bulk_data.u[c[0]]) for c in bcg]) <= 9.; maskV1 = np.array([bulk_data.v[c[0]] != -999.0 for c in bcg]); maskV2 = np.array([bulk_data.v[c[1]] != -999.0 for c in bcg]); maskR = np.array([np.sqrt((bulk_data.x[c[0]]-bulk_data.x[c[1]])**2+(bulk_data.y[c[0]]-bulk_data.y[c[1]])**2) < 30. for c in bcg]); reco_mask = (np.array([bulk_data.x[c[0]]!=-999. for c in bcg]))&(np.array([bulk_data.x[c[1]]!=-999. for c in bcg])); maskRml = np.array([np.sqrt((bulk_data.x_ml[c[0]]-bulk_data.x_ml[c[1]])**2+(bulk_data.y_ml[c[0]]-bulk_data.y_ml[c[1]])**2) < 30. for c in bcg]); 

# z position histogram with subplots

#ends_bulk, no_an, tef, v_mask = all_masks(data,cg); mask = no_an & tef & v_mask; b_ends_bulk, b_no_an, b_tef, b_v_mask = all_masks(bulk_data,bcg); bulk_mask = b_no_an & b_tef & b_v_mask; zRn = np.array([np.array([bulk_data.z[c[0]] for c in bcg])[bulk_mask], np.array([data.z[c[0]] for c in cg])[mask]]); zPo = np.array([np.array([bulk_data.z[c[1]] for c in bcg])[bulk_mask], np.array([data.z[c[1]] for c in cg])[mask]]); plt.rcParams['xtick.labelsize'] = 20; plt.rcParams['ytick.labelsize'] = 20; fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2,figsize=(18,18)); fig.suptitle('R>170, |z|<172, v>0.5', fontsize=50); hist, bins = np.histogram(zRn[0], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax1.plot(xhist, yhist, drawstyle='steps-post'); ax1.set_title('Bulk, Rn-222', fontsize=30); hist, bins = np.histogram(zPo[0], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax2.plot(xhist, yhist, drawstyle='steps-post'); ax2.set_title('Bulk, Po-218', fontsize=30); hist, bins = np.histogram(zRn[1], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax3.plot(xhist, yhist, drawstyle='steps-post'); ax3.set_title('Bulk + Surfaces, Rn-222', fontsize=30); hist, bins = np.histogram(zPo[1], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax4.plot(xhist, yhist, drawstyle='steps-post'); ax4.set_title('Bulk+Surfaces, Po-218', fontsize=30); plt.savefig('zpos_R>170_tef_no_an_v_mask.png')

#ends_bulk, no_an, tef, v_mask = all_masks(data,cg); mask = tef; b_ends_bulk, b_no_an, b_tef, b_v_mask = all_masks(bulk_data,bcg); bulk_mask = b_tef; zRn = np.array([np.array([bulk_data.z[c[0]] for c in bcg])[bulk_mask], np.array([data.z[c[0]] for c in cg])[mask]]); zPo = np.array([np.array([bulk_data.z[c[1]] for c in bcg])[bulk_mask], np.array([data.z[c[1]] for c in cg])[mask]]); plt.rcParams['xtick.labelsize'] = 20; plt.rcParams['ytick.labelsize'] = 20; fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2,figsize=(18,18)); fig.suptitle('R>170', fontsize=50); hist, bins = np.histogram(zRn[0], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax1.plot(xhist, yhist, drawstyle='steps-post'); ax1.set_title('Bulk, Rn-222', fontsize=30); hist, bins = np.histogram(zPo[0], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax2.plot(xhist, yhist, drawstyle='steps-post'); ax2.set_title('Bulk, Po-218', fontsize=30); hist, bins = np.histogram(zRn[1], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax3.plot(xhist, yhist, drawstyle='steps-post'); ax3.set_title('Bulk + Surfaces, Rn-222', fontsize=30); hist, bins = np.histogram(zPo[1], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax4.plot(xhist, yhist, drawstyle='steps-post'); ax4.set_title('Bulk+Surfaces, Po-218', fontsize=30); plt.savefig('zpos_R>170_tef_mask.png')

#ends_bulk, no_an, tef, v_mask = all_masks(data,cg); mask = no_an & tef; b_ends_bulk, b_no_an, b_tef, b_v_mask = all_masks(bulk_data,bcg); bulk_mask = b_no_an & b_tef; zRn = np.array([np.array([bulk_data.z[c[0]] for c in bcg])[bulk_mask], np.array([data.z[c[0]] for c in cg])[mask]]); zPo = np.array([np.array([bulk_data.z[c[1]] for c in bcg])[bulk_mask], np.array([data.z[c[1]] for c in cg])[mask]]); plt.rcParams['xtick.labelsize'] = 20; plt.rcParams['ytick.labelsize'] = 20; fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2,figsize=(18,18)); fig.suptitle('R>170, |z|<172', fontsize=50); hist, bins = np.histogram(zRn[0], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax1.plot(xhist, yhist, drawstyle='steps-post'); ax1.set_title('Bulk, Rn-222', fontsize=30); hist, bins = np.histogram(zPo[0], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax2.plot(xhist, yhist, drawstyle='steps-post'); ax2.set_title('Bulk, Po-218', fontsize=30); hist, bins = np.histogram(zRn[1], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax3.plot(xhist, yhist, drawstyle='steps-post'); ax3.set_title('Bulk + Surfaces, Rn-222', fontsize=30); hist, bins = np.histogram(zPo[1], bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax4.plot(xhist, yhist, drawstyle='steps-post'); ax4.set_title('Bulk+Surfaces, Po-218', fontsize=30); plt.savefig('zpos_R>170_tef_no_an_mask.png')

#ends_bulk, no_an, tef, v_mask = all_masks(data,cg); mask_z = (20 <= np.abs(data.z)) & (np.abs(data.z) <= 172); mask = no_an & tef; zRn = np.array([data.z[c[0]] for c in cg])[mask]; zPo = np.array([data.z[c[1]] for c in cg])[mask]; plt.rcParams['xtick.labelsize'] = 20; plt.rcParams['ytick.labelsize'] = 20; fig, (ax1, ax2) = plt.subplots(1, 2, sharey=True, figsize=(18,9)); fig.suptitle('R>170, 20<|z|<172', fontsize=50); hist, bins = np.histogram(zRn, bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax1.plot(xhist, yhist, drawstyle='steps-post'); ax1.set_title('Surfaces, Rn-222', fontsize=30); hist, bins = np.histogram(zPo, bins = 80, range=(-200,200)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax2.plot(xhist, yhist, drawstyle='steps-post'); ax2.set_title('Surfaces, Po-218', fontsize=30); plt.savefig('zpos_R>170_tef_no_an_no_bulk_mask.png')


#plot for cc vs nsc
#R = (np.sqrt(data.x**2 + data.y**2)); mask_R = (170 < R) & (R < 1400); mask_z = (20 <= np.abs(data.z)) & (np.abs(data.z) <= 172); hist, xbins, ybins = np.histogram2d(data.ccE[mask_R], data.nsc[mask_R], bins=(200,200), range=((0,600),(0,70000))); hist = np.rot90(hist); hist = np.flipud(hist); hist_masked = np.ma.masked_where(hist==0,hist); hist_log = np.log10(hist_masked); plt.clf(); fig1 = plt.figure(1, figsize=(8,6)); plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log)); plt.xlabel('Purity corrected charge energy (keV)'); plt.ylabel('Corrected Scintillation counts'); cbar = plt.colorbar(); cbar.ax.set_ylabel('Counts'); plt.savefig('cc_vs_nsc_teflon_events.png'); 

#hist, xbins, ybins = np.histogram2d(data.ccE[data.x!=-999.], data.scE[data.x!=-999.], bins=(200,200), range=((0,600),(0,70000))); hist = np.rot90(hist); hist = np.flipud(hist); hist_masked = np.ma.masked_where(hist==0,hist); hist_log = np.log10(hist_masked); plt.clf(); fig1 = plt.figure(1, figsize=(8,6)); plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log)); plt.xlabel('Purity corrected charge energy (keV)'); plt.ylabel('Corrected Scintillation counts'); cbar = plt.colorbar(); cbar.ax.set_ylabel('Counts'); plt.show();



