#!/usr/bin/env python
import cPickle
import numpy as np
import sys
import datetime
import math

## At SLAC
#import ROOT
#ROOT.gSystem.Load("libEXOUtilities")
#ROOT.gROOT.SetStyle("Plain")
#ROOT.gROOT.SetBatch(1)
#ROOT.gStyle.SetPalette(1)
#ROOT.gStyle.SetOptStat("ne")

## At home
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn import tree #DecisionTreeRegressor
from sklearn import cross_validation
from sklearn.ensemble import AdaBoostRegressor # boosted DTR

norm = np.array([1.,1.,200./50000.]) 

#### Boundaries to be considered Rn or Po ####
zmin = 20 # mm - will remove this for surfaces
zmax = 172 # mm - will remove this for surfaces
nscounts_bulk_min = 28000
nscounts_bulk_max = 50000
ccE_max = 210 # RnPo, excludes Po-214 (from sc vs cc plot)
rmax = 180 # mm
#### Coincidence time window ####
time_min = 0
time_max = 900 # change this for multiple lifetimes
#### Spatial cut ####
delta_UV = 9 # mm (also check to see how to change this) 
#### For the fair matching, max drift speed ####
drift_speed_max = 2.5 # m/s

def main(argv):
	## ./RnPocoincidence.py, then: 

	## build noML.pkl
	if 'build' in argv[1]:
		candidate_list(argv[2])

	## split noML.pkl
	if 'split' in argv[1]:
		split(argv[2])

	## DTR (automatically takes in from split.pkl)
	if 'DTR' in argv[1]:
		train_DTR(argv[2])

	# ada (automatically takes in from split.pkl)
	if 'ada' in argv[1]:
		train_ada(argv[2])

	## redoplots picklewithML.pkl
	if 'redoplots' in argv[1]:
		redoplots(argv[2])

	## recon
	if 'recon' in argv[1]:
		recon_data()

	## locations
	if 'locations' in argv[1]:
		locations()

	if 'coinc' in argv[1]:
		coincidences()
		
#### Determine if the event is Rn-222, Po-218, or neither ####
def candidate_list(outputpicklename):
	afile = ROOT.TFile.Open("alpha_runs.root","r")
	t = afile.Get("tree")
	num = t.GetEntries()
	candidates = np.zeros(9)
	apd_data = np.zeros(76)

	for i in range(num):
		if i %int(num/10) == 0:
			print "%d of %d"%(i,num)
		t.GetEntry(i)
		ed = t.EventBranch
		alpha = onescint(ed)
#		alpha = RnPo(ed)
		if alpha is not None:	
			candidates = np.vstack((candidates,np.array([alpha[:-1]])))
			apd_data = np.vstack((apd_data, alpha[-1]))

	candidates = candidates[1:]
	apd_data = apd_data[1:]
	args = np.argsort(candidates[:,0])
	candidates_sorted = candidates[args]
	apd_data_sorted = apd_data[args]
	data = {}
	data['candidates'] = candidates_sorted
	data['apd_data'] = apd_data_sorted

	print "Found %d alpha candidates"%len(candidates)
	cPickle.dump(data, open('%s'%outputpicklename,'w'))

def onescint(ed):
	if not ed.GetNumScintillationClusters() == 1: return None
	sc = ed.GetScintillationCluster(0)
	nscounts = sc.GetCountsSumOnAPDPlane(0) + sc.GetCountsSumOnAPDPlane(1)
	cc = sc.GetChargeClusterAt(0)
	if cc: return None

	x, y, z, u, v, ccE = -999., -999., -999., -999., -999., -999.
	apd_data = np.zeros(226-150,dtype='float32')
	apd_data[0] = sc.GetCountsOnAPDPlane(0)
	apd_data[1] = sc.GetCountsOnAPDPlane(1)
	napd = sc.GetNumAPDSignals()
	for j in range(napd):
		sig = sc.GetAPDSignalAt(j)
		if sig.fChannel < 3: continue
		apd_data[sig.fChannel-150] = sig.fRawCounts

	time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.

	return (time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, apd_data)

def RnPo(ed):
	## one scintillation cluster
	if not ed.GetNumScintillationClusters() == 1: return None
	sc = ed.GetScintillationCluster(0)
	## one charge cluster
	if not sc.GetNumChargeClusters() == 1: return None
	cc = sc.GetChargeClusterAt(0)
	ccE = cc.fPurityCorrectedEnergy
	nscounts = sc.GetCountsSumOnAPDPlane(0) + sc.GetCountsSumOnAPDPlane(1)
	'''
	## cut to remove betas
	if sc.fRawEnergy == 0:
		if float(nscounts)/float(ccE) < 33.864: return None
	else:
		if float(sc.fRawEnergy)/float(ccE) < 33.864: return None
	'''
	#### to see if this matches with what Brian got ####
	#### later we will use only the ML criteria ####
#	if nscounts < nscounts_bulk_min or nscounts > nscounts_bulk_max: return None
#	if abs(cc.fZ) < zmin or abs(cc.fZ) > zmax: return None
#	if ccE > ccE_max: return None

	#### These are the candidate events ####
	time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.
	purity_data = get_purity_data()
	pur = calc_purity_datetime(purity_data,datetime.datetime.utcfromtimestamp(time)) #[TPC1,TPC2]
	x, y, z, u, v = cc.fX, cc.fY, cc.fZ, cc.fU, cc.fV

	apd_data = np.zeros(226-150,dtype='float32')
	apd_data[0] = sc.GetCountsOnAPDPlane(0)
	apd_data[1] = sc.GetCountsOnAPDPlane(1)
	napd = sc.GetNumAPDSignals()
	for j in range(napd):
		sig = sc.GetAPDSignalAt(j)
		if sig.fChannel < 3: continue
		apd_data[sig.fChannel-150] = sig.fRawCounts

	return (time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, apd_data)

def split(inputpicklename):
	print "Loading input pickle."
	data = cPickle.load(open("%s"%inputpicklename,'r'))
	print "Input pickle loaded."

	## training and testing sets. all events in this training have been fully reconstructed and therefore have full x, y, z positions
	## input for DTR 
	apd_data = data['apd_data']
	idx0 = data['candidates'][:,5]!=0 ## where sc.fRawEnergy is NOT equal to 0, that is, where events are reconstructed
	apd_data_recon = apd_data[idx0] #APD signals for reco'd events
	z_train = np.array([data['candidates'][:,3][idx0]]).T
	U_train = np.array([data['candidates'][:,7][idx0]]).T
	training_input = np.hstack((apd_data_recon,z_train,U_train))

	## output for DTR - x, y, scE
	training_out = np.array([data['candidates'][:,1][idx0], data['candidates'][:,2][idx0], data['candidates'][:,5][idx0]]).T*norm

	## split training and test sets
	in_train, in_test, out_train, out_test = cross_validation.train_test_split(training_input, training_out, test_size = 0.3)

	## Dictionary for if we want to access this later without running the split again
	split = {}
	split['in_train'] = in_train
	split['out_train'] = out_train
	split['in_test'] = in_test
	split['out_test'] = out_test

	cPickle.dump(split,open('split.pkl','w'))
	
def train_DTR(outputpicklename):
	print "Loading input pickle."
	data = cPickle.load(open('split.pkl','r'))

#	in_train, out_train, in_test, out_test = data['in_train'][:,2:], data['out_train'], data['in_test'][:,2:], data['out_test']
	## train only on APD signals
	in_train = data['in_train'][:,2:76]
	in_test = data['in_test'][:,2:76]

	## z is also a target - x, y, scE, z
	out_train = np.array([data['out_train'][:,0], data['out_train'][:,1], data['out_train'][:,2], data['in_train'][:,76]]).T
	out_test = np.array([data['out_test'][:,0], data['out_test'][:,1], data['out_test'][:,2], data['in_test'][:,76]]).T

	dtr = tree.DecisionTreeRegressor()
	dtr_dict = {} 

	## fit on the training set, put in dictionary
	print "Fitting."
	dtr_dict['dtrfit'] = dtr.fit(in_train, out_train)

	## predict training set - should have a score of very close to 1, if not 1
	print "Predicting training set."
	dtr_dict['ML_out_train'] = dtr.predict(in_train)

	## predict on test set
	print "Predicting test set."
	dtr_dict['ML_out_test'] = dtr.predict(in_test)	

	## get scores
	dtr_dict['train_score'] = dtr.score(in_train, out_train)
	dtr_dict['test_score'] = dtr.score(in_test, out_test)

	## Making pickle of differences
	print "Pickling output."

	## something like "RnPo_training.pkl" to suggest that this is where the ML training has happened
	cPickle.dump(dtr_dict,open('%s'%outputpicklename,'w'))

	## Check the position differences between the ML reco'd positions and normally reco'd positions
#	print "Sending output pickle to plottings differences function."
#	plot_diffs(out_train, dtr_dict['ML_out_train'], 'train_APDs_only')
#	plot_diffs(out_test, dtr_dict['ML_out_test'], 'test_APDs_only')
#	print "Done with difference plots."
'''
	## Show that light map correction is already taken into account with the machine learning.
	print "E vs z plots."
	plotEvsz(in_train[:,76], out_train[:,2], 'trainE_trainz') # training E vs training z
	plotEvsz(in_train[:,76], dtr_dict['ML_out_train'][:,2], 'trainE_MLz') # ML E vs training
	plotEvsz(in_test[:,76], out_test[:,2], 'testE_testz') # testing E vs testing z
	plotEvsz(in_test[:,76], dtr_dict['ML_out_test'][:,2], 'testE_MLz') # ML E vs testing z

	# Visualize the data within the detector, also getting histograms in slices of z.
	print "3d position plots and histograms."
	positionplot(out_train[:,0], out_train[:,1], in_train[:,76], 'trainxy')
	positionplot(dtr_dict['ML_out_train'][:,0], dtr_dict['ML_out_train'][:,1], in_train[:,76], 'trainMLxy')
	positionplot(out_test[:,0], out_test[:,1], in_test[:,76], 'testxy')
	positionplot(dtr_dict['ML_out_test'][:,0], dtr_dict['ML_out_test'][:,1], in_test[:,76], 'testMLxy')
'''
def train_ada(outputpicklename):
	## keep same train/test split as DTR for comparison
	print "Opening split.pkl"
	with open('split.pkl','rb') as f: data = cPickle.load(f)

#	in_train, in_test = data['in_train'][:,2:], data['in_test'][:,2:]
	## train only on APD signals
	in_train = data['in_train'][:,2:76]
	in_test = data['in_test'][:,2:76]

	## targets - remove z when training on z
	x_train = data['out_train'][:,0]
	x_test = data['out_test'][:,0]
	y_train = data['out_train'][:,1]
	y_test = data['out_test'][:,1]
	scE_train = data['out_train'][:,2]
	scE_test = data['out_test'][:,2]
	z_train = data['in_train'][:,76]
	z_test = data['in_test'][:,76]

	ada_dict = {}
	'''
	print "x fitting"
	dtrx = tree.DecisionTreeRegressor()
	adax = AdaBoostRegressor(dtrx, n_estimators = 100)

	ada_dict['ada_xfit'] = adax.fit(in_train, x_train)
	print "x predicting"
	ada_dict['ML_x_train'] = adax.predict(in_train)
	ada_dict['ML_x_test'] = adax.predict(in_test)
	ada_dict['x_train_score'] = adax.score(in_train, x_train)
	ada_dict['x_test_score'] = adax.score(in_test, x_test)
	print "x test score is", ada_dict['x_test_score']
	print "Dumping to pickle"
	cPickle.dump(ada_dict,open('%s'%outputpicklename,'w'))
	'''
	'''
	print "y fitting"
	dtry = tree.DecisionTreeRegressor()
	aday = AdaBoostRegressor(dtry, n_estimators = 100)

	ada_dict['ada_yfit'] = aday.fit(in_train, y_train)
	print "y predicting"
	ada_dict['ML_y_train'] = aday.predict(in_train)
	ada_dict['ML_y_test'] = aday.predict(in_test)
	ada_dict['y_train_score'] = aday.score(in_train, y_train)
	ada_dict['y_test_score'] = aday.score(in_test, y_test)
	print "y test score is", ada_dict['y_test_score']
	print "Dumping to pickle"
	cPickle.dump(ada_dict,open('%s'%outputpicklename,'w'))
	'''

	'''
	print "scE fitting"
	dtre = tree.DecisionTreeRegressor()
	adae = AdaBoostRegressor(dtre, n_estimators = 100)

	ada_dict['ada_scEfit'] = adae.fit(in_train, scE_train)
	print "scE predicting"
	ada_dict['ML_scE_train'] = adae.predict(in_train)
	ada_dict['ML_scE_test'] = adae.predict(in_test)
	ada_dict['scE_train_score'] = adae.score(in_train, scE_train)
	ada_dict['scE_test_score'] = adae.score(in_test, scE_test)
	print "scE test score is", ada_dict['scE_test_score']
	print "Dumping to pickle"
	cPickle.dump(ada_dict,open('%s'%outputpicklename,'w'))
	'''
	
	print "z fitting"
	dtrz = tree.DecisionTreeRegressor()
	adaz = AdaBoostRegressor(dtrz, n_estimators = 100)

	ada_dict['ada_zfit'] = adaz.fit(in_train, z_train)
	print "z predicting"
	ada_dict['ML_z_train'] = adaz.predict(in_train)
	ada_dict['ML_z_test'] = adaz.predict(in_test)
	ada_dict['z_train_score'] = adaz.score(in_train, z_train)
	ada_dict['z_test_score'] = adaz.score(in_test, z_test)
	print "z test score is", ada_dict['z_test_score']

	print "Dumping to pickle"
	cPickle.dump(ada_dict,open('%s'%outputpicklename,'w'))
	

	'''
	train_plot = np.array([x_train, y_train, scE_train, z_train]).T
	test_plot = np.array([x_test, y_test, scE_test, z_test]).T
	ML_train_plot = np.array([ada_dict['ML_x_train'], ada_dict['ML_y_train'], ada_dict['ML_scE_train'], ada_dict['ML_z_train']]).T
	ML_test_plot = np.array([ada_dict['ML_x_test'], ada_dict['ML_y_test'], ada_dict['ML_scE_test'], ada_dict['ML_z_test']]).T
	ML_test_plot = np.array([ada_dict['ML_x_test'], ada_dict['ML_y_te	st'], ada_dict['ML_scE_test']]).T

	print "Sending to plotting code" 
	plot_diffs(train_plot, ML_train_plot, 'train_APDs_only')
	plot_diffs(test_plot, ML_test_plot, 'test_APDs_only')

	plotEvsz(in_train[:,76], out_train[:,2], 'trainE_trainz') # training E vs training z
	plotEvsz(in_train[:,76], ada_dict['ML_out_train'][:,2], 'trainE_MLz') # ML E vs training
	plotEvsz(in_test[:,76], out_test[:,2], 'testE_testz') # testing E vs testing z
	plotEvsz(in_test[:,76], ada_dict['ML_out_test'][:,2], 'testE_MLz') # ML E vs testing z

	positionplot(out_train[:,0], out_train[:,1], in_train[:,76], 'trainxy')
	positionplot(ada_dict['ML_out_train'][:,0], ada_dict['ML_out_train'][:,1], in_train[:,76], 'trainMLxy')
	positionplot(out_test[:,0], out_test[:,1], in_test[:,76], 'testxy')
	positionplot(ada_dict['ML_out_test'][:,0], ada_dict['ML_out_test'][:,1], in_test[:,76], 'testMLxy')
'''
def redoplots_dtr(inputpicklename):
	with open('%s'%inputpicklename, 'rb') as f: newdict = cPickle.load(f)
	with open('split.pkl', 'rb') as f: data = cPickle.load(f)

	## for alpha analysis
	in_train, out_train, in_test, out_test = data['in_train'][:,2:], data['out_train'], data['in_test'][:,2:], data['out_test']
	
	plot_diffs(out_train, newdict['ML_out_train'], 'train')
	plot_diffs(out_test, newdict['ML_out_test'], 'test')
	'''
	## for APDs only
	out_train = np.array([data['out_train'][:,0], data['out_train'][:,1], data['out_train'][:,2], data['in_train'][:,76]]).T
	out_test = np.array([data['out_test'][:,0], data['out_test'][:,1], data['out_test'][:,2], data['in_test'][:,76]]).T

	plot_diffs(out_train, newdict['ML_out_train'], 'train_APDs_only')
	plot_diffs(out_test, newdict['ML_out_test'], 'test_APDs_only')
	'''

	'''
	DTR_training = cPickle.load(open('%s'%inputpicklename,'r'))

	plot_diffs(DTR_training['out_train'], DTR_training['ML_out_train'], 'train')
	plot_diffs(DTR_training['out_test'], DTR_training['ML_out_test'], 'test')
	
	plotEvsz(DTR_training['in_train'][:,76], DTR_training['out_train'][:,2], 'trainE_trainz') # training E vs training z
	plotEvsz(DTR_training['in_train'][:,76], DTR_training['ML_out_train'][:,2], 'MLE_trainz') # ML E vs training
	plotEvsz(DTR_training['in_test'][:,76], DTR_training['out_test'][:,2], 'testE_testz') # testing E vs testing z
	plotEvsz(DTR_training['in_test'][:,76], DTR_training['ML_out_test'][:,2], 'MLE_trainz') # ML E vs testing z

	positionplot(DTR_training['out_train'][:,0], DTR_training['out_train'][:,1], DTR_training['in_train'][:,76], 'trainxy')
	positionplot(DTR_training['ML_out_train'][:,0], DTR_training['ML_out_train'][:,1], DTR_training['in_train'][:,76], 'trainMLxy')
	positionplot(DTR_training['out_test'][:,0], DTR_training['out_test'][:,1], DTR_training['in_test'][:,76], 'testxy')
	positionplot(DTR_training['ML_out_test'][:,0], DTR_training['ML_out_test'][:,1], DTR_training['in_test'][:,76], 'testMLxy')
	'''
def plotEvsz(z,E,name):
	E_vs_z = plt.figure(figsize=(6,4))
	plt.clf()
	H, xedges, yedges = np.histogram2d(z,E/norm[2],bins=(200,200),range=((-200,200),(0,100000)))
	H = np.rot90(H)
	H = np.flipud(H)	
	H2 = np.ma.masked_where(H==0,H)
	H3 = np.log(H2)	
	plt.pcolormesh(xedges,yedges,H3)
	plt.xlabel('Z pos (mm)')
	plt.ylabel('fRawEnergy (LM corrected)')
	#plt.title('E vs z for %s set'%name)
	plt.savefig('RnPo_candidates_%s_e_vs_z.png'%name,dpi=300)
	plt.close(E_vs_z)
	print "Finished E vs z plot"

def positionplot(x, y, z, name):	
	pos_3d = plt.figure(figsize=(6,4))
	ax = pos_3d.add_subplot(111, projection='3d')
	ax.scatter(x/norm[0],y/norm[1],z, s=2, lw=0)
	ax.set_xlabel('cc.fX')
	ax.set_ylabel('cc.fY')
	ax.set_zlabel('cc.fZ')
	ax.set_xlim([-200,200])
	ax.set_ylim([-200,200])
	ax.set_zlim([-200,200])
	plt.savefig('RnPo_candidates_%s_3d_pos.png'%name,dpi=300)
	plt.close(pos_3d)	
 	print "Finished 3d position plot."
	
	print "Histograms, z slices."
	z_edges = np.array([-200, -190, -10, -1, 0, 1, 10, 190, 200])

	event_x = x/norm[0]
	event_y = y/norm[1]

	nbins = 20
	for (z1, z2) in zip(z_edges[:-1], z_edges[1:]):
		mask = (z1 <= z) & (z < z2)
		# make a 2D histogram with event_xs[mask] and event_ys[mask]

		hists, xedges, yedges = np.histogram2d(event_x[mask], event_y[mask], bins=nbins)
		hists = np.rot90(hists)
		hists = np.flipud(hists)
		hists_masked = np.ma.masked_where(hists==0,hists)

		fig = plt.figure(figsize=(6,4))
		if z1 == -200 or z1 == 190: colormax = 100
		elif z1 == -190 or z1 == 10: colormax = 40
		else: colormax = 80
		plt.pcolormesh(xedges, yedges, hists_masked, vmax = colormax)
		plt.xlabel('cc.fX')
		plt.ylabel('cc.fY')
		cbar = plt.colorbar()
		cbar.ax.set_ylabel('Counts')
		plt.savefig('RnPo_candidates_%s_%3.1f_to_%3.1f.png' %(name,z1,z2),dpi=300)
		plt.close(fig)

	print "Histograms, the walls."
	zplot = z[np.sqrt(x**2 + y**2) >= 180.0]
	hist, bins = np.histogram(zplot, bins=80, range = (-200,200))
	fig = plt.figure(figsize=(6,4))
	xhist, yhist = bins, np.r_[hist,hist[-1]]
	ax = plt.gca()
	ax.plot(xhist,yhist,drawstyle='steps-post')
	plt.xlabel('Z')
	plt.ylabel('Events')
	plt.title('Events with R >= 180')
	plt.savefig('RnPo_candidates_%s_wall_hist.png'%name,dpi=300)
	plt.close(fig)
	

def plot_diffs(out, ML_out, name):
	diff = out - ML_out

	## plot differences
	print "Plotting differences."
	nbins = 201
	pos = np.array(['x','y','scE'])
	std = np.sqrt(sum((diff/norm)**2)/(len(diff)-1))

#	pos = np.array(['x','y','scE', 'z'])
#	norm_with_z = np.array([1.,1.,200./50000., 1.])
#	std = np.sqrt(sum((diff/norm_with_z)**2)/(len(diff)-1))
	
	print std

	for idx, i in enumerate(pos):
		fig = plt.figure(figsize=(16,8))
		plt.clf()
		ax = plt.gca()

		if not idx == 2: hist, bins = np.histogram(diff[:,idx],bins=nbins,range=(-100,100))
		else: hist, bins = np.histogram(diff[:,idx]/norm[idx],nbins,(-10000,10000))

		x, y = bins, np.r_[hist,hist[-1]]
		ax.plot(x, y, drawstyle='steps-post')		
		index = (-std[idx] < x) & (x < std[idx])
		xi = x[index]
		xp = np.sort(np.r_[-std[idx], xi, xi, std[idx]])
		yp = y[np.searchsorted(x, np.sort(np.r_[-std[idx], -std[idx], xi, xi]))] 	
		ax.fill_between(xp, 0, yp, color='blue', alpha = 0.5)
		locs, labels = plt.xticks()
		plt.setp(labels, rotation=90)
		if not idx == 2: plt.title("%s difference (mm)"%i)
		else: plt.title("%s difference (APD counts)"%i)
		plt.savefig("RnPo_candidates_%s_%s_difference.png"%(name, i))
	plt.clf()

def recon_data():
	print "Loading data pickle."
	with open('onescnocc.pkl','r') as f:
		data = cPickle.load(f)
	print "Finished loading data pickle."
	is0 = data['candidates'][:,5]==0
	apd_data = data['apd_data'][is0]

	z = np.array([data['candidates'][:,3][is0]]).T
	U = np.array([data['candidates'][:,7][is0]]).T
#	MLinput = np.hstack((apd_data,z,U))
	MLinput = apd_data # for no cc studies 

	print "Loading pickle with fit."
	with open('ada100/ada100_APDs_only.pkl','r') as f:
		fit = cPickle.load(f)
	print "Finished loading pickle with fit."
#	dtr = fit['dtrfit']
	xfit = fit['ada_xfit']
	yfit = fit['ada_yfit']
	scEfit = fit['ada_scEfit']
	zfit = fit['ada_zfit']

	print "Predicting x"
	MLout_x = xfit.predict(MLinput)

	print "Predicting y"
	MLout_y = yfit.predict(MLinput)
	
	print "Predicting scE"
	MLout_scE = scEfit.predict(MLinput)/norm[2]

	print "Predicting z"
	MLout_z = zfit.predict(MLinput)

	
#	MLout = dtr.predict(MLinput)/norm

#	positionplot(MLout[:,0], MLout[:,1], data['candidates'][:,3][is0],'unreco_ML')
#	positionplot(MLout_x, MLout_y, data['candidates'][:,3][is0],'unreco_ML')

	datawithML = {}
	
	print "Futzing with arrays"
	## adding in the machine learned candidates to the original list of data
	tempcandidates = data['candidates'].copy()
	tempX = tempcandidates[:,1]
	tempY = tempcandidates[:,2]
	tempscE = tempcandidates[:,5]
	tempZ = tempcandidates[:,3]

#	tempX[is0] = MLout[:,0]
#	tempY[is0] = MLout[:,1]  
#	tempscE[is0] = MLout[:,2]
#	tempZ[is0] = MLout[:,3]

	tempX[is0] = MLout_x
	tempY[is0] = MLout_y
	tempscE[is0] = MLout_scE
	tempZ[is0] = MLout_z

	finalX = np.column_stack(tempX).T
	finalY = np.column_stack(tempY).T
	finalscE = np.column_stack(tempscE).T
	finalZ = np.column_stack(tempZ).T

#	candidates = np.hstack((data['candidates'],finalX,finalY,finalscE))
	candidates = np.hstack((data['candidates'], finalX, finalY, finalscE, finalZ))
	datawithML['candidates'] = candidates
	datawithML['apd_data'] = apd_data

#	positionplot(candidates[:,9], candidates[:,10], candidates[:,3], 'reco+MLunreco')
#	plotEvsz(candidates[:,3], candidates[:,11], 'reco+MLunreco')

	print "Writing out to new pickle."
	cPickle.dump(datawithML,open('onescnocc_with_ada100_position.pkl','w'))

def locations():
	data = cPickle.load(open('RnPo_all_candidates_with_ML_position.pkl','r'))
	candidates = data['candidates']
	z = candidates[:,3]
	nscounts = candidates[:,4]
	scE = candidates[:,5]
	ccE = candidates[:,6]
	is0 = candidates[:,5]==0

	linebreak = 37500

#	mask_betas = (nscounts >= (80*ccE)-15000)
	## FIX BULK CUT
	bulk = (ccE>ccE_max) & ((z<zmin) | (z>zmax)) & ((nscounts < nscounts_bulk_min) | (nscounts > nscounts_bulk_max))
	mask_surface = ((ccE <= 300) & (nscounts <= (51.667*ccE)+22000)) | ((ccE > 300) & (nscounts < (110.0*ccE)+ 4500))
	notPo214 = (nscounts <= (51.667*ccE)+22000) & (nscounts <= (-100*ccE)+70000) & (ccE<410)
	cathode = (abs(z) <= 20.0) & mask_surface & notPo214
	anode1 = (z<=200.) & (z>=172.) & mask_surface & notPo214
	anode2 = (z>=-200.) & (z<=-172.) & mask_surface & notPo214
	wall1 = (z<172.) & (z>20.) & mask_surface & notPo214
	wall2 = (z>-172.) & (z<-20.) & mask_surface & notPo214
	total_RnPo_surface = mask_surface & notPo214

	print "Cathode", sum(cathode)
	print "Anode1", sum(anode1)
	print "anode2", sum(anode2)
	print "wall1", sum(wall1)
	print "wall2", sum(wall2)
	print "total", sum(total_RnPo_surface)

	hist, bins = np.histogram(z[np.array(total_RnPo_surface)], bins=80, range = (-200,200))
	fig = plt.figure(figsize=(6,4))
	xhist, yhist = bins, np.r_[hist,hist[-1]]
	ax = plt.gca()
	ax.plot(xhist,yhist,drawstyle='steps-post')
	plt.xlabel('Z')
	plt.ylabel('Events')
	plt.title('Event locations in the middle blob on the nsc vs ccE plot')
#	plt.savefig('RnPo_candidates_surface_hist.png',dpi=300)
	plt.close(fig)	

def scEvsccE(nscounts, scE, ccE, MLscE):
	
	hist, xbins, ybins = np.histogram2d(ccE, nscounts, bins=(200,200), range=((0,600),(0,70000)))
	hist = np.rot90(hist)
	hist = np.flipud(hist)
	hist_masked = np.ma.masked_where(hist==0,hist)
	hist_log = np.log10(hist_masked)

	fig1 = plt.figure(figsize=(8,6))
	plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log))
	plt.xlabel('Purity corrected charge energy')
	plt.ylabel('Scintillation counts')
	cbar = plt.colorbar()
	cbar.ax.set_ylabel('Counts')
	fig1.savefig('RnPo_all_candidates_nscounts_vs_ccE.png')
	plt.close(fig1)

	hist, xbins, ybins = np.histogram2d(ccE, scE, bins=(200,200), range=((0,600),(0,70000)))
	hist = np.rot90(hist)
	hist = np.flipud(hist)
	hist_masked = np.ma.masked_where(hist==0,hist)
	hist_log2 = np.log10(hist_masked)

	fig2 = plt.figure(figsize=(8,6))
	plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log))
	plt.xlabel('Purity corrected charge energy')
	plt.ylabel('Light map corrected scintillation energy')
	cbar = plt.colorbar()
	cbar.ax.set_ylabel('Counts')
	fig2.savefig('RnPo_all_candidates_scE_vs_ccE.png')
	plt.close(fig2)

	hist, xbins, ybins = np.histogram2d(ccE, MLscE, bins=(200,200), range=((0,600),(0,70000)))
	hist = np.rot90(hist)
	hist = np.flipud(hist)
	hist_masked = np.ma.masked_where(hist==0,hist)
	hist_log2 = np.log10(hist_masked)

	fig3 = plt.figure(figsize=(8,6))
	plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log))
	plt.xlabel('Purity corrected charge energy')
	plt.ylabel('Light map corrected scintillation energy')
	cbar = plt.colorbar()
	cbar.ax.set_ylabel('Counts')
	plt.savefig('RnPo_all_candidates_with_ML_scE_vs_ccE.png')
	plt.close(fig3)

def coincidences():
	a = cPickle.load(open('RnPo_all_candidates_with_ML_position.pkl','r'))

	coincidences_nov = []
	coincidences_nov_fid = []
	coincidences_nov_fair = []
	coincidences_nov_fid_fair = []
	coincidences_onev = []
	coincidences_onev_fid = []
	coincidences_onev_nonfid = []
	coincidences_onev_fid_fair = []
	coincidences_onev_nonfid_fair = []

	# Fully reconstructed
	coincidences_rec = []
	coincidences_rec_fid = []
	coincidences_rec_fid_fair = []
	coincidences_rec_nonfid = []
	coincidences_rec_nonfid_fair = []
	# False coincidences (of NoV) using fully reconstructed events
	coincidences_not_within_R = []
	# Ambiguous matches (only checked for TPC and U-wire)
	ambiguous_matches = []

	# ML matches
	coincidences_rec_ML = []
	coincidences_onev_ML = []
	coincidences_nov_ML = []

	## cuts
	candidates = a['candidates']	
	z = candidates[:,3]
	nscounts = candidates[:,4]
	scE = candidates[:,5]
	ccE = candidates[:,6]
	is0 = candidates[:,5]==0
	bulk = (ccE>ccE_max) & ((z<zmin) | (z>zmax)) & ((nscounts < nscounts_bulk_min) | (nscounts > nscounts_bulk_max))
	mask_surface = ((ccE <= 300) & (nscounts <= (51.667*ccE)+22000)) | ((ccE > 300) & (nscounts < (110.0*ccE)+ 4500))
	notPo214 = (nscounts <= (51.667*ccE)+22000) & (nscounts <= (-100*ccE)+70000) & (ccE<410)
	surface = mask_surface & notPo214


	# Keep track of the number of times each Rn event is matched
	nov_matches = np.zeros(len(a['candidates']))
	onev_matches = np.zeros(len(a['candidates']))
	rec_matches = np.zeros(len(a['candidates']))
	matched = np.zeros(len(a['candidates']))

	#time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, MLx, MLy, MLz, MLscE
	#Primary loop over list of events
	for i,item1 in enumerate(a['candidates'][bulk|surface][:-1]):
		matching_events = []
		for item2 in a['candidates'][bulk|surface][i+1:]:
			# Perform time difference check
			dt =  item2[0] - item1[0]
			if dt > time_max: # Ordered list, so no point in continuing
				break
			if dt < time_min: # so item1 is first in time (Rn) and item2 follows (Po)
				continue
			# If it passes the time cuts, is it also in the SAME TPC? and same U-Wire?
			# Otherwise it's not a candidate for matching
#			if abs(item1[7]-item2[7]) <= delta_UV and item1[3]/item2[3] > 0:
			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0 and item1[3]/item2[3] > 0:
				matching_events.append(item2)
		if len(matching_events) > 1:
			# This should prevent ambigious events from being used
			matched[i] = len(matching_events)
			for item2 in matching_events:
				ambiguous_matches.append((item1,item2))
			continue
		if len(matching_events) == 0:
			# There are no matching candidates
			continue

		# Unambiguous matches only have one Po candidate
		item2 = matching_events[0]
		matched[i] = 1

		# Both are not fully recon (NoV)
		if item1[8] == -999.0 and item2[8] == -999.0: 
			nov_matches[i]+=1
			# items are nov coincidence candidates
			coincidences_nov.append((item1,item2))
			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_nov_ML.append((item1, item2))

		# Only one item is fully reconstructed (oneV)
		if (item1[8] == -999.0 and not item2[8] == -999.0) or (not item1[8] == -999.0 and item2[8] == -999.0): 
			onev_matches[i]+=1
			coincidences_onev.append((item1,item2))

			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_onev_ML.append((item1, item2))

		# Both are fully reconstructed
		elif not item1[8] == -999.0 and not item2[8] == -999.0:
			if abs(item1[8]-item2[8]) <= delta_UV: 
				#V-wire matches as well
				rec_matches[i]+=1
				coincidences_rec.append((item1,item2))
			if not abs(item1[8]-item2[8]) <= delta_UV:
				# we want to check the efficiency of finding false coincidences using these
				coincidences_not_within_R.append((item1,item2))
#			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
#				coincidences_rec_ML.append((item1, item2))

	# Save coincidences found in dictionary for later if needed
	data = {}
	data['matched'] = matched
	data['coincidences_nov'] = coincidences_nov
	data['coincidences_onev'] = coincidences_onev
	data['coincidences_rec'] = coincidences_rec
	data['rec_matches'] = rec_matches
	data['nov_matches'] = nov_matches
	data['onev_matches'] = onev_matches
	data['ambiguous_matches'] = ambiguous_matches
	data['coincidences_not_within_R'] = coincidences_not_within_R
	# ML coincidences
	data['coincidences_rec_ML'] = coincidences_rec_ML
	data['coincidences_onev_ML'] = coincidences_onev_ML
	data['coincidences_nov_ML'] = coincidences_nov_ML

	cPickle.dump(data, open('RnPo_bulk+surface_t900_R_req_coincidence_candidates.pkl','w'))

def coincidences1():
	a = cPickle.load(open('RnPo_all_candidates_with_ML_position.pkl','r'))

	coincidences_nov = []
	coincidences_nov_fid = []
	coincidences_nov_fair = []
	coincidences_nov_fid_fair = []
	coincidences_onev = []
	coincidences_onev_fid = []
	coincidences_onev_nonfid = []
	coincidences_onev_fid_fair = []
	coincidences_onev_nonfid_fair = []

	# Fully reconstructed
	coincidences_rec = []
	coincidences_rec_fid = []
	coincidences_rec_fid_fair = []
	coincidences_rec_nonfid = []
	coincidences_rec_nonfid_fair = []
	# False coincidences (of NoV) using fully reconstructed events
	coincidences_not_within_R = []
	# Ambiguous matches (only checked for TPC and U-wire)
	ambiguous_matches = []

	# ML matches
	coincidences_rec_ML = []
	coincidences_onev_ML = []
	coincidences_nov_ML = []

	## cuts
	candidates = a['candidates']	
	z = candidates[:,3]
	nscounts = candidates[:,4]
	scE = candidates[:,5]
	ccE = candidates[:,6]
	is0 = candidates[:,5]==0
	isbulk = (ccE<ccE_max) & ((z>zmin) & (z<zmax)) & ((nscounts > nscounts_bulk_min) & (nscounts < nscounts_bulk_max))
	mask_surface = ((ccE <= 300) & (nscounts <= (51.667*ccE)+22000)) | ((ccE > 300) & (nscounts < (110.0*ccE)+ 4500))
	notPo214 = (nscounts <= (51.667*ccE)+22000) & (nscounts <= (-100*ccE)+70000) & (ccE<410)
	surface = mask_surface & notPo214


	# Keep track of the number of times each Rn event is matched
	nov_matches = np.zeros(len(a['candidates']))
	onev_matches = np.zeros(len(a['candidates']))
	rec_matches = np.zeros(len(a['candidates']))
	matched = np.zeros(len(a['candidates']))

	#time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, MLx, MLy, MLz, MLscE
	#Primary loop over list of events
	for i,item1 in enumerate(a['candidates'][bulk|surface][:-1]):
		matching_events = []
		for item2 in a['candidates'][bulk|surface][i+1:]:
			# Perform time difference check
			dt =  item2[0] - item1[0]
			if dt > time_max: # Ordered list, so no point in continuing
				break
			if dt < time_min: # so item1 is first in time (Rn) and item2 follows (Po)
				continue
			# If it passes the time cuts, is it also in the SAME TPC? and same U-Wire?
			# Otherwise it's not a candidate for matching
			if abs(item1[7]-item2[7]) <= delta_UV and item1[3]/item2[3] > 0:
				matching_events.append(item2)
		if len(matching_events) > 1:
			# This should prevent ambigious events from being used
			matched[i] = len(matching_events)
			for item2 in matching_events:
				ambiguous_matches.append((item1,item2))
			continue
		if len(matching_events) == 0:
			# There are no matching candidates
			continue

		# Unambiguous matches only have one Po candidate
		item2 = matching_events[0]
		matched[i] = 1

		# Both are not fully recon (NoV)
		if item1[8] == -999.0 and item2[8] == -999.0: 
			nov_matches[i]+=1
			# items are nov coincidence candidates
			coincidences_nov.append((item1,item2))
			if abs(item1[7]) < rmax and abs(item2[7]) < rmax:
				coincidences_nov_fid.append((item1,item2))
			# Fair Matching
			if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
				coincidences_nov_fair.append((item1,item2))
				if abs(item1[7]) < rmax and abs(item2[7]) < rmax:
					coincidences_nov_fid_fair.append((item1,item2))
			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_nov_ML.append((item1, item2))

		# Only one item is fully reconstructed (oneV)
		if (item1[8] == -999.0 and not item2[8] == -999.0) or (not item1[8] == -999.0 and item2[8] == -999.0): 
			onev_matches[i]+=1
			coincidences_onev.append((item1,item2))

			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_onev_ML.append((item1, item2))

			#Get the item with a fully recon position
			if not item1[8] == -999.0: 
				onev_pos = item1
			else:
				onev_pos = item2

			# Check if that position is in the fiducial volume defined by rmax
			## will get rid of this when we include surface events
			if (onev_pos[1]**2.+onev_pos[2]**2.)**0.5 < rmax:
				coincidences_onev_fid.append((item1,item2))
			else:
				coincidences_onev_nonfid.append((item1,item2))

			# Fair Matching
			if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
				# Check if that position is in the fiducial volume defined by rmax
				if (onev_pos[1]**2.+onev_pos[2]**2.)**0.5 < rmax:
					coincidences_onev_fid_fair.append((item1,item2))
				else:
					coincidences_onev_nonfid_fair.append((item1,item2))

		# Both are fully reconstructed
		elif not item1[8] == -999.0 and not item2[8] == -999.0:
			if abs(item1[8]-item2[8]) <= delta_UV: 
				#V-wire matches as well
				rec_matches[i]+=1
				coincidences_rec.append((item1,item2))
				if (item1[1]**2.+item1[2]**2)**0.5 < rmax and (item2[1]**2.+item2[2]**2)**0.5 < rmax:
					# Both are in the FID
					coincidences_rec_fid.append((item1,item2))
					# Fair Matching
					if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
						coincidences_rec_fid_fair.append((item1,item2))
				else:
					# One or more is outside the FID
					coincidences_rec_nonfid.append((item1,item2))
					# Fair Matching
					if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
						coincidences_rec_nonfid_fair.append((item1,item2))
			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_rec_ML.append((item1, item2))

			else: 
				# we want to check the efficiency of finding false coincidences using these
				coincidences_not_within_R.append((item1,item2))
    
    
	# Save coincidences found in dictionary for later if needed
	data = {}
	data['matched'] = matched
	data['coincidences_nov'] = coincidences_nov
	#data['coincidences_nov_fair'] = coincidences_nov_fair
	#data['coincidences_nov_fid'] = coincidences_nov_fid
	#data['coincidences_nov_fid_fair'] = coincidences_nov_fid_fair
	data['coincidences_onev'] = coincidences_onev
	#data['coincidences_onev_fid'] = coincidences_onev_fid
	#data['coincidences_onev_nonfid'] = coincidences_onev_nonfid
	#data['coincidences_onev_fid_fair'] = coincidences_onev_fid_fair
	#data['coincidences_onev_nonfid_fair'] = coincidences_onev_nonfid_fair
	data['coincidences_rec'] = coincidences_rec
	#data['coincidences_rec_fid'] = coincidences_rec_fid
	#data['coincidences_rec_fid_fair'] = coincidences_rec_fid_fair
	#data['coincidences_rec_nonfid'] = coincidences_rec_fid
	#data['coincidences_rec_nonfid_fair'] = coincidences_rec_fid_fair
	data['rec_matches'] = rec_matches
	data['nov_matches'] = nov_matches
	data['onev_matches'] = onev_matches
	data['ambiguous_matches'] = ambiguous_matches
	data['coincidences_not_within_R'] = coincidences_not_within_R
	# ML coincidences
	data['coincidences_rec_ML'] = coincidences_rec_ML
	data['coincidences_onev_ML'] = coincidences_onev_ML
	data['coincidences_nov_ML'] = coincidences_nov_ML


	print "Done finding coincidences"
	purity_data = get_purity_data()
	data['purity_data'] = purity_data
	#data['parms'] = {'zmin':zmin, 'zmax':zmax, 'rmax':rmax, 'sce_min':sce_min, 'sce_max':sce_max,\
	#				 'time_min':time_min, 'time_max':time_max, 'delta_UV':delta_UV,\
	#				 'drift_speed_max':drift_speed_max}
	cPickle.dump(data, open('RnPo_bulk+surface_t=180_coincidence_candidates.pkl','w'))
	#return data


#### purity information, from Brian's Build_AlphaIon_Data ####
def get_purity_data():
    """
    Returns dictionary with TPC1,TPC2 as keys. In each dictionary is a list of the entries
    in the calib-table used for the 0-nu anlaysis. In this list is a dictionary with all the 
    info for the table, and it gets the actual parameters from the electron-lifetime table 
    that correspond to those entries.
    """
    import MySQLdb
    import MySQLdb.cursors
    import datetime
    data ={'TPC1':[],'TPC2':[]} # Container for purity structure
    db = MySQLdb.connect("mysql-node03.slac.stanford.edu","rd_exo_cond_ro","w0rking.St1fff!","rd_exo_cond",cursorclass=MySQLdb.cursors.DictCursor)
    cursor = db.cursor()
    cursor.execute("SELECT * FROM conditions WHERE calib_type='a-el-life' AND flavor='TPC1_2013_0nu'")
    tpc1 = cursor.fetchall()
    cursor.execute("SELECT * FROM conditions WHERE calib_type='a-el-life' AND flavor='TPC2_2013_0nu'")
    tpc2 = cursor.fetchall()
    for i in tpc1:
        data['TPC1'].append({})
        for k in i.keys():
            data['TPC1'][-1][k] = i[k]
        calib_key = int(i['data_ident'].split(':')[2])
        cursor.execute("SELECT * from ateam_electron_lifetime WHERE calib_key=%d"%calib_key)
        parms = cursor.fetchall()
        for k in parms[0].keys(): 
            data['TPC1'][-1][k] = parms[0][k] 
    for i in tpc2:
        data['TPC2'].append({})
        for k in i.keys():
            data['TPC2'][-1][k] = i[k]
        calib_key = int(i['data_ident'].split(':')[2])
        cursor.execute("SELECT * from ateam_electron_lifetime WHERE calib_key=%d"%calib_key)
        parms = cursor.fetchall()
        for k in parms[0].keys(): 
            data['TPC2'][-1][k] = parms[0][k] 
    return data

def calc_purity_datetime(purity_data,thistime):
    """
    Useage: calc_purity_datetime(purity_data,thistime)
    This takes UTC time and purity data structure to return purity values as [TPC1,TPC2]
    If it returns None, then the TPC does not have a valid purity for that time
    """
    if thistime.tzinfo != None:
        tmp = thistime.astimezone(pytz.UTC)
        thistime = thistime.replace(tzinfo=None)
    purity = [None,None]
    for tpc1_pp in purity_data['TPC1']:
        if thistime > tpc1_pp['vstart'] and thistime < tpc1_pp['vend']:
            # Found the valid TPC1 data point
            purity[0] = tpc1_pp
            break
    for tpc2_pp in purity_data['TPC2']:
        if thistime > tpc2_pp['vstart'] and thistime < tpc2_pp['vend']:
            # Found the valid TPC1 data point
            purity[1] = tpc2_pp
            break
    for itpc in range(2):
        if purity[itpc] == None:
            continue
        #if purity[itpc]['p1'] == 0:
        #    print itpc,"vstart=",purity[itpc]['vstart'],purity[itpc]['p0'],purity[itpc]['p1']
        t = (thistime - datetime.datetime.fromtimestamp(purity[itpc]['origin'])).total_seconds()/3600./24.
        purity[itpc] = purity[itpc]['p0'] + purity[itpc]['p1']*t + purity[itpc]['p2']*(t**2.) + purity[itpc]['p3']*(t**3.)\
                        + purity[itpc]['p4']*(t**4.) + purity[itpc]['p5']*(t**5.) + purity[itpc]['p6']*(t**6.)
    return purity

if __name__ == '__main__':
    main(sys.argv)

