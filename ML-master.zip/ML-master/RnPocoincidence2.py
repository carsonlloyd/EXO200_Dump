#!/usr/bin/env python
import cPickle as pickle
import numpy as np
import sys
import datetime
import math
import sys
from scipy.optimize import curve_fit
import matplotlib as mpl

## At SLAC
#import ROOT
#ROOT.gSystem.Load("libEXOUtilities")
#ROOT.gROOT.SetStyle("Plain")
#ROOT.gROOT.SetBatch(1)
#ROOT.gStyle.SetPalette(1)
#ROOT.gStyle.SetOptStat("ne")

## At home
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn import tree #DecisionTreeRegressor
from sklearn import cross_validation
from sklearn.ensemble import AdaBoostRegressor # boosted DTR
plt.rc('text',usetex=True)

norm = np.array([1.,1.,200./50000.]) 

#### Boundaries to be considered Rn or Po ####
zmin = 20 # mm - will remove this for surfaces
zmax = 172 # mm - will remove this for surfaces
nscounts_bulk_min = 28000
nscounts_bulk_max = 50000
ccE_max = 210 # RnPo, excludes Po-214 (from sc vs cc plot)
rmax = 180 # mm
#### Coincidence time window ####
time_min = 0
time_max = 900 # change this for multiple lifetimes
#### Spatial cut ####
delta_UV = 9 # mm (also check to see how to change this) 
#### For the fair matching, max drift speed ####
drift_speed_max = 2.5 # m/s

def candidate_list(outputpicklename):
	afile = ROOT.TFile.Open("alpha_runs.root","r")
	t = afile.Get("tree")
	num = t.GetEntries()
	candidates = np.zeros(9)
	apd_data = np.zeros(76)

	for i in range(num):
		if i %int(num/10) == 0:
			print "%d of %d"%(i,num)
		t.GetEntry(i)
		ed = t.EventBranch
		alpha = onescint(ed)
#		alpha = RnPo(ed)
		if alpha is not None:	
			candidates = np.vstack((candidates,np.array([alpha[:-1]])))
			apd_data = np.vstack((apd_data, alpha[-1]))

	candidates = candidates[1:]
	apd_data = apd_data[1:]
	args = np.argsort(candidates[:,0])
	candidates_sorted = candidates[args]
	apd_data_sorted = apd_data[args]
	data = {}
	data['candidates'] = candidates_sorted
	data['apd_data'] = apd_data_sorted

	print "Found %d alpha candidates"%len(candidates)
	with open('%s'%outputpicklename, 'wb') as f: pickle.dump(data, f, -1)

def onescint(ed):
	if not ed.GetNumScintillationClusters() == 1: return None
	sc = ed.GetScintillationCluster(0)
	nscounts = sc.GetCountsSumOnAPDPlane(0) + sc.GetCountsSumOnAPDPlane(1)
	cc = sc.GetChargeClusterAt(0)
	if cc: return None

	x, y, z, u, v, ccE = -999., -999., -999., -999., -999., -999.
	apd_data = np.zeros(226-150,dtype='float32')
	apd_data[0] = sc.GetCountsOnAPDPlane(0)
	apd_data[1] = sc.GetCountsOnAPDPlane(1)
	napd = sc.GetNumAPDSignals()
	for j in range(napd):
		sig = sc.GetAPDSignalAt(j)
		if sig.fChannel < 3: continue
		apd_data[sig.fChannel-150] = sig.fRawCounts

	time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.

	return (time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, apd_data)

def RnPo(ed):
	## one scintillation cluster
	if not ed.GetNumScintillationClusters() == 1: return None
	sc = ed.GetScintillationCluster(0)
	## one charge cluster
	if not sc.GetNumChargeClusters() == 1: return None
	cc = sc.GetChargeClusterAt(0)
	ccE = cc.fPurityCorrectedEnergy
	nscounts = sc.GetCountsSumOnAPDPlane(0) + sc.GetCountsSumOnAPDPlane(1)
	'''
	## cut to remove betas
	if sc.fRawEnergy == 0:
		if float(nscounts)/float(ccE) < 33.864: return None
	else:
		if float(sc.fRawEnergy)/float(ccE) < 33.864: return None
	'''
	#### to see if this matches with what Brian got ####
	#### later we will use only the ML criteria ####
#	if nscounts < nscounts_bulk_min or nscounts > nscounts_bulk_max: return None
#	if abs(cc.fZ) < zmin or abs(cc.fZ) > zmax: return None
#	if ccE > ccE_max: return None

	#### These are the candidate events ####
	time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.
	purity_data = get_purity_data()
	pur = calc_purity_datetime(purity_data,datetime.datetime.utcfromtimestamp(time)) #[TPC1,TPC2]
	x, y, z, u, v = cc.fX, cc.fY, cc.fZ, cc.fU, cc.fV

	apd_data = np.zeros(226-150,dtype='float32')
	apd_data[0] = sc.GetCountsOnAPDPlane(0)
	apd_data[1] = sc.GetCountsOnAPDPlane(1)
	napd = sc.GetNumAPDSignals()
	for j in range(napd):
		sig = sc.GetAPDSignalAt(j)
		if sig.fChannel < 3: continue
		apd_data[sig.fChannel-150] = sig.fRawCounts

	return (time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, apd_data)

def split(inputpicklename):
	print "Loading input pickle."
	with open('%s'%inputpicklename, 'rb') as f: data = pickle.load(f)
	print "Input pickle loaded."

	## training and testing sets. all events in this training have been fully reconstructed and therefore have full x, y, z positions

	## input for DTR 
	apd_data = data['apd_data']
	idx0 = data['candidates'][:,5]!=0 ## reco'd events only
	apd_data_recon = apd_data[idx0] #APD signals for reco'd events
	z_train = np.array([data['candidates'][:,3][idx0]]).T
	U_train = np.array([data['candidates'][:,7][idx0]]).T
	training_input = np.hstack((apd_data_recon,z_train,U_train))

	## output for DTR - x, y, scE
	training_out = np.array([data['candidates'][:,1][idx0], data['candidates'][:,2][idx0], data['candidates'][:,5][idx0]]).T*norm

	## split training and test sets
	in_train, in_test, out_train, out_test = cross_validation.train_test_split(training_input, training_out, test_size = 0.3)

	## Dictionary for later access
	split = {}
	split['in_train'] = in_train
	split['out_train'] = out_train
	split['in_test'] = in_test
	split['out_test'] = out_test

	with open('split.pkl', 'wb') as f: pickle.dump(split, f, -1)

def train_DTR_for_alphas():
	print "Loading input pickle."
	with open('split.pkl', 'rb') as f: data = pickle.load(f)

	## train on APD signals, U-wire signal, z-position
	in_train, out_train, in_test, out_test = data['in_train'][:,2:], data['out_train'], data['in_test'][:,2:], data['out_test']

	dtr = tree.DecisionTreeRegressor()
	dtr_dict = {} 

	## fit on the training set, put in dictionary
	print "Fitting."
	dtr_dict['dtrfit'] = dtr.fit(in_train, out_train)

	## predict training set - should have a score of very close to 1, if not 1
	print "Predicting training set."
	dtr_dict['ML_out_train'] = dtr.predict(in_train)

	## predict on test set
	print "Predicting test set."
	dtr_dict['ML_out_test'] = dtr.predict(in_test)	

	## get scores
	dtr_dict['train_score'] = dtr.score(in_train, out_train)
	dtr_dict['test_score'] = dtr.score(in_test, out_test)

	## Making pickle of differences
	print "Pickling output."
	with open('DTR_defaults.pkl', 'wb') as f: pickle.dump(dtr_dict, f, -1)

def train_DTR_for_surfaces():
	print "Loading input pickle."
	with open('split.pkl', 'rb') as f: data = pickle.load(f)

	## train only on APD signals
	in_train = data['in_train'][:,2:76]
	in_test = data['in_test'][:,2:76]

	## z is also a target - x, y, scE, z
	out_train = np.array([data['out_train'][:,0], data['out_train'][:,1], data['out_train'][:,2], data['in_train'][:,76]]).T
	out_test = np.array([data['out_test'][:,0], data['out_test'][:,1], data['out_test'][:,2], data['in_test'][:,76]]).T

	dtr = tree.DecisionTreeRegressor()
	dtr_dict = {} 

	## fit on the training set, put in dictionary
	print "Fitting."
	dtr_dict['dtrfit'] = dtr.fit(in_train, out_train)

	## predict training set
	print "Predicting training set."
	dtr_dict['ML_out_train'] = dtr.predict(in_train)

	## predict on test set
	print "Predicting test set."
	dtr_dict['ML_out_test'] = dtr.predict(in_test)	

	## get scores
	dtr_dict['train_score'] = dtr.score(in_train, out_train)
	dtr_dict['test_score'] = dtr.score(in_test, out_test)

	## Making pickle of differences
	print "Pickling output."
	with open('DTR_defaults_APDs_only.pkl', 'wb') as f: pickle.dump(dtr_dict, f, -1)

def get_fit(in_train, out_train, in_test, out_test):
	out = {}
	ada = AdaBoostRegressor(tree.DecisionTreeRegressor(), n_estimators = 100)
	out['fit'] = ada.fit(in_train, out_train)
	out['ML_out_train'] = ada.predict(in_train)
	out['ML_out_test'] = ada.predict(out_train)
	out['score_train'] = ada.score(in_train, out_train)
	out['score_test'] = ada.score(in_test, out_test)

def train_ada_for_alphas():
	## keep same train/test split as DTR for comparison
	print "Opening split.pkl"
	with open('split.pkl','rb') as f: data = pickle.load(f)

	in_train, in_test = data['in_train'][:,2:], data['in_test'][:,2:]

	## targets - remove z when training on z
	x_train = data['out_train'][:,0]
	x_test = data['out_test'][:,0]
	y_train = data['out_train'][:,1]
	y_test = data['out_test'][:,1]
	scE_train = data['out_train'][:,2]
	scE_test = data['out_test'][:,2]

	ada_dict['x'] = get_fit(in_train, x_train, in_test, x_test)
	ada_dict['y'] = get_fit(in_train, y_train, in_test, y_test)
	ada_dict['scE'] = get_fit(in_train, scE_train, in_test, scE_test)
	
	with open('ada100.pkl', 'wb') as f: pickle.dump(ada_dict, f, -1)

def train_ada_for_surfaces():
	## keep same train/test split as DTR for comparison
	print "Opening split.pkl"
	with open('split.pkl','rb') as f: data = pickle.load(f)

	## train only on APD signals
	in_train = data['in_train'][:,2:76]
	in_test = data['in_test'][:,2:76]

	## targets - separate for ada
	x_train = data['out_train'][:,0]
	x_test = data['out_test'][:,0]
	y_train = data['out_train'][:,1]
	y_test = data['out_test'][:,1]
	scE_train = data['out_train'][:,2]
	scE_test = data['out_test'][:,2]
	z_train = data['in_train'][:,76]
	z_test = data['in_test'][:,76]

	ada_dict['x'] = get_fit(in_train, x_train, in_test, x_test)
	ada_dict['y'] = get_fit(in_train, y_train, in_test, y_test)
	ada_dict['scE'] = get_fit(in_train, scE_train, in_test, scE_test)
	ada_dict['z'] = get_fit(in_train, z_train, in_test, z_test)

def prep_for_diffs(inputpickle):
	with open('%s'%inputpickle, 'rb') as f: newdict = pickle.load(f)
	with open('split.pkl', 'rb') as f: data = pickle.load(f)

	ml_type = inputpickle[:3]

	## surface
	if 'APD' in inputpickle:
		analysis_type = 'surface'
		pos = np.array(['x','y','scE', 'z'])
		plot_norm = np.array([1.,1.,200./50000., 1.])
		if 'ols' or 'DTR' in inputpickle: 		
			reco_train = np.array([data['out_train'][:,0], data['out_train'][:,1], data['out_train'][:,2], data['in_train'][:,76]]).T
			reco_test = np.array([data['out_test'][:,0], data['out_test'][:,1], data['out_test'][:,2], data['in_test'][:,76]]).T
			ML_train = newdict['ML_out_train']
			ML_test = newdict['ML_out_test']
			g = [2, 2, 2, 2]

		elif 'ada' in inputpickle:
			reco_train = np.array([data['out_train'][:,0], data['out_train'][:,1], data['out_train'][:,2], data['in_train'][:,76]]).T
			reco_test = np.array([data['out_test'][:,0], data['out_test'][:,1], data['out_test'][:,2], data['in_test'][:,76]]).T
			ML_train = np.array([newdict['ML_x_train'], newdict['ML_y_train'], newdict['ML_scE_train'], newdict['ML_z_train']]).T
			ML_test = np.array([newdict['ML_x_test'], newdict['ML_y_test'], newdict['ML_scE_test'], newdict['ML_z_test']]).T	
			g = [2, 2, 2, 2]

	## alphas 
	if not 'APD' in inputpickle:
		analysis_type = 'alpha'
		pos = np.array(['x','y','scE'])
		plot_norm = norm
		if 'ols' or 'DTR' in inputpickle:
			reco_train, reco_test = data['out_train'], data['out_test']
			ML_train, ML_test = newdict['ML_out_train'], newdict['ML_out_test']
			g = [2, 2, 2, 2]

		elif 'ada' in inputpickle:
			reco_train = np.array([data['out_train'][:,0], data['out_train'][:,1], data['out_train'][:,2]]).T
			reco_test = np.array([data['out_test'][:,0], data['out_test'][:,1], data['out_test'][:,2]]).T
			ML_train = np.array([newdict['ML_x_train'], newdict['ML_y_train'], newdict['ML_scE_train']]).T
			ML_test = np.array([newdict['ML_x_test'], newdict['ML_y_test'], newdict['ML_scE_test']]).T
			g = [2, 2, 2, 2]

	return reco_train, reco_test, ML_train, ML_test, ml_type, analysis_type, g, pos, plot_norm

def gauss(x, *p):
	A, mu, sigma = p
	return A*np.exp(-(x-mu)**2/(2.*sigma**2))

def laplacian(x, *p):
	A, sigma = p
	val = A*np.exp(-np.abs(x) / sigma)
	return val

def gauss_sum(x, *p):
	n = len(p)/3
	A = p[:n]
	mu = p[n:2*n]
	sigma = p[2*n:3*n]
	y = sum([A[i]*np.exp(-(x-mu[i])**2/(2.*sigma[i]**2)) for i in range(n)])
	return y

def gauss_normed(x, *p):
	w1, sigma1, sigma2 = p
	w2 = 1 - w1
	g = lambda x, s: 1/(s*np.sqrt(2*np.pi)) * np.exp(-x**2/(2.*s**2))
	return w1 * g(x, sigma1) + w2 * g(x, sigma2)

def gauss_1_normed(x, sigma):
	g = lambda x, s: 1./(s*np.sqrt(2.*np.pi)) * np.exp(-x**2/(2.*s**2))
	return g(x, sigma)

def make_hist(x, hist_range, idx, g):
	nbins = [21, 21, 21, 101] 
	hist, bins = np.histogram(x, bins = nbins[idx], range = hist_range)
	hist_norm = np.sum(hist*np.diff(bins))
	hist = hist / hist_norm
	x, y = bins, np.r_[hist,hist[-1]]
	x_fit = bins[:-1] + 0.5 * np.diff(bins)	
	gauss_plot = np.linspace(x.min(), x.max(), 200)
	yerr = np.sqrt(hist/hist_norm)


#####################
	sigma1 = np.array([x.max()/7.5, x.max()/8., x.max()/5.5, x.max()/30.])
	sigma2 = np.array([x.max()/2.5, x.max()/2.5, x.max()/1.5, x.max()/4.])
	w1 = (np.array([7*y.max()/8., 9*y.max()/8., 5.5*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi));
#####################

	if g == 1: p0 = sigma1
	else: p0 = np.vstack((w1, sigma1, sigma2)).T

	if g == 1: 
		coeff, var_matrix = curve_fit(gauss_1_normed, x_fit, hist, p0=p0[idx], sigma = np.sqrt(hist/hist_norm))
		hist_fit = gauss_1_normed(gauss_plot, coeff)

	if g == 2: 		
		coeff, var_matrix = curve_fit(gauss_normed, x_fit, hist, p0=p0[idx], sigma = np.sqrt(hist/hist_norm))
		hist_fit = gauss_normed(gauss_plot, *coeff)

	return x, y, x_fit, hist, yerr, p0[idx], gauss_plot, hist_fit, coeff
	
def plot_diffs(out, ML_out, *kwargs):
	diff = out - ML_out
	name, ml_type, analysis_type, g, pos, plot_norm, logorreg = kwargs
	ranges = [(-100,100),(-100,100),(-50,50),(-20,20)]
	plot_things = [1., 1., out[:,2]/100., 1.]
	diff_ranges = [diff[:,idx]/plot_things[idx] for idx in range(np.shape(diff)[1])]
	xtitles = [r'$\Delta \textrm{x (mm)}$', r'$\Delta \textrm{y (mm)}$', r'$(\Delta \textrm{scE})/\textrm{scE}_\textrm{\small{EXOAnalysis}}$', r'$\Delta \textrm{z (mm)}$']

	for idx, i in enumerate(pos):
		plt.figure(1)
		ax = plt.gca()

		x, y, x_fit, hist, yerr, p0, gauss_plot, hist_fit, coeff = make_hist(diff_ranges[idx], ranges[idx], idx, g[idx])
		hist = 1.* hist
		hist[hist==0] = np.nan
		ax.plot(x, y, drawstyle='steps-post', color='b')
		ax.errorbar(x_fit, hist, yerr=yerr, linestyle='none', capsize=0, color='b')
		if g[idx] == 1: ax.plot(gauss_plot, hist_fit, label='sigma = %4.3f'%coeff[0], color='r')
		if g[idx] == 2: ax.plot(gauss_plot, hist_fit, label=r'$w_1 = %4.3f, \sigma_1 = %4.3f$'%(coeff[0], coeff[1])+'\n'+r'$w_2 = %4.3f, \sigma_2 = %4.3f$'%(1-coeff[0], coeff[2]), color='r')

		if 'log' in logorreg: 
			ax.set_yscale('log', nonposy='clip')
			factor = 10.
		else: factor = 1.2
		
		plt.xlim(ranges[idx])
		ymin = y.min()
		if ymin == 0.: ymin = np.unique(np.sort(y))[1]
		plt.ylim (ymin = ymin/10., ymax = factor*plt.ylim()[1])
		propsmall = mpl.font_manager.FontProperties(size=14)
		propsmaller = mpl.font_manager.FontProperties (size=8)
		plt.legend (prop=propsmall)

		locs, labels = plt.xticks()
		plt.setp(labels, rotation=90)
		plt.gcf().tight_layout()
		plt.gcf().subplots_adjust(bottom=0.15)
		plt.xlabel(xtitles[idx])
		plt.ylabel(r'\textrm{Counts}')
		plt.savefig('test4/%s_%s_%s_%s_%s_difference.png'%(ml_type, analysis_type, name, logorreg, i))
		plt.clf()

def plotEvsz(z,E,name):
	E_vs_z = plt.figure(figsize=(6,4))
	plt.clf()
	H, xedges, yedges = np.histogram2d(z,E/norm[2],bins=(200,200),range=((-200,200),(0,100000)))
	H = np.rot90(H)
	H = np.flipud(H)	
	H2 = np.ma.masked_where(H==0,H)
	H3 = np.log(H2)	
	plt.pcolormesh(xedges,yedges,H3)
	plt.xlabel('Z pos (mm)')
	plt.ylabel('fRawEnergy (LM corrected)')
	#plt.title('E vs z for %s set'%name)
	plt.savefig('RnPo_candidates_%s_e_vs_z.png'%name,dpi=300)
	plt.close(E_vs_z)
	print "Finished E vs z plot"

def pos3d(x, y, z, plotname):
	pos_3d = plt.figure(figsize=(6,4))
	ax = pos_3d.add_subplot(111, projection='3d')
	ax.scatter(x,y,z, s=2, lw=0)
	ax.set_xlabel('x')
	ax.set_ylabel('y')
	ax.set_zlabel('z')
	ax.set_xlim([-200,200])
	ax.set_ylim([-200,200])
	ax.set_zlim([-200,200])
	plt.savefig('alphaplots/bulk_without_z_req_locations.png')
	plt.close(pos_3d)	
 	print "Finished 3d position plot."

def z_slices(x, y, z, plotname):
	z_edges = np.array([-200, -190, -10, -1, 0, 1, 10, 190, 200])

	event_x = x/norm[0]
	event_y = y/norm[1]

	nbins = 20
	for (z1, z2) in zip(z_edges[:-1], z_edges[1:]):
		mask = (z1 <= z) & (z < z2)
		# make a 2D histogram with event_xs[mask] and event_ys[mask]

		hists, xedges, yedges = np.histogram2d(event_x[mask], event_y[mask], bins=nbins)
		hists = np.rot90(hists)
		hists = np.flipud(hists)
		hists_masked = np.ma.masked_where(hists==0,hists)

		fig = plt.figure(figsize=(6,4))
		if z1 == -200 or z1 == 190: colormax = 100
		elif z1 == -190 or z1 == 10: colormax = 40
		else: colormax = 80
		plt.pcolormesh(xedges, yedges, hists_masked, vmax = colormax)
		plt.xlabel('cc.fX')
		plt.ylabel('cc.fY')
		cbar = plt.colorbar()
		cbar.ax.set_ylabel('Counts')
		plt.savefig('%s_%3.1f_to_%3.1f.png' %(name,z1,z2))
		plt.close(fig)

def wall_hists(x, y, z, plotname):
	print "Histograms, the walls."
	zplot = z[np.sqrt(x**2 + y**2) >= 180.0]
	hist, bins = np.histogram(zplot, bins=80, range = (-200,200))
	fig = plt.figure(figsize=(6,4))
	xhist, yhist = bins, np.r_[hist,hist[-1]]
	ax = plt.gca()
	ax.plot(xhist,yhist,drawstyle='steps-post')
	plt.xlabel('Z')
	plt.ylabel('Events')
	plt.title('Events with R >= 180')
	plt.savefig('%s.png'%name)
	plt.close(fig)

def recon_alphas():
	print "Loading data pickle."
	with open('RnPo_all_candidates.pkl', 'rb') as f: data = pickle.load(f)
	print "Finished loading data pickle."

	apd_data = data['apd_data']
	z = np.array([data['candidates'][:,3]]).T
	U = np.array([data['candidates'][:,7]]).T
	MLinput = np.hstack((apd_data[:,2:], z, U))

	print "Loading pickle with fits."
	with open('ada100/ada100.pkl', 'rb') as f: fit = pickle.load(f)
	xfit = fit['ada_xfit']
	yfit = fit['ada_yfit']
	scEfit = fit['ada_scEfit']

	print "Predicting x"
	MLout_x = xfit.predict(MLinput)

	print "Predicting y"
	MLout_y = yfit.predict(MLinput)
	
	print "Predicting scE"
	MLout_scE = scEfit.predict(MLinput)/norm[2]

	datawithML = {}
	candidates = np.hstack((data['candidates'],np.column_stack(MLout_x).T, np.column_stack(MLout_y).T, np.column_stack(MLout_scE).T))
	datawithML['candidates'] = candidates
	datawithML['apd_data'] = apd_data

	print "Writing out to new pickle."
	with open('RnPo_all_candidates_with_ada100_position.pkl', 'wb') as f: pickle.dump(datawithML, f, -1)

def recon_surfaces():
	print "Loading data pickle for surfaces."
	with open('onescnocc.pkl','rb') as f: data = pickle.load(f)
	print "Finished loading data pickle."
	
	apd_data = data['apd_data']
	MLinput = apd_data[:,2:]

	print "Loading pickle with fit."
	with open('ada100/ada100_APDs_only.pkl','rb') as f:	fit = pickle.load(f)
	print "Finished loading pickle with fit."

	xfit = fit['ada_xfit']
	yfit = fit['ada_yfit']
	scEfit = fit['ada_scEfit']
	zfit = fit['ada_zfit']

	print "Predicting x"
	MLout_x = xfit.predict(MLinput)

	print "Predicting y"
	MLout_y = yfit.predict(MLinput)
	
	print "Predicting scE"
	MLout_scE = scEfit.predict(MLinput)/norm[2]

	print "Predicting z"
	MLout_z = zfit.predict(MLinput)

	datawithML = {}
	
	candidates = np.hstack((data['candidates'], np.column_stack(MLout_x).T, np.column_stack(MLout_y).T, np.column_stack(MLout_scE).T, np.column_stack(MLout_z).T))
	datawithML['candidates'] = candidates
	datawithML['apd_data'] = apd_data

	print "Writing out to new pickle."
	with open('onescnocc_with_ada100_position.pkl', 'wb') as f: pickle.dump(datawithML, f, -1)


#if __name__ == '__main__':
	#recon_surfaces()

'''
for idx, i in enumerate(pos):
	fig = plt.figure(1); ax = plt.gca();
	if not idx == 2: 
		hist, bins = np.histogram(diff[:,idx], bins = nbins, range = (-100,100));
	else: 
		hist,bins = np.histogram(diff[:,2]/reco_test[:,2]*100,nbins,range = (-50,50));

	hist_norm = np.sum(hist*np.diff(bins)); hist = hist / hist_norm;  x, y = bins, np.r_[hist,hist[-1]]; ax.plot(x, y, drawstyle='steps-post', color='b'); locs, labels = plt.xticks(); plt.setp(labels, rotation=90); x_fit = bins[:-1] + 0.5 * np.diff(bins); sigma1 = np.array([x.max()/10., x.max()/10., x.max()/8., x.max()/2.]); sigma2 = np.array([x.max()/3.75, x.max()/2., x.max()/2.4, x.max()/2.]); w1 = (np.array([6.*y.max()/8., 6.7*y.max()/8., 6.*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi)); sigma3 = np.array([x.max()/12., x.max()/12., x.max()/8., x.max()/2.]); p0 = np.vstack((w1, sigma1, sigma2)).T; coeff, var_matrix = curve_fit(gauss_1_normed, x_fit, hist, p0=sigma3[idx], sigma = np.sqrt(hist/hist_norm)); gauss_plot = np.linspace(x.min(), x.max(), 200); hist_fit = gauss_1_normed(gauss_plot, *coeff); ax.plot(gauss_plot, hist_fit, label='sigma = %4.3f'%coeff[0], color='r'); propsmall = mpl.font_manager.FontProperties(size=11); propsmaller = mpl.font_manager.FontProperties (size=8); plt.legend (prop=propsmall); ax.errorbar(x_fit, hist, yerr=np.sqrt(hist/hist_norm), linestyle='none', capsize=0, color='b');
	if not idx == 2: plt.title("%s difference (mm)"%i);
	else: plt.title("%s difference (APD counts)"%i);
	plt.savefig('test/ada_alpha_test_%s_1_gauss_difference.png'%i); plt.clf()

ax.plot(gauss_plot, hist_fit, label='w1 = %4.3f, sigma1 = %4.3f\nw2 = %4.3f, sigma2 = %4.3f'%(coeff[0], coeff[1], 1-coeff[0], coeff[2]), color='r');
if logorreg == 'log':
    factor = 10
else:
    factor = 1.2

hist_fid = hist_fid / hist_norm; hist_surf = hist_surf / hist_norm;
coeff_fid, var_matrix = curve_fit(gauss_1_normed, x_fit, hist_fid, p0=sigma1[idx], sigma = np.sqrt(hist_fid/hist_norm)); coeff_surf, var_matrix = curve_fit(gauss_1_normed, x_fit, hist_surf, p0=sigma2[idx], sigma = np.sqrt(hist_surf/hist_norm)); 

hist_fit_fid = gauss_1_normed(gauss_plot, *coeff_fid); hist_fit_surf = gauss_1_normed(gauss_plot, *coeff_surf); ax.plot(gauss_plot, hist_fit_fid, color='r',label='Bulk, 1sigma = %4.3f'%coeff_fid[0]); ax.plot(gauss_plot, hist_fit_surf, color='g', label='Surface, 1sigma = %4.3f'%coeff_surf[0]); plt.legend();
 	if not idx == 2: plt.title("%s difference (mm)"%i);
	else: plt.title("%s difference (APD counts)"%i);
	plt.savefig('test/ols_surface_train_%s_log_difference.png'%i); plt.clf()

#ax.set_ylim(ymin= 0.1*y.min());
#hist_fit = gauss_normed(gauss_plot, *coeff); ax.plot(gauss_plot, hist_fit, label='w1 = %4.3f, sigma1 = %4.3f\nw2 = %4.3f, sigma2 = %4.3f'%(coeff[0], coeff[1], 1-coeff[0], coeff[2]), color='r'); plt.legend(); ax.errorbar(x_fit, hist, yerr=np.sqrt(hist/hist_norm), linestyle='none', capsize=0, color='b');
	if not idx == 2: plt.title("%s difference (mm)"%i);
	else: plt.title("%s difference (APD counts)"%i);
	plt.savefig('ada_alpha_test_%s_difference.png'%i); plt.clf()

#ax.set_yscale('log', nonposy='clip'); 

#hist_norm = np.sum(hist*np.diff(bins)); hist = hist / hist_norm;


#ax.plot(gauss_plot, hist_fit, label='w1 = %4.3f, sigma1 = %4.3f\nw2 = %4.3f, sigma2 = %4.3f'%(coeff[0], coeff[1], 1-coeff[0], coeff[2]), color='r'); plt.legend() 

## for DTR_defaults.pkl
		sigma1 = (np.array([x.max()/7.5, x.max()/8., x.max()/3.5]))
		sigma2 = (np.array([x.max()/2.5, x.max()/2.5, x.max()/2.]))
		w1 = (np.array([7*y.max()/8., 9.*y.max()/8., 5.*y.max()/8.]))*(sigma1 * np.sqrt(2*np.pi));

## for DTR_defaults_APDs_only.pkl
#sigma1 = np.array([x.max()/7.5, x.max()/8., x.max()/3.8, x.max()/30.]); sigma2 = np.array([x.max()/3.1, x.max()/3., x.max()/1.8, x.max()/4.]); w1 = (np.array([7*y.max()/8., 7*y.max()/8., 7*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi));

## for ada100.pkl
#	sigma1 = np.array([x.max()/12., x.max()/12., x.max()/10., x.max()/2.])
	sigma2 = np.array([x.max()/3., x.max()/2., x.max()/2.4, x.max()/2.])
	w1 = (np.array([7.5*y.max()/8., 8.*y.max()/8., 7.*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi))
## for ada100_APDs_only.pkl
#		sigma1 = np.array([x.max()/7.5, x.max()/8., x.max()/5.5, x.max()/30.])
		sigma2 = np.array([x.max()/2.5, x.max()/2.5, x.max()/1.5, x.max()/4.])
		w1 = (np.array([7*y.max()/8., 9*y.max()/8., 5.5*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi));

## for OLS alpha
#train
#sigma1 = np.array([x.max()/7, x.max()/7.8, x.max()/9.5, x.max()/30.]); sigma2 = np.array([x.max()/2., x.max()/3.5, x.max()/2.4, x.max()/4.]); w1 = (np.array([6*y.max()/8., 6.*y.max()/8., 7.5*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi));
#test
		sigma1 = np.array([x.max()/7.5, x.max()/8., x.max()/9.5, x.max()/2.])
		sigma2 = np.array([x.max()/2., x.max()/3., x.max()/3., x.max()/2.])
		w1 = (np.array([4.*y.max()/8., 5.5*y.max()/8., 7.7*y.max()/8., y.max()]))*(sigma1 * np.sqrt(2*np.pi))
		p0 = np.vstack((w1, sigma1, sigma2)).T
'''
