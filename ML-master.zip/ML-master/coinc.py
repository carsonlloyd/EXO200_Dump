def coincidences():
	a = cPickle.load(open('RnPo_all_candidates_with_ML_position.pkl','r'))

	coincidences_nov = []
	coincidences_nov_fid = []
	coincidences_nov_fair = []
	coincidences_nov_fid_fair = []
	coincidences_onev = []
	coincidences_onev_fid = []
	coincidences_onev_nonfid = []
	coincidences_onev_fid_fair = []
	coincidences_onev_nonfid_fair = []

	# Fully reconstructed
	coincidences_rec = []
	coincidences_rec_fid = []
	coincidences_rec_fid_fair = []
	coincidences_rec_nonfid = []
	coincidences_rec_nonfid_fair = []
	# False coincidences (of NoV) using fully reconstructed events
	coincidences_not_within_R = []
	# Ambiguous matches (only checked for TPC and U-wire)
	ambiguous_matches = []

	# ML matches
	coincidences_rec_ML = []
	coincidences_onev_ML = []
	coincidences_nov_ML = []

	## cuts
	candidates = a['candidates']	
	z = candidates[:,3]
	nscounts = candidates[:,4]
	scE = candidates[:,5]
	ccE = candidates[:,6]
	is0 = candidates[:,5]==0
	bulk = (ccE>ccE_max) & ((z<zmin) | (z>zmax)) & ((nscounts < nscounts_bulk_min) | (nscounts > nscounts_bulk_max))
	mask_surface = ((ccE <= 300) & (nscounts <= (51.667*ccE)+22000)) | ((ccE > 300) & (nscounts < (110.0*ccE)+ 4500))
	notPo214 = (nscounts <= (51.667*ccE)+22000) & (nscounts <= (-100*ccE)+70000) & (ccE<410)
	surface = mask_surface & notPo214


	# Keep track of the number of times each Rn event is matched
	nov_matches = np.zeros(len(a['candidates']))
	onev_matches = np.zeros(len(a['candidates']))
	rec_matches = np.zeros(len(a['candidates']))
	matched = np.zeros(len(a['candidates']))

	#time, x, y, z, nscounts, sc.fRawEnergy, ccE, u, v, MLx, MLy, MLz, MLscE
	#Primary loop over list of events

	for i, item1 in enumerate(a['candidates'][bulk|surface][:-1]):
		for item2 in a['candidates'][bulk|surface][:-1]):
			match = [(item2[0] - item1[0] <= time_max) & item1[7]-item[2] <= delta_UV & item1[3]/item[2])]
				
			

	for i,item1 in enumerate(a['candidates'][bulk|surface][:-1]):
		matching_events = []
		for item2 in a['candidates'][bulk|surface][i+1:]:
			# Perform time difference check
			dt =  item2[0] - item1[0]
			if dt > time_max: # Ordered list, so no point in continuing
				break
			if dt < time_min: # so item1 is first in time (Rn) and item2 follows (Po)
				continue
			# If it passes the time cuts, is it also in the SAME TPC? and same U-Wire?
			# Otherwise it's not a candidate for matching
			if abs(item1[7]-item2[7]) <= delta_UV and item1[3]/item2[3] > 0:
				matching_events.append(item2)
		if len(matching_events) > 1:
			# This should prevent ambigious events from being used
			matched[i] = len(matching_events)
			for item2 in matching_events:
				ambiguous_matches.append((item1,item2))
			continue
		if len(matching_events) == 0:
			# There are no matching candidates
			continue

		# Unambiguous matches only have one Po candidate
		item2 = matching_events[0]
		matched[i] = 1

		# Both are not fully recon (NoV)
		if item1[8] == -999.0 and item2[8] == -999.0: 
			nov_matches[i]+=1
			# items are nov coincidence candidates
			coincidences_nov.append((item1,item2))
			if abs(item1[7]) < rmax and abs(item2[7]) < rmax:
				coincidences_nov_fid.append((item1,item2))
			# Fair Matching
			if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
				coincidences_nov_fair.append((item1,item2))
				if abs(item1[7]) < rmax and abs(item2[7]) < rmax:
					coincidences_nov_fid_fair.append((item1,item2))
			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_nov_ML.append((item1, item2))

		# Only one item is fully reconstructed (oneV)
		if (item1[8] == -999.0 and not item2[8] == -999.0) or (not item1[8] == -999.0 and item2[8] == -999.0): 
			onev_matches[i]+=1
			coincidences_onev.append((item1,item2))

			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_onev_ML.append((item1, item2))

			#Get the item with a fully recon position
			if not item1[8] == -999.0: 
				onev_pos = item1
			else:
				onev_pos = item2

			# Check if that position is in the fiducial volume defined by rmax
			## will get rid of this when we include surface events
			if (onev_pos[1]**2.+onev_pos[2]**2.)**0.5 < rmax:
				coincidences_onev_fid.append((item1,item2))
			else:
				coincidences_onev_nonfid.append((item1,item2))

			# Fair Matching
			if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
				# Check if that position is in the fiducial volume defined by rmax
				if (onev_pos[1]**2.+onev_pos[2]**2.)**0.5 < rmax:
					coincidences_onev_fid_fair.append((item1,item2))
				else:
					coincidences_onev_nonfid_fair.append((item1,item2))

		# Both are fully reconstructed
		elif not item1[8] == -999.0 and not item2[8] == -999.0:
			if abs(item1[8]-item2[8]) <= delta_UV: 
				#V-wire matches as well
				rec_matches[i]+=1
				coincidences_rec.append((item1,item2))
				if (item1[1]**2.+item1[2]**2)**0.5 < rmax and (item2[1]**2.+item2[2]**2)**0.5 < rmax:
					# Both are in the FID
					coincidences_rec_fid.append((item1,item2))
					# Fair Matching
					if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
						coincidences_rec_fid_fair.append((item1,item2))
				else:
					# One or more is outside the FID
					coincidences_rec_nonfid.append((item1,item2))
					# Fair Matching
					if item2[0] < item1[0]+abs(item1[3])/drift_speed_max:
						coincidences_rec_nonfid_fair.append((item1,item2))
			if np.sqrt(item1[9]**2+item1[10]**2) - np.sqrt(item2[9]**2+item2[10]**2) <= 30.0:
				coincidences_rec_ML.append((item1, item2))

			else: 
				# we want to check the efficiency of finding false coincidences using these
				coincidences_not_within_R.append((item1,item2))
    
    
	# Save coincidences found in dictionary for later if needed
	data = {}
	data['matched'] = matched
	data['coincidences_nov'] = coincidences_nov
	#data['coincidences_nov_fair'] = coincidences_nov_fair
	#data['coincidences_nov_fid'] = coincidences_nov_fid
	#data['coincidences_nov_fid_fair'] = coincidences_nov_fid_fair
	data['coincidences_onev'] = coincidences_onev
	#data['coincidences_onev_fid'] = coincidences_onev_fid
	#data['coincidences_onev_nonfid'] = coincidences_onev_nonfid
	#data['coincidences_onev_fid_fair'] = coincidences_onev_fid_fair
	#data['coincidences_onev_nonfid_fair'] = coincidences_onev_nonfid_fair
	data['coincidences_rec'] = coincidences_rec
	#data['coincidences_rec_fid'] = coincidences_rec_fid
	#data['coincidences_rec_fid_fair'] = coincidences_rec_fid_fair
	#data['coincidences_rec_nonfid'] = coincidences_rec_fid
	#data['coincidences_rec_nonfid_fair'] = coincidences_rec_fid_fair
	data['rec_matches'] = rec_matches
	data['nov_matches'] = nov_matches
	data['onev_matches'] = onev_matches
	data['ambiguous_matches'] = ambiguous_matches
	data['coincidences_not_within_R'] = coincidences_not_within_R
	# ML coincidences
	data['coincidences_rec_ML'] = coincidences_rec_ML
	data['coincidences_onev_ML'] = coincidences_onev_ML
	data['coincidences_nov_ML'] = coincidences_nov_ML


	print "Done finding coincidences"
	purity_data = get_purity_data()
	data['purity_data'] = purity_data
	#data['parms'] = {'zmin':zmin, 'zmax':zmax, 'rmax':rmax, 'sce_min':sce_min, 'sce_max':sce_max,\
	#				 'time_min':time_min, 'time_max':time_max, 'delta_UV':delta_UV,\
	#				 'drift_speed_max':drift_speed_max}
	cPickle.dump(data, open('RnPo_bulk+surface_t=180_coincidence_candidates.pkl','w'))
	#return data

