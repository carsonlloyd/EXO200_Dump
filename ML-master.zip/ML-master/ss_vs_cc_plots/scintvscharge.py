#!/usr/bin/python

## Takes data, makes scintillation counts vs. charge plot for light map corrected 

import ROOT
import sys
ROOT.gSystem.Load("libEXOUtilities")
import numpy as np
import cPickle
#import matplotlib.pyplot as plt

def main (argv):
	if 'create' in argv[1]:
		create()

#	if 'plot' in argv[1]:
#		plot()

def create():
	afile = ROOT.TFile.Open("alpha_runs.root")
	#afile = ROOT.TFile.Open("AlphaIon_Retry.root")
	t = afile.Get("tree")
	num = t.GetEntries()
	energy = np.array([[0,0,0]])

	for i in range(num):

		if i%int(num/1000) == 0: print "%d of %d" %(i,num)

		t.GetEntry(i)
		ed = t.EventBranch
		nsc = ed.GetNumScintillationClusters()
		if not nsc == 1: continue
		if nsc == 0: continue
		ncc = ed.GetNumChargeClusters()
		if not ncc == 1: continue
		if ncc == 0: continue 
	
		for j in range(nsc):
			nscounts = 0
			scint_energy = 0
			charge_energy = 0

			sc = ed.GetScintillationCluster(j)
			if sc.GetNumChargeClusters() == 0: continue
			scint_energy = sc.fRawEnergy
			nscounts = sc.GetCountsSumOnAPDPlane(0) + sc.GetCountsSumOnAPDPlane(1)
			for k in range(sc.GetNumChargeClusters()):
				cc = sc.GetChargeClusterAt(k)
				charge_energy += cc.fPurityCorrectedEnergy

			energy = np.concatenate((energy, np.array([[scint_energy, nscounts, charge_energy]])))

	energy = energy[1:]
	cPickle.dump(energy,open('SS_scE_nscounts_ccE.pkl','w'))
'''
def plot(): 
	energy = cPickle.load(open('scE_nscounts_ccE.pkl','r'))

	# counts
hist, xbins, ybins = np.histogram2d(ccE, nsc, bins=(200,200), range=((0,600),(0,70000))); hist = np.rot90(hist); hist = np.flipud(hist); hist_masked = np.ma.masked_where(hist==0,hist); hist_log = np.log10(hist_masked); plt.clf(); fig1 = plt.figure(2, figsize=(8,6)); plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log)); plt.xlabel('Purity corrected charge energy (keV)'); plt.ylabel('Raw Scintillation counts'); cbar = plt.colorbar(); cbar.ax.set_ylabel('Counts'); plt.show(); 

plt.savefig('ss_vs_cc_plots/nscounts_vs_ccE.png')


#scE vs ccE
hist, xbins, ybins = np.histogram2d(ccE[scE!=0], scE[scE!=0], bins=(200,200), range=((0,600),(0,70000))); hist = np.rot90(hist); hist = np.flipud(hist); hist_masked = np.ma.masked_where(hist==0,hist); hist_log = np.log10(hist_masked); plt.clf(); fig1 = plt.figure(2, figsize=(8,6)); plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log)); plt.xlabel('Purity corrected charge energy (keV)'); plt.ylabel('Corrected Scintillation Counts'); cbar = plt.colorbar(); cbar.ax.set_ylabel('Counts'); plt.savefig('ss_vs_cc_plots/scE_vs_ccE.png')

#betas
hist, xbins, ybins = np.histogram2d(ccE[scE!=0], scE[scE!=0], bins=(200,200), range=((0,5000),(0,60000))); hist = np.rot90(hist)-2; hist = np.flipud(hist); hist_masked = np.ma.masked_where(hist==0,hist); hist_log = np.log10(hist_masked); plt.clf(); fig1 = plt.figure(1, figsize=(8,6)); plt.pcolormesh(xbins, ybins, hist_log, vmax = np.amax(hist_log)); plt.xlabel('Purity corrected charge energy (keV)'); plt.ylabel('Corrected Scintillation Counts'); cbar = plt.colorbar(); cbar.ax.set_ylabel('Counts'); plt.savefig('ss_vs_cc_plots/scE_vs_ccE_show_betas.png')


	hist, xedges, yedges = np.histogram2d(energy[:,2], energy[:,1])
	hist = np.rot90(hist)
	hist = np.flipud(hist)
	hist_masked = np.ma.masked_where(hist==0,hist)
	fig1 = plt.figure(1,figsize=(6,4))
#	fig1.suptitle('Scintillation counts vs. corrected charge energy', fontsize=50)
	plt.xlabel('Corrected Charge Energy (keV)')
	plt.ylabel('Scintillation Counts')
	plt.xlim(0,700)
	plt.ylim(0,70000)
#	plt.rcParams['xtick.labelsize'] = 20
#	plt.rcParams['ytick.labelsize'] = 20
	plt.savefig('nsc_vs_ccE.png')

	# Corrected scintillation energy vs corrected charge energy
	hist, xedges, yedges = np.histogram2d(energy[:,2], energy[:,0])
	hist = np.rot90(hist)
	hist = np.flipud(hist)
	hist_masked = np.ma.masked_where(hist==0,hist)
	fig2 = plt.figure(1,figsize=(6,4))
#	fig2.suptitle('Corrected scintillation energy vs. corrected charge energy', fontsize=50)
	plt.xlabel('Corrected Charge Energy (keV)')
	plt.ylabel('Corrected Scintillation Energy (keV)')
#	plt.rcParams['xtick.labelsize'] = 20
#	plt.rcParams['ytick.labelsize'] = 20
	plt.savefig('scE_vs_ccE.png')


#	cutoff_beta = ROOT.TLine(9.375, 0, 600, 20000)
#	cutoff_surface1 = ROOT.TLine(0,22000,300,37500)
#	cutoff_surface2 = ROOT.TLine(300, 37500, 500, 59500)
'''
if __name__ == '__main__':
    main(sys.argv)

