#!/usr/bin/python

## Takes data from 

import ROOT
ROOT.gSystem.Load("libEXOUtilities")
from numpy import *
import cPickle

afile = ROOT.TFile.Open("alpha_runs.root")
t = afile.Get("tree")
num = t.GetEntries()

for i in range(num):
	if i%int(num/1000) == 0: print "%d of %d" %(i,num)
	
	t.GetEntry(i)
	ed = t.EventBranch
	nsc = ed.GetNumScintillationClusters()
#	if nsc == 0: continue
	if not nsc == 1: continue ## Rn-Po
	ncc = ed.GetNumChargeClusters()
	if not ncc == 1: continue ## Rn-Po
#	if ncc == 0: continue 


