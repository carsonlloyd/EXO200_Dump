`#!/usr/bin/env python

README = """
This script should be run at SLAC where it has access to the EXO200 data.
This script finds alpha like events, and classifies them, and saves them for
further analsysis.

Phase2a started Oct 5th, ended April 16th (runs 2464-3564)
    This is marked by U-wire shaping time change?

AlphaIon run list 
"""

import ROOT
import sys
ROOT.gSystem.Load("libEXOUtilities")
#ROOT.gSystem.Load("libEXOCalibUtilities")
import datetime, pytz

##############################################################################################################
#                                              Constants
##############################################################################################################
fid_cut_cyl = (172.,5.,185.)  # radius, z_min, z_max
fid_cut_hex = (172.,5.,185.)  #apethum, z_min, z_max
cathode_anode_dist = 192. #mm
max_drift_time = cathode_anode_dist/1.711 + 6./2.041
# 1.711 mm/us in drift_vol and 2.041 mm/us in anode region

# Energy calibration database flavors (same database flavors used in 2014 0nu analysis)
fCalibrationDatabaseFlavors = ("2013-0nu-denoised", "2013-0nu-denoised", "vanilla")

# Feed events approximate time and how much was injected approx
feed_events = [
        (datetime.datetime(2012,1,13,10,56,0),21.7),
        (datetime.datetime(2012,1,14,15,26,0),91),
        (datetime.datetime(2012,1,15,13,40,0),40.4),
        (datetime.datetime(2012,1,16,8,54,0),397.1),
        (datetime.datetime(2012,1,17,12,12,0),14.4),
        (datetime.datetime(2012,1,18,12,0,0),392.4),
        (datetime.datetime(2012,6,19,19,30,0),33),
        (datetime.datetime(2012,6,20,9,0,0),269.3),
        (datetime.datetime(2012,8,28,13,34,0),15.7),
        (datetime.datetime(2012,8,30,9,30,0),377.2),
        (datetime.datetime(2012,8,31,16,30,0),269.9),
        (datetime.datetime(2012,9,1,10,55,0),630.2),
        (datetime.datetime(2012,9,12,9,50,0),356.8),
        (datetime.datetime(2012,10,15,15,13,0),343.5),
        (datetime.datetime(2013,2,5,17,0,0),43.0),
        (datetime.datetime(2013,5,5,13,30,0),332.6),
        (datetime.datetime(2013,6,21,11,40,0),355.9),
        (datetime.datetime(2013,7,17,14,20,0),269.5),
        (datetime.datetime(2013,7,18,8,18,0),115.5),
        (datetime.datetime(2013,8,12,9,40,0),546.0),
        (datetime.datetime(2013,11,11,13,18,54),200), #not actually measured how bad
        (datetime.datetime(2013,11,12,10,38,54),100), #not actually measured how bad
        (datetime.datetime(2013,11,15,20,41,54),50), #not actually measured how bad
        (datetime.datetime(2013,11,16,18,00,00),500), #not actually measured how bad
        (datetime.datetime(2014,1,9,20,41,54),400)] #not actually measured how bad


##############################################################################################################
#                                                 MAIN
##############################################################################################################
def main():
    """
    This builds a concentrated dataset from the selected initial LB dataset
    Output is a single root file with entries corresponding to the cuts set here.
    """
    # Verbosity: 1=Selection Results, >1 is various debugging information
    verbose = 1
    print "Build_AlphaIon_Data.py running with verbose=%s"%(str(verbose))
    if verbose:
        print "Fiducial Cut: ",fid_cut_hex,"(apethum, z_min, z_max)"
        print "Max Drift Distance = %.4f us"%(max_drift_time)

    tree = get_data_tree(list='AlphaIon')
     
    # We use the EXOFitting processed tree to get high-level physical quantities
    # like the anticorrelated energy, etc. 
    #ptree_file = ROOT.TFile(preprocessed_tree)
    #ptree = ROOT.Get("dataTree")
    #if verbose: print "Indexing EXOFitting PreProcessed tree"
    #ptree.BuildIndex("runNum", "eventNum")
    #if verbose: print " ...done"

    #There must be at least 1 scintillation cluster:
    #cuts = "@fScintClusters.size()>=1"
    cuts = "(fScintClusters.GetCountsOnAPDPlane(0)+fScintClusters.GetCountsOnAPDPlane(1))>20000"

    # The minimum scintinlation counts must be > 20000 and <70000
    # I observe that three peaks presumable alphas are at 38500, 42200, and 55000
    # So Rn222=5.4MeV, Po218=6MeV, Po214=7.7MeV
    # calibrate:: y=mx+b,  m=6167, b=5198
    #cuts = "fScintClusters.fRawEnergy>20000 && fScintClusters.fRawEnergy<70000"
    #cuts += "&& fScintClusters.fRawEnergy>22000 && fScintClusters.fRawEnergy<80000"
    #cuts += " && Sum$(fAPDs.fRawCounts) > 8000"

    # Ignore Noise and Muon tagged events
    cuts +=" && fEventHeader.fTaggedAsNoise==0 && fEventHeader.fTaggedAsMuon==0"

    # That's the last of the cuts, lets show the user what the cut looks like
    print "Applying Cuts to data: \n%s"%cuts

    #Draw is the fastest method to apply cuts, in the end what we want is a reduced data list
    # to perform a more targeted analysis...
    tree.Draw(">>+elist_alpha_canidates",cuts,"goff")
    elist_alpha_canidates = ROOT.gDirectory.Get("elist_alpha_canidates")
    print "There are %d events passing the initial cuts"%elist_alpha_canidates.GetN()

    #Now we have to look at events passing the cuts individually
    tf = ROOT.TFile("alpha_runs.root","RECREATE")
    Rntree = tree.CloneTree(0)
    
    for i in range(elist_alpha_canidates.GetN()):
        # Print Progress
        if i%int(elist_alpha_canidates.GetN()/20) == 0:
            print "%d of %d"%(i,elist_alpha_canidates.GetN())

        #Grab the event data
        tree.GetEntry(elist_alpha_canidates.GetEntry(i))
        #ed = tree.EventBranch
        #if verbose>1: print_event_data(ed,verbose)

        #is_alphaish = check_alpha_like(ed,verbose)
        
        #is the event a fully reconstructed BiPo?
        #is_bipo = check_full_BiPo(ed,verbose)

        # Case1 (position matched Bi-Po)
        #is_case1 = check_case1(ed,verbose)
        #print "BiPo=%s, Case1=%s"%(is_bipo, is_case1) 
        #raw_input('<hit any key to continue>')
        #if is_bipo or is_alphaish:
            # Write the EventData of events which pass any of our selection criteria
            # to ROOT file
        Rntree.Fill()

    Rntree.AutoSave()

##############################################################################################################
#                                              Selection cuts
##############################################################################################################

# ---------------------------- Bung1 ---------------------------------
def check_alpha_like(ed, verbose=0):
    """
    This looks for any event that contains an alpha-like event.
    Alpha like events have a single scintillation cluster, that is larger than charge
    """ 
    nsc = ed.GetNumScintillationClusters()
    for isc in range(nsc):
        sc = ed.GetScintillationCluster(isc)
        scss1 = sc.GetPlaneOneSignal().fCounts
        scss2 = sc.GetPlaneTwoSignal().fCounts
        sc_e  = sc.fRawEnergy
        if sc.GetNumChargeClusters()>1:
            #Skip this scintillation cluster, has >1 charge clusters
            #This can cut BiPo events that are close enough in time that the charge
            # clusters are miss-associeated. 
            continue
        cc = sc.GetChargeClusterAt(0)
        if cc.fCorrectedEnergy < 500:
            return True


def check_full_BiPo(ed, verbose=0):
    """
    This function requires two scintillation clusters, and only one charge cluster to be found
    associeated with the alpha. The alpha is required to have more scintillation energy, and the
    alpha must be the second scintillation cluster. Finally the alpha cluster must be in the 
    fiducial volume.
    """
    nsc = ed.GetNumScintillationClusters()
    ncl = ed.GetNumChargeClusters()
    # A fully reconstructed BiPo must have two scintillation clusters
    if nsc != 2: return False

    # Loop over scintillation clusters
    tmp = []
    for isc in range(nsc):
        tmp.append({})
        sc = ed.GetScintillationCluster(isc)
        tmp[isc]['sc_time'] = sc.fTime
        tmp[isc]['sc_ene'] = sc.fRawEnergy
        tmp[isc]['sc_ncl'] = sc.GetNumChargeClusters()
        tmp[isc]['sc_cc'] = []
        # Loop over associeated charge clusters
        for icl in range(tmp[isc]['sc_ncl']):
            tmp[isc]['sc_cc'].append(sc.GetChargeClusterAt(icl))
        # So Bi214 has a ton of gammas, so it's not going to necessiarlly be SS...
    #This sorts the two clusters by time...    
    tmp.sort(key=lambda k: k['sc_time'])
    
    # There are a few more things we know,
    # The alpha comes second, and should be single site
    if tmp[1]['sc_ncl'] != 1:
        if verbose>1: print "Full_BiPo: Alphas can't be MS. (rejected)"
        return False
    
    # We expect the scintillation energy to be greater for the alpha
    if (tmp[1]['sc_ene'] < tmp[0]['sc_ene']):
        if verbose>1: print "Full_BiPo: Alpha cant have less scint than Beta (rejected)"
        return False
    
    # Is the Alpha cluster in the fidutial volume?
    if not is_fiducial_hex(tmp[1]['sc_cc'][0]):
        if verbose>1: print "Full_BiPo: Alhpa charge cluster is not in the fiducial volume (rejected)"
        return False

    if verbose: print "Full_BiPo found: run %d, event %d"%(ed.fRunNumber,ed.fEventNumber)
    return True

# ---------------------------- Case 1 ---------------------------------
def check_case1(ed, verbose=0):
    """
    Case1: Two fully reconstructed clusters (Bi-Po)
           Position of charge clusters must be within 20mm radius
           (There is a chance that all charge clusters arrive after the second scintillation!!)
           Arrivial time of charge clusters must be > 5us
           There may be other CC from secondary gammas from beta decay
           Algorythm tries to remove incorrectly found scintillation clusters before rejecting event
    """
    if verbose:
        print " ---ooo000OOO000ooo--- ---ooo000OOO000ooo--- ---ooo000OOO000ooo---"
        print "                            Case1  Test                            "

    # Must have at least 2 scintillation clusters
    if ed.GetNumScintillationClusters()<2:
        return False

    # Assemble event into pythonic structure
    BiPo_canidate = []
    for isc in range(ed.GetNumScintillationClusters()):
        sc = ed.GetScintillationCluster(isc)
        BiPo_canidate.append((sc,[]))
        for iacc in range(sc.GetNumChargeClusters()):
            BiPo_canidate[-1][1].append(sc.GetChargeClusterAt(iacc))
    BiPo_canidate.sort(key=lambda k: k[0].fTime)

    # Are there too many scintillation clusters for BiPo? This attempts to remove suspect scint clusters
    if len(BiPo_canidate)>2:
        # Find me the largest scintillation cluster (we know it's got to have at least one cluster > cut on fRawEnergy)
        alpha_i,alpha_e = max(enumerate([i[0].fRawEnergy for i in BiPo_canidate]),key=operator.itemgetter(1))
        if verbose>1: print " Alpha Energy=%f"%(alpha_e)

        # The alpha event can't be the first scintillation cluster in case1
        if alpha_i == 0:
            if verbose: print "Largest scint is seen first, so did not find beta scintillation, Not case1"
            return False

        # Scint clusters coming after the alpha are suspect!
        if alpha_i < len(BiPo_canidate) - 1:
            if verbose: print "Case1: Scint cluster found after the alpha scintillation!?! Can't be!"
            for i in range(alpha_i,len(BiPo_canidate)):
                if BiPo_canidate[i][0].fRawEnergy < threshold_apd:
                    if verbose: print "  rm Scint fTime=%d, fRawEnergy=%f"%(BiPo_canidate[i][0].fTime,BiPo_canidate[i][0].fRawEnergy)
                    BiPo_canidate.pop(i)
                else:
                    if verbose: print " Cannot remove scint, it's above threshold: %f>%f ADC counts"%(BiPo_canidate[i][0].fRawEnergy, threshold_apd)
                    return False

        # If still more than 2 scintillation clusters, then maybe ambigious which scint is the beta
        if len(BiPo_canidate)>2:
            # TODO: Can cut based on time perhaps, expect beta to be somewhat close to the alpha
            if verbose: print "Case1: Still more than 2 scintillations, you be the judge..."
            if verbose: print_event_data(ed)
            if verbose: print "^^^^^^Case1: Still more than 2 scintillations, you be the judge^^^^^^"
            return False


    # Is the event in the fiducial volume?
    if sum([is_fiducial_hex(cc) for cc in BiPo_canidate[1][1]]) == 0:
        if verbose: print "Alpha decay is not in the fiducial volume"
        return False


    # At this point we've done all we can to resolve extra scintillation clusters
    if len(BiPo_canidate)!=2:
        if verbose: print "Case1: Still too many SC, rejecting"
        return False

    #Grab all unassocieated charge clusters
    unassocieated_charge_clusters = []
    for icc in range(ed.GetNumChargeClusters()):
        cc = ed.GetChargeCluster(icc)
        if not cc.HaveScintillationCluster():
            unassocieated_charge_clusters.append(cc)
    if verbose: print "Case1: There are %d unassocieated CCs"%(len(unassocieated_charge_clusters))

    BiPo_dt = (BiPo_canidate[1][0].fTime - BiPo_canidate[0][0].fTime)/1000. #us
    if BiPo_dt < 5.:
        if verbose: print "Case1: scints too close together >5us, rejected"
        return False

    if len(BiPo_canidate[1][1])>1:
        if verbose: print "Case1: Alpha has more than one CC, how?"
        if max([abs(cc.fZ) for cc in BiPo_canidate[1][1]]) < 2.0: #mm 
            # Then alpha is close enough to cathode to split charge...
            if len(BiPo_canidate[1][1])==2:
                if is_opposite_sign(BiPo_canidate[1][1][0].fZ, BiPo_canidate[1][1][1].fZ):
                    #Alpha is split on cathode:
                    if verbose: print "Alpha charge is split across cathode"
                    #Right now we dont care about alphas on the cathode.... (maybe this will change later)
                    return False 
    
    # Start looking at event positions
    if BiPo_dt > max_drift_time: # Very unlikley that the charges are mixed up
        r3_dist = lambda cc1,cc2: ( (cc1.fX-cc2.fX)**2 + (cc1.fY-cc2.fY)**2 + (cc1.fZ-cc2.fZ)**2 )**0.5
        r3_min  = min([r3_dist(BiPo_canidate[1][1][0],cc) for cc in BiPo_canidate[0][1]])
        print "BiPo minimum dist between CC:", r3_min

        if r3_min < 20: #mm
            if verbose: print "Good Case1 Canidate!"
            return True

def check_case2(ed,verbose=False):
    """
    Case2: Case where the first scintillation signal is missing (the beta usually)
           Alpha scintillation must be greater than 10k ADC (above betas)
           There must be a charge cluster found at the trigger time for the Beta decay (?)
           There must be another CC >5us after, found within 15mm
           Algorythm tries to remove incorrectly found scintillation clusters before rejecting event
    """
    pass

def check_case3(ed, verbose=False):
    """
    Case3: Two reconstructed scintillation clusters with a ration SC_alpha/SC_beta > 3
           Second SC > 10k ADC counts
           Must be at least one CC associeated with first SC (BM: really?)
           If the CC comes after the second SC, look for another CC:
             If second CC found at matching x/y (with right time delay?) maybe promote to Case1 (clustering error)
           If no other CC are found associeate CC with first SC (the beta)
    """
    pass

def check_case4(ed, verbose=False):
    """
    Case4: CC at trigger time
           SC with magnitude > 10k ADC
           (Hand scan later?)
    """
    pass



##############################################################################################################
#                                              Helper Functions
##############################################################################################################

def get_data_tree(list, test=False,rebuild=True):
    """
    Returns TChain of requested run list:
      AlphaIon (default) - Custom list made for AlphaIon work, golden + low purity runs
      Golden - The golden run list used for the 2014 0v paper
      GoldenDenoised - The golden run list used for the 2014 0v paper
      All - All data runs since phase 2 started
    """
    run_list = get_run_list(list, rebuild=rebuild)
    #Create TChain of all data runs:
    print "Making TChain..."
    tree = ROOT.TChain("tree")
    if test:
        i=0
        print "Test Mode, only using 1/50th of the data"
    for run in run_list.keys():
        if test:
            i+=1
            if i%50 != 0:
                continue
        for file in run_list[run]['file_paths']:
            tree.Add(file)
    print "... Done. There are %d events in this dataset."%tree.GetEntries()
    #Build Index so we can associeate this with the pre-processed tree information
    #if verbose: print "Indexing ROOT tree"
    #tree.BuildIndex("fRunNumber", "fEventNumber")
    #if verbose: print " ...done"
    return tree

def get_run_list(list, rebuild=False):
    # This retrieves a list of golden data runs from the RESTfull interface (not denoised)
    if list == 'Golden':
        run_list = get_golden_data_list()
    #   ---- or ----
    #
    # This gets the LB data from the EXO_Fitting DeNoised Run2abc file list
    elif list == 'EXO_Fitting':
        run_list = get_golden_data_from_file('BuildRunList/fileListRun2abcDenoised.dat')
    #   ---- or ----
    #
    # This gets the runs from the exofitting list, but then grabs the files from the database
    elif list == 'EXO_Fitting_runs':
        run_list = get_runs_from_fitting('BuildRunList/fileListRun2abcDenoised.dat',list='masked')
    #
    # Get all runs that we can do analysis on. This includes right after feeds where
    # there are more alphas, but detector responce isn't as great.
    elif list == 'All':
        run_list = get_all_runs_list()
    #
    #  ---- or ----
    # A run list of all Physics runs that are in 0v or were >1hour and passed hand-scan
    # This includes runs with low purity, but not with poor operational conditions
    elif list == 'AlphaIon':
		print "this is the alpha list"
        run_list = get_alphaion_run_list(rebuild)
    #
    # A run_list is a dictionary object that cointains at a minimum:
    #     run_info[run]['file_paths'] = []

    # NOTE: THIS ISN'T FUNCTIONING YET
    #The conditions data stores when data_quality group marks parts of data runs BAD
    #Grabbing bad times in-case we want to cut these out...
    #bad_times = get_bad_time_data()
    return run_list


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_livetime(list_name,method='DAQ',verbose=False):
    """
    Calculates livetime for AlphaIon supported lists. See get_run_list for list options.
    Can calculate livetime from many methods:
        DAQ  = Used DAQ start and stop time for each run
        tree = Uses first and last event in each run tree
        all  = Prints out each method
    Returns livetime in seconds
    """
    import dateutil.parser
    run_list = get_run_list(list_name)
    if method in ['DAQ','all']:
        daq_livetime = 0
        for run in run_list:
            run_data = ROOT.EXORunInfoManager.GetDataRunInfo(int(run))
            exposure = run_data.FindMetaData('exposure').AsDouble()
            #start_time = run_data.FindMetaData('startTime').AsString()
            #end_time = run_data.FindMetaData('endTime').AsString()
            if verbose:
                print "Run %d - Exposure=%.2f hours"%(run,exposure/1.e9/3600.)
            daq_livetime += exposure/1e9 #seconds
        print "Total Livetime = %.2f days or %.2f hours"%(daq_livetime/3600./24.,daq_livetime/3600.)
    return daq_livetime



# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_purity_data():
    """
    Returns dictionary with TPC1,TPC2 as keys. In each dictionary is a list of the entries
    in the calib-table used for the 0-nu anlaysis. In this list is a dictionary with all the 
    info for the table, and it gets the actual parameters from the electron-lifetime table 
    that correspond to those entries.
    """
    import MySQLdb
    import MySQLdb.cursors
    import datetime
    data ={'TPC1':[],'TPC2':[]} # Container for purity structure
    db = MySQLdb.connect("mysql-node03.slac.stanford.edu","rd_exo_cond_ro","w0rking.St1fff!","rd_exo_cond",cursorclass=MySQLdb.cursors.DictCursor)
    cursor = db.cursor()
    cursor.execute("SELECT * FROM conditions WHERE calib_type='a-el-life' AND flavor='TPC1_2013_0nu'")
    tpc1 = cursor.fetchall()
    cursor.execute("SELECT * FROM conditions WHERE calib_type='a-el-life' AND flavor='TPC2_2013_0nu'")
    tpc2 = cursor.fetchall()
    for i in tpc1:
        data['TPC1'].append({})
        for k in i.keys():
            data['TPC1'][-1][k] = i[k]
        calib_key = int(i['data_ident'].split(':')[2])
        cursor.execute("SELECT * from ateam_electron_lifetime WHERE calib_key=%d"%calib_key)
        parms = cursor.fetchall()
        for k in parms[0].keys(): 
            data['TPC1'][-1][k] = parms[0][k] 
    for i in tpc2:
        data['TPC2'].append({})
        for k in i.keys():
            data['TPC2'][-1][k] = i[k]
        calib_key = int(i['data_ident'].split(':')[2])
        cursor.execute("SELECT * from ateam_electron_lifetime WHERE calib_key=%d"%calib_key)
        parms = cursor.fetchall()
        for k in parms[0].keys(): 
            data['TPC2'][-1][k] = parms[0][k] 
    return data

def calc_purity_datetime(purity_data,thistime):
    """
    Useage: calc_purity_datetime(purity_data,thistime)
    This takes UTC time and purity data structure to return purity values as [TPC1,TPC2]
    If it returns None, then the TPC does not have a valid purity for that time
    """
    if thistime.tzinfo != None:
        tmp = thistime.astimezone(pytz.UTC)
        thistime = thistime.replace(tzinfo=None)
    purity = [None,None]
    for tpc1_pp in purity_data['TPC1']:
        if thistime > tpc1_pp['vstart'] and thistime < tpc1_pp['vend']:
            # Found the valid TPC1 data point
            purity[0] = tpc1_pp
            break
    for tpc2_pp in purity_data['TPC2']:
        if thistime > tpc2_pp['vstart'] and thistime < tpc2_pp['vend']:
            # Found the valid TPC1 data point
            purity[1] = tpc2_pp
            break
    for itpc in range(2):
        if purity[itpc] == None:
            continue
        #if purity[itpc]['p1'] == 0:
        #    print itpc,"vstart=",purity[itpc]['vstart'],purity[itpc]['p0'],purity[itpc]['p1']
        t = (thistime - datetime.datetime.fromtimestamp(purity[itpc]['origin'])).total_seconds()/3600./24.
        purity[itpc] = purity[itpc]['p0'] + purity[itpc]['p1']*t + purity[itpc]['p2']*(t**2.) + purity[itpc]['p3']*(t**3.)\
                        + purity[itpc]['p4']*(t**4.) + purity[itpc]['p5']*(t**5.) + purity[itpc]['p6']*(t**6.)
    return purity

def make_purity_plot(plot_filename='purity_plot.png',plot_feeds=True):
    """
    Makes plots of the purity data that it gets from the above functions
    """
    import matplotlib.pyplot as plt
    import pytz, datetime
    import numpy
    purity_data = get_purity_data()
    local = pytz.timezone("US/Mountain")
    t0 = datetime.datetime(2011,10,5,18,3,4) #phase2 run start (Mountain?)
    tf = datetime.datetime(2013,9,1,8,16,45) # run 5597, last used in AlphaIon
    t0_mt = local.localize(t0)
    tf_mt = local.localize(tf)
    t0_utc = t0_mt.astimezone(pytz.utc)
    tf_utc = tf_mt.astimezone(pytz.utc)
    tdx = numpy.linspace(0,(tf_utc - t0_utc).total_seconds(),10000)
    t,p = [],[]
    for i in tdx:
        t.append(t0_utc+datetime.timedelta(seconds=i))
        p.append(calc_purity_datetime(purity_data,t0+datetime.timedelta(seconds=i)))
    npp = numpy.array(p)
    fig = plt.figure(figsize=(12,7))
    plt.plot(t,npp[:,0],label='TPC1')
    plt.plot(t,npp[:,1],label='TPC2')
    plt.legend(loc=2)
    for i in feed_events:
        plt.vlines(i[0],0,plt.gca().get_ylim()[1],color='r',linewidth=2)
    plt.xlabel('Time [UTC]')
    plt.ylabel('Purity [microseconds]')
    plt.grid()
    fig.autofmt_xdate()
    plt.savefig(plot_filename,dpi=200)

# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def is_fiducial_cyl(EXOChargeCluster):
    # Checks if position is in global defined FID
    x = EXOChargeCluster.fX
    y = EXOChargeCluster.fY
    z = EXOChargeCluster.fZ
    if (x**2+y**2)<= fid_cut_cyl[0] and abs(z) > fid_cut_cyl[1] and abs(z) < fid_cut_cyl[2]:
        return True
    return False


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def is_fiducial_hex(EXOChargeCluster):
    u = EXOChargeCluster.fU
    v = EXOChargeCluster.fV
    x = EXOChargeCluster.fX
    z = EXOChargeCluster.fZ
    if abs(x) < fid_cut_hex[0] and abs(u) < fid_cut_hex[0] and abs(v) < fid_cut_hex[0] and abs(z) > fid_cut_cyl[1] and abs(z) < fid_cut_cyl[2]:
        return True
    return False


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def is_opposite_sign(a,b):
    """Checks if numbers have different sign, zero belongs to both signs"""
    if (a>=0. and b<=0.) or (a<=0. and b>=0.):
        return True
    return False


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def print_event_data(ed, verbose=False):
    """ Prints detailed event data information associeated with clusters, and signals with verbose=True"""
    print "##################################################"
    print " Detailed Event Data: Run=%d, Event=%d"%(ed.fRunNumber,ed.fEventNumber)
    print "--------------------------------------------------"
    for isc in range(ed.GetNumScintillationClusters()):
        sc = ed.GetScintillationCluster(isc)
        print " %d) Scintillation: %d, %d RawEnergy in (North,South) at %.2f us"%(isc,sc.GetCountsOnAPDPlane(0),sc.GetCountsOnAPDPlane(1),sc.fTime/1000.)
        for icc in range(sc.GetNumChargeClusters()):
            cc = sc.GetChargeClusterAt(icc)
            print "  %d) CC: %.1f KeV, t=%.1f us, X,Y,Z = %.1f, %.1f, %.1f"%(icc, cc.fPurityCorrectedEnergy, cc.fCollectionTime/1000., cc.fX, cc.fY, cc.fZ)
            if verbose>1:
                for iu in range(cc.GetNumUWireSignals()):
                    usig = cc.GetUWireSignalAt(iu)
                    print "   %d) USig: Chn=%d, t=%f, %f KeV"%(iu, usig.fChannel, usig.fTime/1000., usig.fRawEnergy)

    # Now look for any charge clusters that were not associeated w/ scintllations
    print " Unassocieated Charge Clusters:"
    num_unassocieated = 0
    for icc in range(ed.GetNumChargeClusters()):
        cc = ed.GetChargeCluster(icc)
        if not cc.HaveScintillationCluster():
            print " CC: %.1f KeV, X,Y,Z=%.1f,%.1f,%.1f"%(cc.fPurityCorrectedEnergy, cc.fX, cc.fY, cc.fZ)
            num_unassocieated +=1
            if verbose>1:
                for iu in range(cc.GetNumUWireSignals()):
                    usig = cc.GetUWireSignalAt(iu)
                    print "   %d) USig: Chn=%d, t=%.1f, %.1f KeV"%(iu, usig.fChannel, usig.fTime, usig.fRawEnergy)
    if num_unassocieated == 0: print "  None"
    if verbose>2:
        print "--------------------------------------------------"
        print "   Scintillation Signals"
        for iss in range(ed.GetNumAPDSignals()):
            ss = ed.GetAPDSignal(iss)
            print "%d) t=%.2f, chn=%d, adc=%d, e=%.2f, desc=%s"%(iss,ss.fTime/1000.,ss.fChannel,ss.fRawCounts,ss.fCorrectedCounts,ss.fDescr)
    print "##################################################"


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_golden_data_list(list='masked',**kwargs):
    """
    This function gets the golden run list from the RESTful interface, but...
    we dont use the !!&$(@ RESTful interface to describe our run lists for analysis
    (YET)
    """
    if 'verbose' in kwargs.keys():
        verbose = int(kwargs['verbose'])
    run_start = 2464
    run_end   = 5597
    run_cut_str = "quality==\"GOLDEN\" && runType==\"Data-Physics\""
    if 'run_min' in kwargs.keys():
        run_start = int(kwargs['run_min'])
    if 'run_max' in kwargs.keys():
        run_end = int(kwargs['run_max'])
    run_cut_str += " && run>= %d && run<= %d"%(run_start,run_end)
    if 'verbose' in kwargs:
        print "Getting Run Data List:"
        print "  ",run_cut_str
    golden_ds = ROOT.EXORunInfoManager.GetDataSet("Data/Processed/%s"%list,run_cut_str)
    run_info = {}
    for i in golden_ds:
        run = i.GetRunNumber()
        run_info[run] = {}
        run_info[run]['file_paths'] = []
        for afile in i.GetRunFiles():
            run_info[run]['file_paths'].append(afile.GetFileLocation())
        run_data = ROOT.EXORunInfoManager.GetDataRunInfo(run)
        run_info[run]['exposure'] = run_data.FindMetaData('exposure').AsDouble()
        run_info[run]['start_time'] = run_data.FindMetaData('startTime').AsString()  
        run_info[run]['end_time'] = run_data.FindMetaData('endTime').AsString()
        run_info[run]['run_type'] = run_data.FindMetaData('runType').AsString()
    return run_info


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_golden_data_from_file(file):
    """A file stolen from EXO_Fitting trunk that has locations of all DeNoised Data"""
    import re
    file_list = open(file,'r').readlines()
    run_info = {}
    for f in file_list:
        run = int(re.findall(r'\d+',f.split('/')[-1].split('-')[0])[0])
        if run not in run_info.keys():
            run_info[run] = {}
            run_info[run]['file_paths'] = []
        run_info[run]['file_paths'].append(f.rsplit()[0])
    return run_info

# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_runs_from_fitting(file,list='masked'):
    """ 
    Uses the file list from EXO_Fitting to determine runs, but gets file list from database 
    This way you can change if you want denoised/masked or whatever...
    """
    import pickle
    import re
    file_list = open(file,'r').readlines()
    run_list = []
    for f in file_list:
        run = int(re.findall(r'\d+',f.split('/')[-1].split('-')[0])[0])
        if run not in run_list:
            run_list.append(run)    
    run_info = {}
    for run in run_list:
        run_info[int(run)] = {}
        run_info[int(run)]['file_paths'] = []
        rundata = ROOT.EXORunInfoManager.GetRunInfo(int(run),"Data/Processed/%s"%list) # This might need updated
        for rf in rundata.GetRunFiles():
            run_info[int(run)]['file_paths'].append(rf.GetFileLocation())
        run_data = ROOT.EXORunInfoManager.GetDataRunInfo(run)
        run_info[run]['exposure'] = run_data.FindMetaData('exposure').AsDouble()
        run_info[run]['start_time'] = run_data.FindMetaData('startTime').AsString()  
        run_info[run]['end_time'] = run_data.FindMetaData('endTime').AsString()
        run_info[run]['run_type'] = run_data.FindMetaData('runType').AsString()
    print "... Done building run_info."
    pickle.dump(run_info,open('exofitting_run_list.pkl','w'))
    return run_info

# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_all_runs_list():
    """
    This gets all runs in the data-catalogue that are masked, type=Data-Physics, and run>=2464
    """
    all_ds = ROOT.EXORunInfoManager.GetDataSet("Data/Processed/%s"%list,"runType==\"Data-Physics\" && run>=2464")
    run_info = {}
    for i in all_ds:
        run = i.GetRunNumber()
        run_info[run] = {}
        run_info[run]['file_paths'] = []
        for afile in i.GetRunFiles():
            run_info[run]['file_paths'].append(afile.GetFileLocation())
        run_data = ROOT.EXORunInfoManager.GetDataRunInfo(run)
        run_info[run]['exposure'] = run_data.FindMetaData('exposure').AsDouble()
        run_info[run]['start_time'] = run_data.FindMetaData('startTime').AsString()  
        run_info[run]['end_time'] = run_data.FindMetaData('endTime').AsString()
        run_info[run]['run_type'] = run_data.FindMetaData('runType').AsString()
    return run_info


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_alphaion_run_list(list='masked',rebuild=False):
    """
    Run list by Erica and Brian.
    Included all runs in 0v analysis by default.
    Runs that had relitivly good E.O.R. plots were also included, especially low purity runs...
    See BuildRunList for some more information
    
    If the runs have been reprocessed and the DataCatalogue gets updated, you need to run with 
        rebuild=True
    to get the new files.
    """
    print "Building run_info..."
    import pickle
    run_info = {}
    run_list = pickle.load(open('BuildRunList/AlphaIon_RunList.pkl','r'))
    
    #Does one exist already, maybe we dont need to rebuild it...
    if rebuild == False:
        try:
            existing_run_list = pickle.load(open('alphaion_run_list.pkl','r'))
            is_consistant = True
            for run in run_list:
                if run not in existing_run_list.keys():
                    is_consistant = False
            if is_consistant:
                print "  Found existing alphaion_run_list.pkl, using that"
                print "  Use option rebuild=True to force rebuild of run_list"
                return existing_run_list
            else:
                print "  Found existing alphaion_run_list.pkl, but it's inconsistant"
                print "  Building it again, please wait :)"
        except:
            print "No existing run list, building one..."
        
    for run in run_list:
        run_info[int(run)] = {}
        run_info[int(run)]['file_paths'] = []
        rundata = ROOT.EXORunInfoManager.GetRunInfo(int(run),"Data/Reprocess/Processed/%s"%list) # This might need updated
        for rf in rundata.GetRunFiles():
            run_info[int(run)]['file_paths'].append(rf.GetFileLocation())
        run_data = ROOT.EXORunInfoManager.GetDataRunInfo(run)
        run_info[run]['exposure'] = run_data.FindMetaData('exposure').AsDouble()
        run_info[run]['start_time'] = run_data.FindMetaData('startTime').AsString()  
        run_info[run]['end_time'] = run_data.FindMetaData('endTime').AsString()
        run_info[run]['run_type'] = run_data.FindMetaData('runType').AsString()
    print "... Done building run_info."
    pickle.dump(run_info,open('alphaion_runs.pkl','w'))
    return run_info


# ---ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo------ooo000OOO000ooo---
def get_bad_time_data():
    import MySQLdb
    db = MySQLdb.connect(host="mysql-node03.slac.stanford.edu", port=3306, user="rd_exo_cond_ro", db="rd_exo_cond", passwd="w0rking.St1fff!")
    cursor = db.cursor()
    cursor.execute("select vstart,vend,data_ident from conditions WHERE calib_type='environment' and data_ident!='environment:id:0'")
    bad_times = []
    for i in cursor:
        bad_times.append(i)
    cursor.close()
    db.close()
    return bad_times

def get_ed_datetime(ed):
    """Returns datetime object for eventdata object"""
    import datetime
    et = (ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.)
    return datetime.datetime.fromtimestamp(et)

if __name__ == '__main__':
    main()
