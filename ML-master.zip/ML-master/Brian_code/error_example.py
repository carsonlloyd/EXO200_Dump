import ROOT
ROOT.gSystem.Load("libEXOUtilities")
import numpy

def get_apd_array(sc):
    apd_data = numpy.zeros(226-150,dtype='float32')
    apd_data[0] = sc.GetCountsOnAPDPlane(0)
    apd_data[1] = sc.GetCountsOnAPDPlane(1)
    napd = sc.GetNumAPDSignals()
    for j in range(napd):
        sig = sc.GetAPDSignalAt(j)
        if sig.fChannel < 3: continue
        apd_data[sig.fChannel-150] = sig.fRawCounts
    return apd_data


def main():
    print "loading"
    tf = ROOT.TFile("masked00002464-000.root",'r')
    t = tf.Get("tree")
    data = []
    print "NE = %d"%(t.GetEntries())
    for ie in range(min(t.GetEntries(),100)):
        t.GetEntry(ie)
        nsc = t.EventBranch.GetNumScintillationClusters()
        for isc in range(nsc):
            data.append(get_apd_array(t.EventBranch.GetScintillationCluster(isc)))
    return data


if __name__ == '__main__':
    data = main()
