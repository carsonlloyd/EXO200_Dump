import matplotlib.pyplot as plt
import cPickle
#import ROOT
import numpy
from sklearn import tree #DecisionTreeRegressor
from sklearn import cross_validation

# Data is already trained, loading the pickle of the trained data
data = cPickle.load(open("light_only_recon.pkl","r"))
print " Done loading pickle..."
#apd_data = data['apd_data']#[:,0:500]
#norm = numpy.array([1.,1.,1.,200./50000.])
#position = data['position']*norm

# Setup datasets to train and test, start training.
#apd_train, apd_test, pos_train, pos_test = cross_validation.train_test_split(apd_data, position, test_size=0.4)
#dtr = tree.DecisionTreeRegressor()
#dtr.fit(apd_train, pos_train)
#print " Done training..."


# Start testing the predicting on the test set
predict_x,predict_y,predict_z,predict_e = numpy.zeros(apd_test.shape[0]),numpy.zeros(apd_test.shape[0]),numpy.zeros(apd_test.shape[0]),numpy.zeros(apd_test.shape[0])
for i in range(apd_test.shape[0]):
    out = dtr.predict(apd_test[i]) - pos_test[i]
    out = out[0]
    predict_x[i],predict_y[i],predict_z[i],predict_e[i] = out[0],out[1],out[2],out[3]

# Make prediction plots
nbins = 200
hist_x,bins_x = numpy.histogram(predict_x/norm[0],nbins,(-200,200))
hist_y,bins_y = numpy.histogram(predict_y/norm[1],nbins,(-200,200))
hist_z,bins_z = numpy.histogram(predict_z/norm[2],nbins,(-200,200))
hist_e,bins_e = numpy.histogram(predict_e/norm[3],nbins,(-10000,10000))
bincenters_pos = 0.5*(bins_x[1:]+bins_x[:-1])
bincenters_ene = 0.5*(bins_e[1:]+bins_e[:-1])

fig = plt.figure(figsize=(15,6))
plt.subplot(1,4,1)
plt.step(bincenters_pos,hist_x)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("X difference (mm)")
plt.subplot(1,4,2)
plt.step(bincenters_pos,hist_y)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Y difference (mm)")
plt.subplot(1,4,3)
plt.step(bincenters_pos,hist_z)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Z difference (mm)")
plt.subplot(1,4,4)
plt.step(bincenters_ene,hist_e)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Energy difference (APD Counts)")
plt.savefig("energy_pos.png")

def find_sigma(A,val):
    valp = .5+val/2.
    valm = .5-val/2.
    sigma = [None,None]
    for i in range(A.size-1):
        if A[i] < valm and A[i+1]>valm:
            sigma[0] = i
        if A[i] < valp and A[i+1]>valp:
            sigma[1] = i
    return sigma

sum_x = numpy.zeros(hist_x.shape)
sum_y = numpy.zeros(hist_y.shape)
sum_z = numpy.zeros(hist_z.shape)
sum_e = numpy.zeros(hist_e.shape)
for i in range(nbins):
    sum_x[i] = sum(hist_x[0:i+1])
    sum_y[i] = sum(hist_y[0:i+1])
    sum_z[i] = sum(hist_z[0:i+1])
    sum_e[i] = sum(hist_e[0:i+1])
sum_x = sum_x/hist_x.sum()
sum_y = sum_y/hist_y.sum()
sum_z = sum_z/hist_z.sum()
sum_e = sum_e/hist_e.sum()

for i in [.6827,.9545]: #,.9973]:
    print "Sigma %.2f"%i
    valsx = find_sigma(sum_x,i)
    valsy = find_sigma(sum_y,i)
    valsz = find_sigma(sum_z,i)
    valse = find_sigma(sum_e,i)
    print "  X = %.2f,%.2f"%(bincenters_pos[valsx[0]],bincenters_pos[valsx[1]])
    print "  Y = %.2f,%.2f"%(bincenters_pos[valsy[0]],bincenters_pos[valsy[1]])
    print "  Z = %.2f,%.2f"%(bincenters_pos[valsz[0]],bincenters_pos[valsz[1]])
    print "  E = %.2f,%.2f"%(bincenters_ene[valse[0]],bincenters_ene[valse[1]])

figx = plt.figure(figsize=(8,6))
plt.plot(bincenters_pos,sum_x)
plt.title('X difference')
plt.hlines(0.5 - .6827/2,-200,200,'g')
plt.hlines(0.5 + .6827/2,-200,200,'g')
plt.hlines(0.5 - .9545/2,-200,200,'g')
plt.hlines(0.5 + .9545/2,-200,200,'g')
plt.grid()
valsx = find_sigma(sum_x,.6827)
plt.vlines(bincenters_pos[valsx[0]],0,0.5-.6827/2,'g')
plt.vlines(bincenters_pos[valsx[1]],0,0.5+.6827/2,'g')
valsx = find_sigma(sum_x,.9545)
plt.vlines(bincenters_pos[valsx[0]],0,0.5 - .9545/2,'g')
plt.vlines(bincenters_pos[valsx[1]],0,0.5 + .9545/2,'g')
plt.savefig("diff_pos_x.png")

figy = plt.figure(figsize=(8,6))
plt.plot(bincenters_pos,sum_y)
plt.grid()
plt.hlines(0.5 - .6827/2,-200,200,'g')
plt.hlines(0.5 + .6827/2,-200,200,'g')
plt.hlines(0.5 - .9545/2,-200,200,'g')
plt.hlines(0.5 + .9545/2,-200,200,'g')
valsy = find_sigma(sum_y,.6827)
plt.vlines(bincenters_pos[valsy[0]],0,0.5-.6827/2,'g')
plt.vlines(bincenters_pos[valsy[1]],0,0.5+.6827/2,'g')
valsy = find_sigma(sum_y,.9545)
plt.vlines(bincenters_pos[valsy[0]],0,0.5 - .9545/2,'g')
plt.vlines(bincenters_pos[valsy[1]],0,0.5 + .9545/2,'g')
plt.title('Y difference')
#plt.hlines(0.5 - .9973/2,-200,200,'g')
#plt.hlines(0.5 + .9973/2,-200,200,'g')
plt.savefig("diff_pos_y.png")

figz = plt.figure(figsize=(8,6))
plt.plot(bincenters_pos,sum_z)
plt.title('Z difference')
plt.hlines(0.5 - .6827/2,-200,200,'g')
plt.hlines(0.5 + .6827/2,-200,200,'g')
plt.hlines(0.5 - .9545/2,-200,200,'g')
plt.hlines(0.5 + .9545/2,-200,200,'g')
plt.grid()
valsz = find_sigma(sum_z,.6827)
plt.vlines(bincenters_pos[valsz[0]],0,0.5-.6827/2,'g')
plt.vlines(bincenters_pos[valsz[1]],0,0.5+.6827/2,'g')
valsz = find_sigma(sum_z,.9545)
plt.vlines(bincenters_pos[valsz[0]],0,0.5 - .9545/2,'g')
plt.vlines(bincenters_pos[valsz[1]],0,0.5 + .9545/2,'g')
#plt.hlines(0.5 - .9973/2,-200,200,'g')
#plt.hlines(0.5 + .9973/2,-200,200,'g')
plt.savefig("diff_pos_z.png")

fige = plt.figure(figsize=(8,6))
plt.plot(bincenters_ene,sum_e)
plt.title('E difference')
plt.hlines(0.5 - .6827/2,-10000,10000,'g')
plt.hlines(0.5 + .6827/2,-10000,10000,'g')
plt.hlines(0.5 - .9545/2,-10000,10000,'g')
plt.hlines(0.5 + .9545/2,-10000,10000,'g')
plt.grid()
plt.xlim(-10000,10000)
valse = find_sigma(sum_e,.6827)
plt.vlines(bincenters_ene[valse[0]],0,0.5-.6827/2,'g')
plt.vlines(bincenters_ene[valse[1]],0,0.5+.6827/2,'g')
valse = find_sigma(sum_e,.9545)
plt.vlines(bincenters_ene[valse[0]],0,0.5 - .9545/2,'g')
plt.vlines(bincenters_ene[valse[1]],0,0.5 + .9545/2,'g')
#plt.hlines(0.5 - .9973/2,-200,200,'g')
#plt.hlines(0.5 + .9973/2,-200,200,'g')
plt.savefig("diff_pos_e.png")
