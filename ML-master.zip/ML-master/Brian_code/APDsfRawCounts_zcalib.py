import ROOT
ROOT.gROOT.SetStyle("Plain")
ROOT.gStyle.SetPalette(1)
ROOT.gROOT.SetBatch(1)
ROOT.gSystem.Load("libEXOUtilities")
tf = ROOT.TFile("APDsfRawCounts_plane12g8000.root")
t  = tf.Get("tree")


c1 = ROOT.TCanvas("c1","z bins",1200,900)
c1.Divide(1,3)
h1 = ROOT.TH1I("h1","TPC1 APD Plane Signal",200,8000,80000)
h2 = ROOT.TH1I("h2","TPC2 APD Plane Signal",200,8000,80000)
h3 = ROOT.TH1I("h3","BOTH APD Plane Signal",200,8000,80000)
for i in range(-19,20):
    zmin = i*10-5
    zmax = i*10+5
    print zmin,zmax

    vgpad1 = c1.cd(1)
    t.Draw("fAPDs.fRawCounts>>h1","fAPDs.fChannel==1 && fAPDs.fRawCounts>100 && fAPDs.fRawCounts<100000 && @fScintClusters.size()==1 && fChargeClusters.fZ>%d && fChargeClusters.fZ<%d"%(zmin,zmax))
    vgpad1.SetLogy(1)
    h1.SetTitle("TPC1 APD Plane fRawCounts, z>%d and z<%d"%(zmin,zmax))

    vgpad2 = c1.cd(2)
    t.Draw("fAPDs.fRawCounts>>h2","fAPDs.fChannel==2 && fAPDs.fRawCounts>100 && fAPDs.fRawCounts<100000 && @fScintClusters.size()==1 && fChargeClusters.fZ>%d && fChargeClusters.fZ<%d"%(zmin,zmax))
    vgpad2.SetLogy(1)
    h2.SetTitle("TPC2 APD Plane fRawCounts, z>%d and z<%d"%(zmin,zmax))
    
    vgpad3 = c1.cd(3)
    t.Draw("Sum$(fAPDs.fRawCounts)>>h3","(fAPDs.fChannel==1 || fAPDs.fChannel==2) && fAPDs.fRawCounts>100 && fAPDs.fRawCounts<100000 && @fScintClusters.size()==1 && @fChargeClusters.size()==1 && fChargeClusters.fZ>%d && fChargeClusters.fZ<%d"%(zmin,zmax))
    vgpad3.SetLogy(1)
    h3.SetTitle("BOTH APD Plane fRawCounts, z>%d and z<%d"%(zmin,zmax))
    zi = ""
    if i<0:
        zi += 'n'
    else:
        zi += 'p'
    zi+= str(abs(zmin))+'-'+str(abs(zmax))
    c1.Print("APDs_plots/zplot_%s.png"%zi)
    #h1.Reset()
    #h2.Reset()
    
