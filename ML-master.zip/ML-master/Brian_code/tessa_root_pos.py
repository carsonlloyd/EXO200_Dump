import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
import cPickle
import ROOT
ROOT.gSystem.Load("libEXOUtilities")
import numpy
from sklearn import tree #DecisionTreeRegressor

def get_apd_array(sc):
    apd_data = numpy.zeros(226-150,dtype='float32')
    apd_data[0] = sc.GetCountsOnAPDPlane(0)
    apd_data[1] = sc.GetCountsOnAPDPlane(1)
    napd = sc.GetNumAPDSignals()
    for j in range(napd):
        sig = sc.GetAPDSignalAt(j)
        if sig.fChannel < 3: continue
        apd_data[sig.fChannel-150] = sig.fRawCounts
    return apd_data

def get_scint_cluster(event,num):
    all_sc = []
    if event.GetNumScintillationClusters() > 2:
        print "There are more than two SC clusters!"
    if num > event.GetNumScintillationClusters():
        print "Requested SC that does not exist"
        return None
    for i in range(event.GetNumScintillationClusters()):
        sc = event.GetScintillationCluster(i)
        all_sc.append((sc,sc.fTime))
    # We want the SC list sorted by time
    all_sc.sort(key=lambda x: x[1])
    return all_sc[num][0]


def main(argv):
    print "Loading DTR"
    dtr = cPickle.load(open("DTR_all.pkl","r"))
    
    print "Loading Data"
    data = {}
    # Load files (filename,treename,scint_num)
    data_files = [('Case2_BiPo_Tree.root','Case2Tree',0),
                  ('Case2a_BiPo_Tree.root','Case2aTree',0),
                  ('Case2b_BiPo_Tree.root','Case2bTree',0),
                  ('Case4_BiPo_Tree.root','Case4Tree',0),
                  ('Case1_BiPo_Tree.root','Case1Tree',1),
                  ('Case1a_BiPo_Tree.root','Case1aTree',1),
                  ('Case1b_BiPo_Tree.root','Case1bTree',1),
                  ('Case3_BiPo_Tree.root','Case3Tree',1)]
    data_dir = 'tessa_root/'
    for fn,tn,isc in data_files:
        print "Working on %s"%(tn)
        data[tn] = []
        tf = ROOT.TFile(data_dir+fn,'r')
        tree = tf.Get(tn)
        ne = tree.GetEntries()
        for ie in range(ne):
            data[tn].append({})
            data[tn][-1]['entry'] = ie
            tree.GetEntry(ie)
            data[tn][-1]['run'] = tree.EventBranch.fRunNumber
            data[tn][-1]['event'] = tree.EventBranch.fEventNumber
            sc = get_scint_cluster(tree.EventBranch,isc)
            data[tn][-1]['apd_array'] = get_apd_array(sc)
            data[tn][-1]['apd_fTime'] = sc.fTime
            data[tn][-1]['apd_fRawEnergy'] = sc.fRawEnergy
            data[tn][-1]['apd_APDEnergy'] = sc.GetCountsOnAPDPlane(0)+sc.GetCountsOnAPDPlane(1)
            apd_predict = dtr.predict(data[tn][-1]['apd_array'])[0]
            data[tn][-1]['x'] = apd_predict[0]
            data[tn][-1]['y'] = apd_predict[1]
            data[tn][-1]['z'] = apd_predict[2]
            data[tn][-1]['ene'] = apd_predict[3]*50000./200.
    cPickle.dump(data,open('tessa_bipo.pkl','w'))


if __name__ == '__main__':
    main(sys.argv)