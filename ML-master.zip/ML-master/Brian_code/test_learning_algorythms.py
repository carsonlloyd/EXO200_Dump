import cPickle
import numpy
import sklearn
from sklearn import tree #DecisionTreeRegressor
from sklearn import linear_model #BayesianRidge/OrthogonalMatchingPursuit
from sklearn import svm # SVC
from sklearn import cross_validation

data = cPickle.load(open("light_only_recon.pkl","r"))
apd_data = data['apd_data']
#position = data['position']*numpy.array([1,1,1,1/250.])
position = data['position']*numpy.array([1.,1.,1.,200./50000.])

apd_train, apd_test, pos_train, pos_test = cross_validation.train_test_split(apd_data, position, test_size=0.4)


def runall():
    print "DecisionTreeRegressor"
    dtr = tree.DecisionTreeRegressor()
    dtr.fit(apd_train, pos_train)
    print " done, scoring..."
    print "  Score = ",dtr.score(apd_test, pos_test)
    # 0.844157564724

    #print "BayesianRidge"
    lbr = linear_model.BayesianRidge()
    #lbr.fit(apd_train, pos_train)
    #print " done, scoring..."
    #print "  Score = ",lbr.score(apd_test, pos_test)
    # Errored

    print "OrthogonalMatchingPursuit"
    omp = linear_model.OrthogonalMatchingPursuit()
    omp.fit(apd_train, pos_train)
    print " done, scoring..."
    print "  Score = ",omp.score(apd_test, pos_test)
    # 0.243016996592

    #print "SVC"
    svc = svm.SVC(kernel='linear', C=1)
    #svc.fit(apd_train, pos_train)
    #print " done, scoring..."
    #print "  Score = ",svc.score(apd_test, pos_test)
    # Errored

    print "ElasticNet"
    lEN = linear_model.ElasticNet()
    lEN.fit(apd_train,pos_train)
    print " done, scoring..."
    print "  Score = ",lEN.score(apd_test, pos_test)
    # 0.39881324846278399

    print "version", sklearn.__version__

runall()
