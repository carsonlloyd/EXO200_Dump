import pickle
import ROOT
ROOT.gROOT.SetStyle("Plain")
import datetime
import sys
sys.path.append('/u/xo/bung/bin/')
import bungfun
import matplotlib.pyplot as plt
import matplotlib.cm as mplcm
import matplotlib.colors as colors
from matplotlib import gridspec
import numpy
ROOT.gSystem.Load("libEXOUtilities")
data = pickle.load(open('APDs_data.pkl','r'))
treef = ROOT.TFile("APDsfRawCounts_g4000.root")
tree = treef.Get("tree")

feed_events = [
        (datetime.datetime(2012,1,13,10,56,0),21.7),
        (datetime.datetime(2012,1,14,15,26,0),91),
        (datetime.datetime(2012,1,15,13,40,0),40.4),
        (datetime.datetime(2012,1,16,8,54,0),397.1),
        (datetime.datetime(2012,1,17,12,12,0),14.4),
        (datetime.datetime(2012,1,18,12,0,0),392.4),
        (datetime.datetime(2012,6,19,19,30,0),33),
        (datetime.datetime(2012,6,20,9,0,0),269.3),
        (datetime.datetime(2012,8,28,13,34,0),15.7),
        (datetime.datetime(2012,8,30,9,30,0),377.2),
        (datetime.datetime(2012,8,31,16,30,0),269.9),
        (datetime.datetime(2012,9,1,10,55,0),630.2),
        (datetime.datetime(2012,9,12,9,50,0),356.8),
        (datetime.datetime(2012,10,15,15,13,0),343.5),
        (datetime.datetime(2013,2,5,17,0,0),43.0),
        (datetime.datetime(2013,5,5,13,30,0),332.6),
        (datetime.datetime(2013,6,21,11,40,0),355.9),
        (datetime.datetime(2013,7,17,14,20,0),269.5),
        (datetime.datetime(2013,7,18,8,18,0),115.5),
        (datetime.datetime(2013,8,12,9,40,0),546.0)]

# We need a plot of the spectrum for each type of event
fig0 = plt.figure(figsize=(15,8))
x,lowE = bungfun.get_pltXY_TH1D(data['h_low'])
_,rnpoE =  bungfun.get_pltXY_TH1D(data['h_rnpo'])
_,bipoE =  bungfun.get_pltXY_TH1D(data['h_bipo'])
_,Po214E =  bungfun.get_pltXY_TH1D(data['h_Po214'])
_,highE =  bungfun.get_pltXY_TH1D(data['h_high'])
sum = lowE+rnpoE+bipoE+Po214E+highE
plt.step(x[20:],sum[20:],'k.',label='Sum')
plt.step(x[20:],lowE[20:],'*',label='Low E ROI')
plt.step(x[20:],rnpoE[20:],'x',label='Rn/Po Tag')
plt.step(x[20:],bipoE[20:],'s',label='BiPo Tag')
plt.step(x[20:],Po214E[20:],'o',label='Po214 E ROI')
plt.step(x[20:],highE[20:],'>',label='High E ROI')
fig0.gca().set_yscale('log')
plt.grid()
plt.legend()
plt.xlabel('Energy (rel)')
plt.ylabel('Counts')
#plt.show()
plt.savefig('roi_energy.png')
plt.close()

# Plot the events per day for each type of event
fig1 = plt.figure(figsize=(15,12))
plt.subplot(511)
plt.plot(data['phase2_time'],data['roi_low_dpd'],'*',label='LowE')
plt.title('Low E ROI')
plt.grid()
plt.subplot(512)
plt.plot(data['phase2_time'],data['rnpo_dpd'],'x',label='RnPo')
plt.title('Rn/Po Candidates')
plt.grid()
plt.subplot(513)
plt.plot(data['phase2_time'],data['roi_Po214_dpd'],'o',label='Po214')
plt.title('Po214 Candidates')
plt.grid()
plt.subplot(514)
plt.plot(data['phase2_time'],data['roi_high_dpd'],'>',label='HighE')
plt.title('High E ROI')
plt.grid()
plt.subplot(515)
plt.plot(data['phase2_time'],data['bipo_dpd'],'s',label='Bi-Po')
plt.title('Bi-Po Candidates')
plt.grid()
for i in range(5):
    plt.subplot(5,1,i+1)
    ylim = plt.gca().get_ylim()
    for feed in feed_events:
        plt.vlines(feed[0],ylim[0],ylim[1],'r',alpha=0.8)
#fig1.gca().set_yscale('log')
plt.subplots_adjust(hspace=0.2, bottom=0.1)
fig1.autofmt_xdate()
#plt.legend()
#plt.grid()
#plt.show()
plt.savefig('roi_rates.png')
plt.close()

# Investigate the RnPo roi region, what are those events if not Rn or Po?
fig2 = plt.figure(figsize=(12,8))
tree.Draw("fScintClusters.fRawEnergy>>hRnPo","fScintClusters.fRawEnergy>35000 && fScintClusters.fRawEnergy<47000 && @fScintClusters.size() ==1 &&@fChargeClusters.size() ==1 && abs(fChargeClusters.fZ) >5 && abs(fChargeClusters.fZ) < 182","goff")
tree.Draw("fScintClusters.fRawEnergy>>hnotRnPo","fScintClusters.fRawEnergy>35000 && fScintClusters.fRawEnergy<50000 && (@fScintClusters.size() !=1 || @fChargeClusters.size() !=1) && abs(fChargeClusters.fZ) >5 && abs(fChargeClusters.fZ) < 182","goff")
tree.Draw("fScintClusters.fRawEnergy>>hRnPozcut","fScintClusters.fRawEnergy>35000 && fScintClusters.fRawEnergy<50000 && @fScintClusters.size() ==1 &&@fChargeClusters.size() ==1 && (abs(fChargeClusters.fZ) <5 || abs(fChargeClusters.fZ) > 182)","goff")
hRnPo = ROOT.gDirectory.Get("hRnPo")
hnotRnPo = ROOT.gDirectory.Get("hnotRnPo")
hRnPozcut = ROOT.gDirectory.Get("hRnPozcut")
xRnPo,yRnPo = bungfun.get_pltXY_TH1D(hRnPo)
xnotRnPo,ynotRnPo = bungfun.get_pltXY_TH1D(hnotRnPo)
xRnPozcut,yRnPozcut = bungfun.get_pltXY_TH1D(hRnPozcut)
plt.step(xRnPo,yRnPo,label='Rn/Po Candidates')
plt.step(xnotRnPo,ynotRnPo,label='Failed SS')
plt.step(xRnPozcut,yRnPozcut,label='Failed Zcut')
plt.legend()
plt.title('Rn/Po ROI (alpha like i.e. SS)')
plt.savefig('roi_RnPo_cuts.png')
plt.close()

fig3 = plt.figure(figsize=(12,8))
pyh_rn = []
pyh_po8= []
for rn,po in data['RnPo_coincidince']:
    pyh_rn.append(rn[4])
    pyh_po8.append(po[4])
bins = numpy.linspace(30000,50000,100)
plt.hist(pyh_rn,bins,label='Rn',alpha=0.5)
plt.hist(pyh_po8,bins,label='Po',alpha=0.5)
plt.legend()
plt.title('Rn-Po218 Coincidence')
plt.savefig('roi_RnPo_coinc_ene.png')
plt.close()

fig4 = plt.figure(figsize=(15,12))
gs = gridspec.GridSpec(3,1,height_ratios=[3,1,1])
rn_z,po8_z,time,dt,dzdt =  [],[],[],[],[]
for rn,po in data['RnPo_coincidince']:
    rn_z.append(rn[3])
    po8_z.append(po[3])
    time.append(datetime.datetime.fromtimestamp(rn[0]))
    dt.append(po[0]-rn[0])
    dzdt.append((abs(rn[3])-abs(po[3]))/(po[0]-rn[0]))
ax0 = plt.subplot(gs[0])
plt.plot(time,rn_z,'x',label='Rn222')
plt.plot(time,po8_z,'s',label='Po218')
plt.grid()
leg = plt.legend()
leg.get_frame().set_alpha(0.3)
plt.vlines(time,po8_z,rn_z)
plt.title('Drift Position')
ax1 = plt.subplot(gs[1])
plt.plot(time,dt,'o')
plt.grid()
plt.title('Drift dT (s)')
ax2 = plt.subplot(gs[2])
plt.plot(time,dzdt,'o')
plt.ylim((-3,3))
plt.grid()
plt.title('Drift velocity (mm/s)')
plt.savefig('roi_RnPo_driftmap.png')
plt.close()

fig5 = plt.figure(figsize=(12,6))
plt.subplot(121)
bins = numpy.linspace(0,900,50)
plt.hist(dt,bins)
plt.grid()
plt.title('Drift Time (s)')
plt.subplot(122)
bins = numpy.linspace(-3,3,50)
plt.hist(dzdt,bins)
plt.grid()
plt.title('Drift Speed (mm/s)')
plt.savefig('roi_RnPo_drifthist.png')
plt.close()


fig6 = plt.figure(figsize=(12,8))
gs = gridspec.GridSpec(3,1,height_ratios=[3,1,1])
alpha_z,bipo_z,time,dt,dzdt =  [],[],[],[],[]
for a,bipo in data['BiPo_coincidince']:
    alpha_z.append(a[3])
    bipo_z.append(bipo[3])
    time.append(datetime.datetime.fromtimestamp(a[0]))
    dt.append(bipo[0]-a[0])
    dzdt.append( (abs(a[3])-abs(bipo[3]))/(bipo[0]-a[0]) )
ax0 = plt.subplot(gs[0])
plt.plot(time,alpha_z,'x',label='Alpha')
plt.plot(time,bipo_z,'s',label='BiPo')
plt.grid()
leg = plt.legend()
leg.get_frame().set_alpha(0.3)
plt.vlines(time,bipo_z,alpha_z)
plt.title('Drift Position')
ax1 = plt.subplot(gs[1])
plt.plot(time,dt,'o')
plt.grid()
plt.title('Drift dT (s)')
ax2 = plt.subplot(gs[2])
plt.plot(time,dzdt,'o')
#plt.ylim((-3,3))
plt.grid()
plt.title('Drift velocity (mm/s)')
plt.savefig('roi_Alpha_BiPo_driftmap.png')
plt.close()

