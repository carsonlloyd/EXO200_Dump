#!/usr/bin/env python

import ROOT
ROOT.gROOT.SetStyle("Plain")
ROOT.gROOT.SetBatch(1)
ROOT.gStyle.SetPalette(1)
ROOT.gSystem.Load("libEXOUtilities")

import pickle


def main():
    try:
        print "Using existing alpha_alpha_canidates.pkl"
        a = pickle.load(open('alpha_alpha_canidates.pkl','r'))
    except:
        print "Building alpha_alpha_canidates.pkl"
        build_canidates_list()
        a = pickle.load(open('alpha_alpha_canidates.pkl','r'))
    
    hRnE = ROOT.TH1D("hRnE","Rn222_sce",100,30000,50000)
    hPoE = ROOT.TH1D("hRnE","Po218_sce",100,30000,50000)
    hRnPo_dZ = ROOT.TH1D("hRnPo_dZ","RnPo dZ",100,-1,3)
    for i in a:
        for j in a:
            dt =  i[0] - j[0]
            if dt>10 and dt<10*60:
                # so j is first in time (Rn) and i follows (Po)
                if abs(i[1]-j[1]) < 10 and abs(i[2]-j[2])<10:
                    print "dt=%.2f, dzdt=%.2f, dxy=%.2f, dz=%.2f, eRn=%d, ePo=%d"%(dt, (abs(j[3])-abs(i[3]))/dt, ((i[1]-j[1])**2. + (i[2]-j[2])**2.)**.5, abs(j[3])-abs(i[3]),j[4],i[4])
                    hRnE.Fill(j[4])
                    hPoE.Fill(i[4])
                    hRnPo_dZ.Fill((abs(j[3])-abs(i[3]))/dt)
    
    hRnE.SetLineColor(9)
    hRnE.SetLineWidth(2)
    hPoE.SetLineColor(2)
    hPoE.SetLineWidth(2)

    c1 = ROOT.TCanvas("c1","c1",800,600)
    hRnE.Draw()
    hPoE.Draw("same")
    c1.Print("alpha_alpha_E.png")

    c2 = ROOT.TCanvas("c2","c2",800,600)
    hRnPo_dZ.Draw()
    c2.Print("alpha_alpha_Z.png")
    


def build_canidates_list():
    tf = ROOT.TFile("Rn_like.root")
    t = tf.Get("tree")

    ne = t.GetEntries()
    
    canidates = []

    for i in range(ne):
        if i%(ne/10) == 0: print i,'/',ne
        t.GetEntry(i)
        ed = t.EventBranch
        alpha = is_RnPo(ed)
        if alpha != False:
            canidates.append(alpha)
    pickle.dump(canidates,open('alpha_alpha_canidates.pkl','w'))
    


def is_RnPo(ed):
    """
    Rn222 is 5.49 MeV scintillation, peak fRawEnergy is 38500, 
    limits are ~35000 to 42000, but the higher end bleeds into Po218 peak considerably
    """
    # Rn222 is single scintillation cluster events only
    if ed.GetNumScintillationClusters()!=1:
        return False
    sc = ed.GetScintillationCluster(0)
    
    # Rn222 is only single site as well
    if sc.GetNumChargeClusters() != 1:
        return False
    cc = sc.GetChargeClusterAt(0)

    # Make sure it's in the proper energy range
    if sc.fRawEnergy < 35000 or sc.fRawEnergy > 47000:
        return False

    # Make sure it's in the drift volume
    if abs(cc.fZ)<5 or abs(cc.fZ)>182:
        return False
    
    # Canidate event, lets return some useful shit!
    time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.
    x,y,z = cc.fX, cc.fY, cc.fZ
    sce = sc.fRawEnergy
    cce = cc.fPurityCorrectedEnergy

    return (time,x,y,z,sce,cce)
    

if __name__ == '__main__':
    main()
