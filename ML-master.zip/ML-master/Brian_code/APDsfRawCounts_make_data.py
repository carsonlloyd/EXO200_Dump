#!/usr/bin/env python

import ROOT
ROOT.gSystem.Load("libEXOUtilities")
import datetime
import Build_AlphaIon_Data
import alpha_alpha_search
import numpy

# This file was produced from the AlphaIon dataset, using the following cuts:
#  cuts = "@fScintClusters.size()>=1 && Max$(fAPDs.fRawCounts) > 8000 && 
#          fEventHeader.fTaggedAsNoise==0 && fEventHeader.fTaggedAsMuon==0"
# There are 230633 entries in this tree
#treef = ROOT.TFile("APDsfRawCounts_m8000.root")
treef = ROOT.TFile("APDsfRawCounts_m20000.root")
tree = treef.Get("tree")
ntree = tree.GetEntries()
# The run starts on this day, and end on this day:
t0 = datetime.datetime(2011,10,5,0,0,0) #2464
tf = datetime.datetime(2013,9,2,0,0,0) #5597
# Store fully reconstructed tagged alphas's per day in these
bipo_count = numpy.zeros((tf-t0).days+1)
rnpo_count = numpy.zeros((tf-t0).days+1)
roi_low    = numpy.zeros((tf-t0).days+1)
roi_Po214  = numpy.zeros((tf-t0).days+1)
roi_high   = numpy.zeros((tf-t0).days+1)
h_bipo = ROOT.TH1D("h_bipo","BiPo events",300,0,80000)
h_rnpo = ROOT.TH1D("h_rnpo","RnPo events",300,0,80000)
h_low = ROOT.TH1D("h_low","LowE events",300,0,80000)
h_Po214 = ROOT.TH1D("h_Po214","Po214 events",300,0,80000)
h_high = ROOT.TH1D("h_high","HighE events",300,0,80000)
rnpo_event = [] # Store (time,x,y,z,sce,cce)
bipo_event = [] # Store (time,x,y,z,sce,cce)
phase2_time_days  = []
for i in range((tf-t0).days+1):
    phase2_time_days.append( t0 + datetime.timedelta(days=i) )
# Record all the feed events
feed_events = [
        (datetime.datetime(2012,1,13,10,56,0),21.7),
        (datetime.datetime(2012,1,14,15,26,0),91),
        (datetime.datetime(2012,1,15,13,40,0),40.4),
        (datetime.datetime(2012,1,16,8,54,0),397.1),
        (datetime.datetime(2012,1,17,12,12,0),14.4),
        (datetime.datetime(2012,1,18,12,0,0),392.4),
        (datetime.datetime(2012,6,19,19,30,0),33),
        (datetime.datetime(2012,6,20,9,0,0),269.3),
        (datetime.datetime(2012,8,28,13,34,0),15.7),
        (datetime.datetime(2012,8,30,9,30,0),377.2),
        (datetime.datetime(2012,8,31,16,30,0),269.9),
        (datetime.datetime(2012,9,1,10,55,0),630.2),
        (datetime.datetime(2012,9,12,9,50,0),356.8),
        (datetime.datetime(2012,10,15,15,13,0),343.5),
        (datetime.datetime(2013,2,5,17,0,0),43.0),
        (datetime.datetime(2013,5,5,13,30,0),332.6),
        (datetime.datetime(2013,6,21,11,40,0),355.9),
        (datetime.datetime(2013,7,17,14,20,0),269.5),
        (datetime.datetime(2013,7,18,8,18,0),115.5),
        (datetime.datetime(2013,8,12,9,40,0),546.0)]
# Keep track of identified BiPo's so we can look for the Rn daughter that caused it
full_bipo_event = []
alpha_energy = {}
alpha_energy['Planes'] = ROOT.TH1D('hplane','fAPDs.fRawEnergy (P1+P2)',200,0,200000)
alpha_energy['ScintClusters'] = ROOT.TH1D('hsc','fScintClusters.fRawEnergy',200,0,80000)
# Loop over events now 
for i in range(ntree):
    # Print Progress
    if i%(ntree/20) == 0:
        print "Progress = %.2f"%(float(i)/ntree)
    tree.GetEntry(i)
    ed = tree.EventBranch
    event_time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.
    event_datetime = datetime.datetime.fromtimestamp(event_time) 
    # Look for RnPo like events
    RnPo = alpha_alpha_search.is_RnPo(ed) #This returns either False or (time,x,y,z,sce,cce) 
    BiPo = False
    if RnPo:
        # Energy is in the range for Rn222 and Po218
        rnpo_count[(event_datetime - t0).days]+=1
        rnpo_event.append(RnPo)
        h_rnpo.Fill(RnPo[4])
    if Build_AlphaIon_Data.check_full_BiPo(ed):
        # The event is tagged as a BiPo canidate
        BiPo = True
        if RnPo: print "WTF, cant be BiPo and RnPo"
        bipo_count[(event_datetime - t0).days]+=1
        tmp = []
        for isc in range(ed.GetNumScintillationClusters()):
            tmp.append({})
            sc = ed.GetScintillationCluster(isc)
            tmp[isc]['sc_time'] = sc.fTime
            tmp[isc]['sc_ene'] = sc.fRawEnergy
            if sc.GetNumChargeClusters() > 0:
                cc = sc.GetChargeClusterAt(0)
                tmp[isc]['pos'] = (cc.fX,cc.fY,cc.fZ)
        tmp.sort(key=lambda k: k['sc_time'])
        bi_time = tmp[0]['sc_time']/1.e9 + event_time
        bipo_event.append((bi_time,tmp[1]['pos'][0],tmp[1]['pos'][1],tmp[1]['pos'][2],tmp[1]['sc_ene']))
        h_bipo.Fill(tmp[1]['sc_ene'])
    if not RnPo or not BiPo:
        for isc in range(ed.GetNumScintillationClusters()):
            sc = ed.GetScintillationCluster(isc)
            if sc.fRawEnergy < 50000:
                roi_low[(event_datetime - t0).days]+=1
                h_low.Fill(sc.fRawEnergy)
            elif sc.fRawEnergy >= 50000 and sc.fRawEnergy < 60000:
                roi_Po214[(event_datetime - t0).days]+=1
                h_Po214.Fill(sc.fRawEnergy)
            elif sc.fRawEnergy >= 60000:
                roi_high[(event_datetime - t0).days]+=1
                h_high.Fill(sc.fRawEnergy)
print "Done grabbing data."
print "len(rnpo) = %d,  len(bipo) = %d"%(len(rnpo_event),len(bipo_event))
print "Sorting lists..."
rnpo_event.sort(key=lambda x: x[0])
bipo_event.sort(key=lambda x: x[0])
print " ... done sorting lists"
# Now we need to try to associeate decays in a chain...
RnPo_coincidince = []
BiPo_coincidince = []
nrnpo = len(rnpo_event)
for i,ia in enumerate(rnpo_event[1:]):
    # Print Progress
    if i%(nrnpo/10) == 0:
        print "Progress = %.2f"%(float(i)/nrnpo)
    alpha_alpha = 0
    alpha_bipo  = 0
    # Looking for Rn-Po coindinces
    for j,ja in enumerate(rnpo_event[:i+1]):
        dt = ia[0] - ja[0] #Unix time (smaller is earlier)
        # Is the decay within 5 lifetimes of Po218
        if dt>10 and dt<(3.1*5*60):
            if abs(ia[1] - ja[1]) < 20 and abs(ia[2] - ja[2]) < 20:
                RnPo_coincidince.append((ja,ia))
                alpha_alpha +=1
                if alpha_alpha>1:
                    print " Thats %d alpha coincidences with this alpha..."%alpha_alpha
    # Now look for BiPo coincidence with an alpha earlier
    for bp in bipo_event:
        # Ignore events after the BiPo
        if ia[0] > bp[0]: continue
        # Ignore alpahs that happen 3 hours before the BiPo
        if bp[0] - 3600*3. > ia[0]: continue
        if abs(bp[1] - ia[1]) < 20 and abs(bp[2] - ia[2]) < 20:
            BiPo_coincidince.append((ia,bp))
            alpha_bipo +=1
            if alpha_bipo>1:
                print " Thats %d bipo coincidences w/ this alpha..."%alpha_bipo
# Look for a triple coincidence!!!
Triple_coincidince = []
for bp in bipo_event:
    for rn,po in RnPo_coincidince:
        if bp[0] - 3600*3. > po[0]: continue
        if po[0] > bp[0]: continue
        if abs(bp[1]-po[1]) < 20 and abs(bp[2]-po[2]) < 20:
            print "Triple!",rn,po,bp
            Triple_coincidince.append((rn,po,bp))

data = {}
data['BiPo_coincidince'] = BiPo_coincidince
data['RnPo_coincidince'] = RnPo_coincidince
data['Triple_coincidince'] = Triple_coincidince
data['bipo_event'] = bipo_event
data['rnpo_event'] = rnpo_event
data['bipo_dpd'] = bipo_count
data['rnpo_dpd'] = rnpo_count
data['roi_low_dpd'] = roi_low
data['roi_Po214_dpd'] = roi_Po214
data['roi_high_dpd'] = roi_high
data['phase2_time'] = phase2_time_days
data['h_low'] = h_low
data['h_rnpo'] = h_rnpo
data['h_Po214'] = h_Po214
data['h_bipo'] = h_bipo
data['h_high'] = h_high

import pickle
pickle.dump(data,open('APDs_data.pkl','w'))
print "APDs_data.pkl written, done."
