from scipy.special import erfc
import matplotlib.pyplot as plt
from array import array
import cPickle
#import ROOT
#ROOT.gSystem.Load("libEXOUtilities")
import numpy
from sklearn import tree #DecisionTreeRegressor
from sklearn import cross_validation
norm = numpy.array([1.,1.,1.,200./50000.])
import sys

def main(argv):
    if 'redo' in argv:
        create_training_data()
        create_real_data()
        train_DTR()
    if 'retrain' in argv:
        train_DTR()
    predict_data()


def create_training_data():
    tf = ROOT.TFile("AlphaIon_Retry.root","r")
    t = tf.Get("tree")
    cuts = "fScintClusters.fRawEnergy>30000"
    t.Draw(">>+elist",cuts,"goff")
    elist = ROOT.gDirectory.Get("elist")
    ne = elist.GetN()

    print "There are %d entries after the cuts"%ne
    # So APD's start on channel 152, so I'll subtract 150 from that
    # 0 is plane1, 1 is plane2, and then 152 will be index 2, etc, U-pos, Z-pos
    #apd_data = numpy.zeros((ne,226-150+2),dtype='float32')
    #position = numpy.zeros((ne,4),dtype='float32') # [x,y,z,energy]
    apd_data,position = [],[]
    for i in range(ne):
        if i%int(ne/10) == 0:
            print "%d of %d"%(i,ne)
        t.GetEntry(elist.GetEntry(i))
        ed = t.EventBranch
        nsc = ed.GetNumScintillationClusters()
        for isc in range(nsc):
            sc = ed.GetScintillationCluster(0)
            if sc.GetNumChargeClusters() != 1:
                # we only want pure alpha events, so should only have one CC
                continue
            cc = sc.GetChargeClusterAt(0)
            if cc.fPurityCorrectedEnergy > 500:
                # Alphas dont have higher charge energy
                continue
            if sc.fTime > 1928000. or sc.fTime < 120000.:
                # Alpha it too close to event ends
                continue
#            if nsc == 2:
                # For Bi-Po's we dont want to confuse the charges and therefore the location of the Po214
#                if abs(ed.GetScintillationCluster(0).fTime - ed.GetScintillationCluster(1).fTime) < 120000.:
#                    continue
            # This scintillation cluster has passed our event selection cuts
            # Now add the found position to the position array
            position.append((cc.fX, cc.fY, cc.fZ, sc.fRawEnergy))
            # Lets fill the Scintillation data now
            apd_data.append(numpy.zeros(226-150,dtype='float32'))
            apd_data[-1][0] = sc.GetCountsOnAPDPlane(0)
            apd_data[-1][1] = sc.GetCountsOnAPDPlane(1)
            napd = sc.GetNumAPDSignals()
            for j in range(napd):
                sig = sc.GetAPDSignalAt(j)
                if sig.fChannel < 3: continue
                apd_data[-1][sig.fChannel-150] = sig.fRawCounts
    # Pickle dat shit
    del t
    del tf
    print "done looping over data"
    data = {}
    data['apd_data'] = numpy.array(apd_data)
    data['position'] = numpy.array(position)
    data['cuts'] = cuts
    import cPickle
    cPickle.dump(data,open('beta_neutral_training_data.pkl','w'))
    print "done pickling data, making plot"
    fig_train = plt.figure(figsize=(6,4))
    H, xedges, yedges = numpy.histogram2d(data['position'][:,2],data['position'][:,3],bins=(200,200),range=((-200,200),(25000,70000)))
    H = numpy.rot90(H)
    H = numpy.flipud(H)
    H2 = numpy.ma.masked_where(H==0,H)
    H3 = numpy.log(H2)
    plt.pcolormesh(xedges,yedges,H3)
    plt.xlabel('Z pos (mm)')
    plt.ylabel('fRawEnergy (LM corr counts)')
    plt.savefig('Beta_TrainingData.png',dpi=300)
    plt.close(fig_train)


def create_real_data():
    tf = ROOT.TFile("AlphaIon_Retry.root","r")
    t = tf.Get("tree")
    #We want to make some cuts to select better data for training from the concentrated tree
    cuts = "(fScintClusters.GetCountsOnAPDPlane(0)+fScintClusters.GetCountsOnAPDPlane(1))>25000"
    t.Draw(">>+elist",cuts,"goff")
    elist = ROOT.gDirectory.Get("elist")
    ne = elist.GetN()

    print "There are %d entries after the cuts"%ne
    # So APD's start on channel 152, so I'll subtract 150 from that
    # 0 is plane1, 1 is plane2, and then 152 will be index 2, etc, U-pos, Z-pos
    #apd_data = numpy.zeros((ne,226-150+2),dtype='float32')
    #position = numpy.zeros((ne,4),dtype='float32') # [x,y,z,energy]
    apd_data = []
    for i in range(ne):
        if i%int(ne/10) == 0:
            print "%d of %d"%(i,ne)
        t.GetEntry(elist.GetEntry(i))
        ed = t.EventBranch
        nsc = ed.GetNumScintillationClusters()
        for isc in range(nsc):
            sc = ed.GetScintillationCluster(0)
            if sc.GetCountsOnAPDPlane(0)+sc.GetCountsOnAPDPlane(1) < 25000.:
                continue
            # This scintillation cluster has passed our event selection cuts
            # Lets fill the Scintillation data now
            apd_data.append(numpy.zeros(226-150,dtype='float32'))
            apd_data[-1][0] = sc.GetCountsOnAPDPlane(0)
            apd_data[-1][1] = sc.GetCountsOnAPDPlane(1)
            napd = sc.GetNumAPDSignals()
            for j in range(napd):
                sig = sc.GetAPDSignalAt(j)
                if sig.fChannel < 3: continue
                apd_data[-1][sig.fChannel-150] = sig.fRawCounts
    del t
    del tf
    print "done looping over data"
    # Pickle dat shit
    data = {}
    data['apd_data'] = numpy.array(apd_data)
    data['cuts'] = cuts
    import cPickle
    cPickle.dump(data,open('beta_neutral_real_data.pkl','w'))
    print "done pickling data, making plot"
    fig_data = plt.figure(figsize=(6,4))
    plt.hist(data['apd_data'][:,0]+data['apd_data'][:,0],bins=100,range=(25000,70000))
    plt.xlabel('APD counts')
    plt.savefig('Beta_RealData.png',dpi=300)
    plt.close(fig_data)
    print "create_real_data() done "

def train_DTR():
    #data = cPickle.load(open('beta_neutral_training_data.pkl','r'))
    data = cPickle.load(open('light_only_recon_no_fiduc.pkl','r'))
    print "Done loading pickle..."
    apd_data = data['apd_data']#[:,0:500]
    
    position = data['position']*norm
    # Setup datasets to train and test, start training.
    apd_train, apd_test, pos_train, pos_test = cross_validation.train_test_split(apd_data, position, test_size=0.4)
    dtr_test = tree.DecisionTreeRegressor()
    dtr_test.fit(apd_train, pos_train)
    print " done, scoring..."
    print "  Score = ",dtr_test.score(apd_test, pos_test)
#    dtr = tree.DecisionTreeRegressor()
#    dtr.fit(apd_data, position)
#    cPickle.dump(dtr,open('Beta_Neutral_DTR.pkl','w'))


def predict_data():
    dtr = cPickle.load(open('Beta_Neutral_DTR.pkl','r'))
    data = cPickle.load(open('beta_neutral_real_data.pkl','r'))
    out = dtr.predict(data['apd_data'])
    # out should be x,y,z,fRawEnergy
    cPickle.dump(out,open('Beta_predicted_event.pkl','w'))

    fig_out = plt.figure(figsize=(6,4))
    H, xedges, yedges = numpy.histogram2d(out[:,2],out[:,3]/norm[3],bins=(200,200),range=((-200,200),(25000,70000)))
    H = numpy.rot90(H)
    H = numpy.flipud(H)
    H2 = numpy.ma.masked_where(H==0,H)
    H3 = numpy.log(H2)
    plt.pcolormesh(xedges,yedges,H3)
    plt.xlabel('Z pos (mm)')
    plt.ylabel('fRawEnergy (LM corr counts)')
    plt.savefig('Beta_PredictedData.png',dpi=300)
    plt.close(fig_out)

    # Here the fitting to the data happens and the number of alphas extracted
    h1 = ROOT.TH1I("h1","h1",100,30000,60000)
    h2 = ROOT.TH1I("h2","h2",100,30000,60000)
    h1.Sumw2() #Set bin error calc
    h2.Sumw2() #Set bin error calc
    data_py = {'tpc1':[],'tpc2':[]}
    for i in out:
        if i[2] > 30 and i[2] < 175:
            h1.Fill(i[3]/norm[3])
            data_py['tpc1'].append(i[3]/norm[3])
        if i[2] > -175 and i[2] < -30:
            h2.Fill(i[3]/norm[3])
            data_py['tpc2'].append(i[3]/norm[3])

    py_gaus = lambda p,x: p[0]*numpy.exp(-.5*((x-p[1])/p[2])**2)
    gaus = ROOT.TF1("gaus","[0]*exp(-.5*((x-[1])/[2])^2)")
    # Triple gauss for fittting
    #py_skew_trpl_gaus = lambda p,x: p[0]*numpy.exp(-.5*((x-p[1])/p[2])**2)*erfc(p[3]*(x-p[1])/(2.**.5*p[2])) + p[4]*numpy.exp(-.5*((x-p[5])/(p[5]/p[1]*p[2]))**2)*erfc(p[3]*(x-p[5])/(2.**.5*(p[5]/p[1]*p[2]))) + p[6]*numpy.exp(-.5*((x-p[7])/(p[7]/p[1]*p[2]))**2)*erfc(p[3]*(x-p[7])/(2.**.5*(p[7]/p[1]*p[2])))
    #skew_trpl_gaus = ROOT.TF1("skewtrplgaus","[0]*exp(-.5*((x-[1])/[2])^2)*TMath::Erfc([3]*(x-[1])/(sqrt(2)*[2]))+[4]*exp(-.5*((x-[5])/([5]/[1]*[2]))^2)*TMath::Erfc([3]*(x-[5])/(sqrt(2)*[5]/[1]*[2]))+[6]*exp(-.5*((x-[7])/([7]/[1]*[2]))^2)*TMath::Erfc([3]*(x-[7])/(sqrt(2)*[7]/[1]*[2]))")
    #skew_trpl_gaus.SetParameters(400,39000,1000,1,200,43000,50,55000)
    py_trpl_gaus = lambda p,x: p[0]*numpy.exp(-.5*((x-p[1])/p[2])**2) + p[3]*numpy.exp(-.5*((x-p[4])/p[5])**2) + p[6]*numpy.exp(-.5*((x-p[7])/p[8])**2)
    trpl_gaus = ROOT.TF1("trpl_gaus","[0]*exp(-.5*((x-[1])/[2])^2)+[3]*exp(-.5*((x-[4])/[5])^2)+[6]*exp(-.5*((x-[7])/[8])^2)")
    trpl_gaus.SetParameters(1400,39000,500,1400,43000,500,100,55000,500)
    
    # Fit of Rn+Po218+Po214
    h1.Fit("trpl_gaus","0L","goff",30000,60000)
    h1_fit_res = h1.GetFunction("trpl_gaus")
    par_tpc1 = h1_fit_res.GetParameter(0), h1_fit_res.GetParameter(1), h1_fit_res.GetParameter(2),\
               h1_fit_res.GetParameter(3), h1_fit_res.GetParameter(4), h1_fit_res.GetParameter(5),\
               h1_fit_res.GetParameter(6), h1_fit_res.GetParameter(7), h1_fit_res.GetParameter(8),\
               h1_fit_res.GetChisquare(), h1_fit_res.GetNDF()
    h2.Fit("trpl_gaus","0L","goff",30000,60000)
    h2_fit_res = h2.GetFunction("trpl_gaus")
    par_tpc2 = h2_fit_res.GetParameter(0), h2_fit_res.GetParameter(1), h2_fit_res.GetParameter(2),\
               h2_fit_res.GetParameter(3), h2_fit_res.GetParameter(4), h2_fit_res.GetParameter(5),\
               h2_fit_res.GetParameter(6), h2_fit_res.GetParameter(7), h2_fit_res.GetParameter(8),\
               h2_fit_res.GetChisquare(), h2_fit_res.GetNDF()

    fig_trpl_gaus = plt.figure(figsize=(6,4))
    plt.hist(data_py['tpc1'],bins=100,range=(30000,60000),histtype='step',label='TPC1')
    plt.hist(data_py['tpc2'],bins=100,range=(30000,60000),histtype='step',label='TPC2')
    x = numpy.linspace(30000,60000,500)
    y1 = py_trpl_gaus(par_tpc1,x)
    y2 = py_trpl_gaus(par_tpc2,x)
    plt.plot(x,y1,label='Fit 1')
    plt.plot(x,y2,label='Fit 2')
    plt.xlim(35000,60000)
    plt.legend()
    plt.savefig('Beta_Neut_zpos_corr_scint_trpl.png',dpi=200)
    plt.close(fig_trpl_gaus)

    fig_trpl_gaus_ind,axes = plt.subplots(nrows=2,ncols=1,sharex=True,figsize=(6,6))
    axes[0].hist(data_py['tpc1'],bins=100,range=(35000,60000),histtype='step',label='TPC1')
    #plt.hist(data_py['tpc2_zcor_sce'],bins=200,range=(20000,60000),histtype='step',label='TPC2')
    x = numpy.linspace(30000,60000,500)
    y1 = py_trpl_gaus(par_tpc1,x)
    y1Rn = py_gaus((par_tpc1[0],par_tpc1[1],par_tpc1[2]),x)
    y1P8 = py_gaus((par_tpc1[3],par_tpc1[4],par_tpc1[5]),x)
    y1P4 = py_gaus((par_tpc1[6],par_tpc1[7],par_tpc1[8]),x)
    axes[0].plot(x,y1,label='Overall')
    axes[0].plot(x,y1Rn,label='Rn222')
    axes[0].plot(x,y1P4,label='Po218')
    axes[0].plot(x,y1P8,label='Po214')
    axes[0].set_xlim(30000,60000)
    axes[0].legend(prop={'size':12})
    axes[0].set_ylabel('Events')
    #plt.subplot(2,1,2)
    axes[1].hist(data_py['tpc2'],bins=100,range=(35000,60000),histtype='step',label='TPC2')
    y2 = py_trpl_gaus(par_tpc2,x)
    y2Rn = py_gaus((par_tpc2[0],par_tpc2[1],par_tpc2[2]),x)
    y2P8 = py_gaus((par_tpc2[3],par_tpc2[4],par_tpc2[5]),x)
    y2P4 = py_gaus((par_tpc2[6],par_tpc2[7],par_tpc2[8]),x)
    axes[1].plot(x,y2,label='Overall')
    axes[1].plot(x,y2Rn,label='Rn222')
    axes[1].plot(x,y2P4,label='Po218')
    axes[1].plot(x,y2P8,label='Po214')
    axes[1].set_xlim(35000,60000)
    axes[1].legend(prop={'size':12})
    axes[1].set_xlabel('Scintillation Counts')
    axes[1].set_ylabel('Events')
    plt.savefig('Beta_Neut_zpos_corr_scint_trpl_ind_tpc1.png',dpi=200)
    plt.close(fig_trpl_gaus_ind)

    # Lets print results of fits and integrals
    # TPC1
    print "TPC1 Fit Chi^2/NDF = %.2f/%d"%(par_tpc1[9],par_tpc1[10])
    int1_Rn = gaus.Integral(30000,70000,array('d',(par_tpc1[0],par_tpc1[1],par_tpc1[2])))
    print 'TPC1 Rn222 = ', int1_Rn/h1.GetXaxis().GetBinWidth(0)
    int1_P8 = gaus.Integral(30000,70000,array('d',(par_tpc1[3],par_tpc1[4],par_tpc1[5])))
    print 'TPC1 Po218 = ', int1_P8/h1.GetXaxis().GetBinWidth(0)
    int1_P4 = gaus.Integral(30000,70000,array('d',(par_tpc1[6],par_tpc1[7],par_tpc1[8])))
    print 'TPC1 Po214 = ', int1_P4/h1.GetXaxis().GetBinWidth(0)
    # TPC2
    print "TPC2 Fit Chi^2/NDF = %.2f/%d"%(par_tpc2[9],par_tpc2[10])
    int2_Rn = gaus.Integral(30000,70000,array('d',(par_tpc2[0],par_tpc2[1],par_tpc2[2])))
    print 'TPC2 Rn222 = ', int2_Rn/h2.GetXaxis().GetBinWidth(0)
    int2_P8 = gaus.Integral(30000,70000,array('d',(par_tpc2[3],par_tpc2[4],par_tpc2[5])))
    print 'TPC2 Po218 = ', int2_P8/h2.GetXaxis().GetBinWidth(0)
    int2_P4 = gaus.Integral(30000,70000,array('d',(par_tpc2[6],par_tpc2[7],par_tpc2[8])))
    print 'TPC2 Po214 = ', int2_P4/h2.GetXaxis().GetBinWidth(0)

if __name__ == '__main__':
    main(sys.argv)

