import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys
import cPickle
import ROOT
ROOT.gSystem.Load("libEXOUtilities")
import numpy
from sklearn import tree #DecisionTreeRegressor
ROOT.gROOT.SetStyle("Plain")
ROOT.gROOT.SetBatch(1)
ROOT.gStyle.SetPalette(1)
ROOT.gStyle.SetOptStat(11)
ROOT.gStyle.SetLabelSize(0.01,"xyz")
#ROOT.gPad.SetLabelSize(0.01,"xy")
ROOT.gStyle.SetTitleSize(0.02,"xy")
ROOT.gStyle.SetTitleOffset(1.2,"x")
ROOT.gStyle.SetTitleOffset(1.0,"y")
ROOT.gStyle.SetPadTopMargin(0.16)
ROOT.gStyle.SetPadRightMargin(0.13)
ROOT.gStyle.SetPadBottomMargin(0.13)
ROOT.gStyle.SetPadLeftMargin(0.13)
ROOT.gSystem.Load("libEXOUtilities")
ROOT.TGaxis.SetMaxDigits(3)

def main(argv):
    #try:
    #    hists = cPickle.load(open('unrecon_hists.pkl','r'))
    #    print "Using histograms pickled in unrecon_hists.pkl"
    #except:
    #    make_hists(argv)
    #make_plots()
    check_RnPo_coinc()

def get_apd_array(sc):
    apd_data = numpy.zeros(226-150,dtype='float32')
    apd_data[0] = sc.GetCountsOnAPDPlane(0)
    apd_data[1] = sc.GetCountsOnAPDPlane(1)
    napd = sc.GetNumAPDSignals()
    for j in range(napd):
        sig = sc.GetAPDSignalAt(j)
        if sig.fChannel < 3: continue
        apd_data[sig.fChannel-150] = sig.fRawCounts
    return apd_data

def get_charge_info(sc):
    ncl = sc.GetNumChargeClusters()
    charge = {}
    charge['num_clusters'] = ncl
    charge['total_energy'] = 0
    charge['cluster_energy'] = []
    charge['cluster_pos'] = []
    charge['cluster_numv'] = []
    for icl in range(ncl):
        cc = sc.GetChargeClusterAt(icl)
        charge['total_energy'] += cc.fPurityCorrectedEnergy
        charge['cluster_energy'].append(cc.fPurityCorrectedEnergy)
        charge['cluster_pos'].append((cc.fX,cc.fY,cc.fZ))
        charge['cluster_numv'].append(cc.GetNumVWireSignals())
    return charge

def make_hists(argv):
    print "Generating histograms"
    print "Loading TTree %s"%argv[1]
    tf = ROOT.TFile(argv[1],'r')
    t = tf.Get("tree")
    ne = t.GetEntries()
    print "There are %d entries in %s"%(ne,sys.argv[1])

    print "Loading DTR"
    dtr = cPickle.load(open("DTR_all.pkl","r"))

    print "Looping over Data..."
    #Single Scintillation Clusters
    h1_rec_ssc = ROOT.TH1I("h1_rec_ssc","Reconstructed SSC",200,7000,70000)
    h1_nor_ssc_cor = ROOT.TH1I("h1_nor_ssc_cor","NonReconstructed SSC Cor",200,7000,70000)
    h1_nor_ssc_raw = ROOT.TH1I("h1_nor_ssc_raw","NonReconstructed SSC Raw",200,7000,70000)
    h2_rec_ssc = ROOT.TH2I("h2_rec_ssc","Reconstructed SSC",100,0,500,200,7000,70000)
    h2_nor_ssc_cor = ROOT.TH2I("h2_nor_ssc_cor","NonReconstructed SSC Cor",100,0,500,200,7000,70000)
    h2_nor_ssc_raw = ROOT.TH2I("h2_nor_ssc_raw","NonReconstructed SSC Raw",100,0,500,200,7000,70000)
    # Single Site only!
    h1ss_rec_ssc = ROOT.TH1I("h1ss_rec_ssc","Reconstructed SSC",200,7000,70000)
    h1ss_nor_ssc_cor = ROOT.TH1I("h1ss_nor_ssc_cor","NonReconstructed SSC Cor",200,7000,70000)
    h1ss_nor_ssc_raw = ROOT.TH1I("h1ss_nor_ssc_raw","NonReconstructed SSC Raw",200,7000,70000)
    h2ss_rec_ssc = ROOT.TH2I("h2ss_rec_ssc","Reconstructed SSC",100,0,500,200,7000,70000)
    h2ss_nor_ssc_cor = ROOT.TH2I("h2ss_nor_ssc_cor","NonReconstructed SSC Cor",100,0,500,200,7000,70000)
    h2ss_nor_ssc_raw = ROOT.TH2I("h2ss_nor_ssc_raw","NonReconstructed SSC Raw",100,0,500,200,7000,70000)


    h1_rec_msc = ROOT.TH1D("h1_rec_msc","Reconstructed MSC",200,7000,70000)
    h1_nor_msc_cor = ROOT.TH1D("h1_nor_msc_cor","NonReconstructed MSC Cor",200,7000,70000)
    h1_nor_msc_raw = ROOT.TH1D("h1_nor_msc_raw","NonReconstructed MSC Raw",200,7000,70000)
    h2_rec_msc = ROOT.TH2D("h2_rec_msc","Reconstructed MSC",100,0,500,200,7000,70000)
    h2_nor_msc_cor = ROOT.TH2D("h2_nor_msc_cor","NonReconstructed MSC Cor",100,0,500,200,7000,70000)
    h2_nor_msc_raw = ROOT.TH2D("h2_nor_msc_raw","NonReconstructed MSC Raw",100,0,500,200,7000,70000)
    #h3_rec_ssc = ROOT.TH2D("h3_rec_ssc","Reconstructed SSC Pos",100,-200,200,100,-200,200,100,-200,200)
    #h3_nor_ssc = ROOT.TH2D("h3_nor_ssc","NonReconstructed SSC Pos",100,-200,200,100,-200,200,100,-200,200)
    #h3_rec_msc = ROOT.TH2D("h3_rec_msc","Reconstructed MSC Pos",100,-200,200,100,-200,200,100,-200,200)
    #h3_nor_msc = ROOT.TH2D("h3_nor_msc","NonReconstructed MSC Pos",100,-200,200,100,-200,200,100,-200,200)
    ss_non_rec_events = []
    ms_non_rec_events = []
    for i in range(ne):
        if i%(ne/10) == 0: print i,'/',ne
        t.GetEntry(i)
        ed = t.EventBranch
        event_time = ed.fEventHeader.fTriggerSeconds + ed.fEventHeader.fTriggerMicroSeconds/1000000.
        # Single Scintillation Cluster == SSC
        if ed.GetNumScintillationClusters() == 1:
            sc = ed.GetScintillationCluster(0)
            charge = get_charge_info(sc)
            if sc.fRawEnergy == 0: # Non-Reconstructed cluster
                apd_data = get_apd_array(sc)
                out = dtr.predict(apd_data)
                x,y,z,ene = out[0]*numpy.array([1.,1.,1.,50000./200.])
                ss_non_rec_events.append((x,y,z,ene,charge,event_time,ed.fRunNumber,ed.fEventNumber))
                h1_nor_ssc_cor.Fill(ene)
                h1_nor_ssc_raw.Fill(sc.GetCountsOnAPDPlane(1)+sc.GetCountsOnAPDPlane(0))
                if charge['num_clusters'] ==1:
                    h1ss_nor_ssc_cor.Fill(ene)
                    h1ss_nor_ssc_raw.Fill(sc.GetCountsOnAPDPlane(1)+sc.GetCountsOnAPDPlane(0))
                    h2ss_nor_ssc_cor.Fill(charge['total_energy'],ene)
                    h2ss_nor_ssc_raw.Fill(charge['total_energy'],sc.GetCountsOnAPDPlane(1)+sc.GetCountsOnAPDPlane(0))
            else:
                h1_rec_ssc.Fill(sc.fRawEnergy)
                if charge['num_clusters'] ==1:
                    h1ss_rec_ssc.Fill(sc.fRawEnergy)
                    h2ss_rec_ssc.Fill(charge['total_energy'],sc.fRawEnergy)

        # Multi Scintillation CLuster = MSC
        if ed.GetNumScintillationClusters() > 1:
            for isc in range(ed.GetNumScintillationClusters()):
                sc = ed.GetScintillationCluster(isc)
                if sc.fRawEnergy == 0: # Non-Reconstructed cluster
                    apd_data = get_apd_array(sc)
                    out = dtr.predict(apd_data)
                    x,y,z,ene = out[0]*numpy.array([1.,1.,1.,50000./200.])
                    ms_non_rec_events.append((x,y,z,ene,charge,event_time,ed.fRunNumber,ed.fEventNumber))
                    #print out[0]
                    h1_nor_msc_cor.Fill(ene)
                    h1_nor_msc_raw.Fill(sc.GetCountsOnAPDPlane(1)+sc.GetCountsOnAPDPlane(0))
                else:
                    h1_rec_msc.Fill(sc.fRawEnergy)
    data = {}
    # Single Scintillation
    data['h1_rec_ssc'] = h1_rec_ssc
    data['h1_nor_ssc_cor'] = h1_nor_ssc_cor
    data['h1_nor_ssc_raw'] = h1_nor_ssc_raw
    data['h2_rec_ssc'] = h2_rec_ssc
    data['h2_nor_ssc_cor'] = h2_nor_ssc_cor
    data['h2_nor_ssc_raw'] = h2_nor_ssc_raw
    # Single Scintillation, Single Charge Cluster
    data['h1ss_rec_ssc'] = h1ss_rec_ssc
    data['h1ss_nor_ssc_cor'] = h1ss_nor_ssc_cor
    data['h1ss_nor_ssc_raw'] = h1ss_nor_ssc_raw
    data['h2ss_rec_ssc'] = h2ss_rec_ssc
    data['h2ss_nor_ssc_cor'] = h2ss_nor_ssc_cor
    data['h2ss_nor_ssc_raw'] = h2ss_nor_ssc_raw
    # Mulit Scintillation Cluster
    data['h1_rec_msc'] = h1_rec_msc
    data['h1_nor_msc_cor'] = h1_nor_msc_cor
    data['h1_nor_msc_raw'] = h1_nor_msc_raw
    data['h2_rec_msc'] = h2_rec_msc
    data['h2_nor_msc_cor'] = h2_nor_msc_cor
    data['h2_nor_msc_raw'] = h2_nor_msc_raw
    data['ms_non_rec_events'] = ms_non_rec_events
    data['ss_non_rec_events'] = ss_non_rec_events
    cPickle.dump(data,open('unrecon_hists.pkl','w'))

def make_plots():
    data = cPickle.load(open('unrecon_hists.pkl','r'))

    c1 = ROOT.TCanvas("c1","c1",800,800)
    data['h1_rec_ssc'].Draw()
    c1.Print("unrecon_h1_rec_ssc.png")

    c2 = ROOT.TCanvas("c2","c2",1600,800)
    p1 = ROOT.TPad("p1","UnCorrectedScint",0,0,0.48,1)
    p2 = ROOT.TPad("p2","CorrectedScint",0.52,0,1,1)
    p1.Draw()
    p2.Draw()
    p1.cd()
    data['h1_nor_ssc_raw'].Draw()
    data['h1_nor_ssc_raw'].GetXaxis().SetLabelSize(0.035)
    data['h1_nor_ssc_raw'].GetYaxis().SetLabelSize(0.035)
    data['h1_nor_ssc_raw'].GetXaxis().SetTitle("Scnitillation (cor counts)")
    data['h1_nor_ssc_raw'].GetXaxis().SetTitleSize(0.04)
    p2.cd()
    data['h1_nor_ssc_cor'].Draw()
    data['h1_nor_ssc_cor'].GetXaxis().SetLabelSize(0.035)
    data['h1_nor_ssc_cor'].GetYaxis().SetLabelSize(0.035)
    data['h1_nor_ssc_cor'].GetXaxis().SetTitle("Scnitillation (cor counts)")
    data['h1_nor_ssc_cor'].GetXaxis().SetTitleSize(0.04)
    c2.Print("unrecon_h1_nor_ssc.png")

    c3 = ROOT.TCanvas("c3","c3",1600,800)
    p1 = ROOT.TPad("p1","UnCorrectedScint",0,0,0.49,1)
    p2 = ROOT.TPad("p2","CorrectedScint",0.51,0,1,1)
    p1.Draw()
    p2.Draw()
    p1.cd()
    data['h2ss_nor_ssc_raw'].Draw("COLZ")
    data['h2ss_nor_ssc_raw'].GetXaxis().SetLabelSize(0.035)
    data['h2ss_nor_ssc_raw'].GetYaxis().SetLabelSize(0.035)
    data['h2ss_nor_ssc_raw'].GetXaxis().SetTitle("Charge (purity cor)")
    data['h2ss_nor_ssc_raw'].GetXaxis().SetTitleSize(0.04)
    p2.cd()
    data['h2ss_nor_ssc_cor'].Draw("COLZ")
    data['h2ss_nor_ssc_cor'].GetXaxis().SetLabelSize(0.035)
    data['h2ss_nor_ssc_cor'].GetYaxis().SetLabelSize(0.035)
    c3.Print("unrecon_h2ss_ssc_raw_cor.png")

    c4 = ROOT.TCanvas("c4","c4",1600,800)
    p1 = ROOT.TPad("p1","UnCorrectedScint",0,0,0.49,1)
    p2 = ROOT.TPad("p2","CorrectedScint",0.51,0,1,1)
    p1.Draw()
    p2.Draw()
    p1.cd()
    data['h2ss_rec_ssc'].Draw("COLZ")
    data['h2ss_rec_ssc'].GetXaxis().SetLabelSize(0.035)
    data['h2ss_rec_ssc'].GetYaxis().SetLabelSize(0.035)
    p2.cd()
    data['h2ss_nor_ssc_cor'].Draw("COLZ")
    data['h2ss_nor_ssc_cor'].GetXaxis().SetLabelSize(0.035)
    data['h2ss_nor_ssc_cor'].GetYaxis().SetLabelSize(0.035)
    c4.Print("unrecon_h2ss_rec_nor.png")

    ss_ne = len(data['ss_non_rec_events'])
    rn_x,rn_y,rn_z = [],[],[] #numpy.zeros(ss_ne),numpy.zeros(ss_ne),numpy.zeros(ss_ne)
    po_x,po_y,po_z = [],[],[] #numpy.zeros(ss_ne),numpy.zeros(ss_ne),numpy.zeros(ss_ne)
    for i,sse in enumerate(data['ss_non_rec_events']):
        if sse[3] > 36000 and sse[3] < 40300:
            rn_x.append(sse[0])
            rn_y.append(sse[1])
            rn_z.append(sse[2])
        elif sse[3] > 40300 and sse[3] < 44000:
            po_x.append(sse[0])
            po_y.append(sse[1])
            po_z.append(sse[2])
            #po_x[i],po_y[i],po_z[i] = sse[0],sse[1],sse[2]


    fig1 = plt.figure(figsize=(15,13))
    ax1 = fig1.add_subplot(111, projection='3d')
    ax1.scatter(rn_x,rn_y,rn_z, s=4, marker='o',facecolor='r',lw=0)
    ax1.grid()
    ax1.set_xlim(-200,200)
    ax1.set_ylim(-200,200)
    ax1.set_zlim(-200,200)
    ax1.set_xlabel('X (mm)')
    ax1.set_ylabel('Y (mm)')
    ax1.set_zlabel('Z (mm)')
    ax1.view_init(elev=15., azim=65.)
    ax1.set_title('SS Rn ROI')
    fig1.savefig('unrecon_3D_SS_Rn_ROI.png')
    plt.close(fig1)

    fig2 = plt.figure(figsize=(15,13))
    ax2 = fig2.add_subplot(111, projection='3d')
    ax2.scatter(po_x,po_y,po_z, s=4, marker='o',facecolor='b',lw=0)
    ax2.grid()
    ax2.set_xlim(-200,200)
    ax2.set_ylim(-200,200)
    ax2.set_zlim(-200,200)
    ax2.set_xlabel('X (mm)')
    ax2.set_ylabel('Y (mm)')
    ax2.set_zlabel('Z (mm)')
    ax2.view_init(elev=15., azim=65.)
    ax2.set_title('SS Po ROI')
    fig2.savefig('unrecon_3D_SS_Po_ROI.png')
    plt.close(fig2)

def sign(num1):
    if num1 < 0:
        return -1
    if num1 >= 0:
        return 1

def check_RnPo_coinc():
    print "Checking for Rn/Po coincidences"
    data = cPickle.load(open('unrecon_hists.pkl','r'))
    print "Sorting events by time"
    data['ss_non_rec_events'].sort(key=lambda x: x[5])
    # Data Tuple = (x,y,z,ene,charge,event_time,ed.fRunNumber,ed.fEventNumber)
    Rn = [36000,40300]
    Po = [40300,44000]
    time_delay = 3.1*60.*2
    coincidences = []
    ne = len(data['ss_non_rec_events'])
    print "Looping for coincidences"
    for i,e1 in enumerate(data['ss_non_rec_events'][:-1]):
        if i%int(ne/10)==0:
            #print e1
            print " progress %d/%d"%(i,ne)
        if e1[3]<30000 or e1[3]>55000: continue
        for e2 in data['ss_non_rec_events'][i+1:]:
            if e2[3] < 30000 or e2[3]>55000: continue
            if e2[5] > e1[5]+e1[2]/2.0: break
            if ((e1[0]-e2[0])**2. + (e1[1]-e2[1])**2.)**0.5 <= 50 and sign(e1[2]) == sign(e2[2]) and e2[5]>e1[5]+10.:
                coincidences.append((e1,e2))
    cPickle.dump(coincidences,open("non_rec_conin.pkl","w"))
    print "Num coincidences = %d"%len(coincidences)
    e1,e2 = [],[]
    for i in coincidences:
        e2.append(i[1][3])
        e1.append(i[0][3])
    hist_e1,bins_e1 = numpy.histogram(e1,50,(35000,45000))
    hist_e2,bins_e2 = numpy.histogram(e2,50,(35000,45000))
    xe1 = 0.5*(bins_e1[1:]+bins_e1[:-1])
    xe2 = 0.5*(bins_e2[1:]+bins_e2[:-1])
    fig = plt.figure(figsize=(8,6))
    plt.step(xe1,hist_e1,'r',label="First")
    plt.step(xe2,hist_e2,'b',label="Second")
    plt.legend()
    plt.savefig('unrecon_RnPo_coinc_ene.png')


if __name__ == '__main__':
    main(sys.argv)
