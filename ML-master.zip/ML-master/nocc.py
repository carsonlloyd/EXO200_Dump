#!/usr/bin/env python

from __future__ import print_function

import cPickle as pickle
import os
import sys

import numpy as np
import matplotlib.pyplot as plt


def load (filename):
	with open (filename, 'rb') as f:
		return pickle.load (f)

def save (obj, filename):
	with open (filename, 'wb') as f:
		pickle.dump (obj, f, -1)

class Data (object):

	def __init__ (self, candidates=None):
		self._cols = 't x y z nsc scE ccE u v ' \
			'x_ml y_ml scE_ml z_ml'.split ()
		if candidates is not None:
			for (i, col) in enumerate (self._cols):
				setattr (self, col, candidates.T[i])

	def __len__ (self):
		return self.t.size

	def get_copy (self, mask):
		out = Data ()
		for col in self._cols:
			a = getattr (self, col)
			setattr (out, col, a[mask])
		return out	

def load_data ():
	return Data (load ('onescnocc_with_ada100_position.pkl')['candidates'])
'''
## plot nsc
#plt.figure(1); plt.clf(); ax = plt.gca(); hist, bins = np.histogram(data.nsc, bins = 220, range = (28000,50000)); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax.plot(xhist, yhist, drawstyle='steps-post'); plt.xlim(28000,50000); plt.xlabel('Scintillation Counts'); plt.ylabel('Events'); plt.title('One Scint Cluster, No Charge Clusters'); plt.savefig('nocc_nscounts_28-50.png');  plt.show()

## plot 3d location
#from mpl_toolkits.mplot3d import Axes3D; pos_3d = plt.figure(2); ax = pos_3d.add_subplot(111, projection='3d'); ax.scatter(data.x_ml[surface_mask],data.y_ml[surface_mask],data.z_ml[surface_mask], s=2, lw=0); ax.set_xlabel('x'); ax.set_ylabel('y'); ax.set_zlabel('z'); ax.set_xlim([-200,200]); ax.set_ylim([-200,200]); ax.set_zlim([-200,200]); plt.savefig('surfaceplots/nocc_3d_surf.png'); plt.show(); plt.close(pos_3d)

## plot z locations
z_edges = np.array([-200, -190, -10, -1, 0, 1, 10, 190, 200]); nbins = 20; 
#z_edges = np.arange(-200,200,10)

for (z1, z2) in zip(z_edges[:-1], z_edges[1:]):

	mask = (z1 <= data.z_ml) & (data.z_ml < z2)
	hists, xedges, yedges = np.histogram2d(data.x_ml[mask&nsc_mask], data.y_ml[mask&nsc_mask], bins=nbins)
	hists = np.rot90(hists)
	hists = np.flipud(hists)
	hists_masked = np.ma.masked_where(hists==0,hists)
	fig = plt.figure()

	if z1 == -200 or z1 == 190: colormax = 16
	elif z1 == -190 or z1 == 10: colormax = 200
	elif z1 == -1 or z1 == 0: colormax = 16
	elif z1 == -10 or z1 == 1: colormax = 20
	else: colormax = 80

	plt.pcolormesh(xedges, yedges, hists_masked, vmax=colormax)
	plt.xlabel('x')
	plt.ylabel('y')
	cbar = plt.colorbar()
	cbar.ax.set_ylabel('Counts')
	plt.savefig('surfaceplots/nocc_heatmaps/nocc_%3.1f_to_%3.1f.png'%(z1,z2))
	plt.close(fig)




## plot z 
#hist, bins = np.histogram(data.z_ml[mask], bins=40, range = (-200,200)); plt.figure(1); xhist, yhist = bins, np.r_[hist,hist[-1]]; ax = plt.gca(); ax.plot(xhist, yhist, drawstyle='steps-post', color='b'); bin_centers = bins[:-1] + 0.5 * np.diff(bins); ax.errorbar(bin_centers, hist, yerr=np.sqrt(hist), linestyle='none', capsize=0, color='b'); plt.xlabel('z'); plt.ylabel('Events'); plt.show(); plt.close(fig)

#plt.savefig('no_cc_28-50.png'); plt.show(); plt.close(fig)




hist, bins = np.histogram(data.z_ml[z_mask&tpc1&nsc_mask], bins = 40, range = (0,200)); hist_norm = np.sum(hist*np.diff(bins)); hist = hist/hist_norm; fig = plt.figure(1); fig.clf(); ax = plt.gca(); xedges, yedges = bins, np.r_[hist,hist[-1]]; ax.plot(xedges,yedges, drawstyle='steps-post'); bincenters = bins[:-1] + 0.5*np.diff(bins); ax.errorbar(bincenters, hist, yerr=np.sqrt(hist/hist_norm),linestyle='none',capsize=0,color='b'); plt.xlabel('z'); ax.plot(np.linspace(0,200,40),cdf2.pdf(np.linspace(0,200,40)),drawstyle='steps-post'); plt.savefig('surfaceplots/z_normed_bulk_tpc1.png'); plt.show()

fig = plt.figure(1); fig.clf(); ax = plt.gca(); yedges2 = np.r_[hist_cum,hist_cum[-1]]; ax.plot(xedges, 5*yedges2,drawstyle='steps-post'); ax.plot(x,cdf2.cdf(x)); ax.errorbar(bincenters, 5*hist_cum, yerr=5*np.sqrt(hist_cum/hist_norm),linestyle='none',capsize=0,color='b');plt.ylim(-0.5,1.5); plt.show();





'''
