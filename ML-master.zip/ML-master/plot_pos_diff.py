#!/usr/bin/env python
## Takes in pickles of differences between training sets and test sets, plots them
## Erica Smith
## February 16, 2015

import cPickle
import os
import sys 
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn import metrics
from sklearn import cross_validation

## output directory is input 
outdir = "./%s" %sys.argv[1]
if not os.path.isdir(outdir):
	os.mkdir(outdir)

## open the data file
diffs = cPickle.load(open("Brian_code/DTR_beta_neutral_training_data.pkl","r"))
print "Done loading pickle..."
diff_train = diffs['train']
diff_test = diffs['test']

## Score of the algorithm
print "Training set score:", diffs['score_train']
print "Testing set score:", diffs['score_test']

## plot position differences for training set
nbins = 200
norm = np.array([1.,1.,1.,200./50000.])
hist_x_train, bins_x_train = np.histogram(diff_train[:,0]/norm[0],nbins,(-200,200))
hist_y_train, bins_y_train = np.histogram(diff_train[:,1]/norm[1],nbins,(-200,200))
hist_z_train, bins_z_train = np.histogram(diff_train[:,2]/norm[2],nbins,(-200,200))
hist_e_train, bins_e_train = np.histogram(diff_train[:,3]/norm[3],nbins,(-10000,10000))
bincenters_pos = 0.5*(bins_x_train[1:]+bins_x_train[:-1])
bincenters_ene = 0.5*(bins_e_train[1:]+bins_e_train[:-1])

fig = plt.figure(figsize=(15,6))
plt.subplot(1,4,1)
plt.step(bincenters_pos,hist_x_train)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("X difference (mm)")
plt.subplot(1,4,2)
plt.step(bincenters_pos,hist_y_train)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Y difference (mm)")
plt.subplot(1,4,3)
plt.step(bincenters_pos,hist_z_train)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Z difference (mm)")
plt.subplot(1,4,4)
plt.step(bincenters_ene,hist_e_train)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Energy difference (APD Counts)")
plt.savefig("%s/%s_difference_training_set.png"%(outdir,outdir))

## plot position differences for test set
hist_x_test, bins_x_test = np.histogram(diff_test[:,0]/norm[0],nbins,(-200,200))
hist_y_test, bins_y_test = np.histogram(diff_test[:,1]/norm[1],nbins,(-200,200))
hist_z_test, bins_z_test = np.histogram(diff_test[:,2]/norm[2],nbins,(-200,200))
hist_e_test, bins_e_test = np.histogram(diff_test[:,3]/norm[3],nbins,(-10000,10000))
bincenters_pos = 0.5*(bins_x_test[1:]+bins_x_test[:-1])
bincenters_ene = 0.5*(bins_e_test[1:]+bins_e_test[:-1])

fig = plt.figure(figsize=(15,6))
plt.subplot(1,4,1)
plt.step(bincenters_pos,hist_x_test)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("X difference (mm)")
plt.subplot(1,4,2)
plt.step(bincenters_pos,hist_y_test)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Y difference (mm)")
plt.subplot(1,4,3)
plt.step(bincenters_pos,hist_z_test)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Z difference (mm)")
plt.subplot(1,4,4)
plt.step(bincenters_ene,hist_e_test)
locs, labels = plt.xticks()
plt.setp(labels, rotation=90)
plt.title("Energy difference (APD Counts)")
plt.savefig("%s/%s_difference_test_set.png"%(outdir,outdir))
