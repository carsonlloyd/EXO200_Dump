#!/usr/bin/env python
import ROOT
import sys
ROOT.gSystem.Load("libEXOUtilities")
import pickle

run_list = pickle.load(open('alphaion_runs.pkl','r'))

t = ROOT.TChain("tree")
for run in run_list.keys():
	for afile in run_list[run]['file_paths']:
		t.Add(afile)

cuts = "fEventHeader.fTaggedAsNoise==0 && fEventHeader.fTaggedAsMuon==0"
t.Draw(">>+alpha_candidates",cuts,"goff")
alpha_candidates = ROOT.gDirectory.Get("alpha_candidates")

tf = ROOT.TFile("alpha_runs.root","RECREATE")
Rntree = t.CloneTree(0)

for i in range(alpha_candidates.GetN()):
	if i%int(alpha_candidates.GetN()/20) == 0:
		print "%d of %d"%(i,alpha_candidates.GetN())
	t.GetEntry(alpha_candidates.GetEntry(i))
	Rntree.Fill()

Rntree.AutoSave()
